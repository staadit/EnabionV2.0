import Head from 'next/head';
import type { GetServerSideProps } from 'next';
import { useState } from 'react';
import OrgShell from '../../../components/OrgShell';
import { getYNavItems } from '../../../lib/org-nav';
import { requireOrgContext, type OrgInfo, type OrgUser } from '../../../lib/org-context';
import { formatDateTime } from '../../../lib/date-format';
import {
  fetchIncomingIntent,
  type AttachmentRedactionView,
  type IntentRedactionView,
} from '../../../lib/intent-redaction';

type IncomingIntentDetailProps = {
  user: OrgUser;
  org: OrgInfo;
  intentId: string;
  intent: IntentRedactionView | null;
  attachments: AttachmentRedactionView[];
};

export default function IncomingIntentDetail({
  user,
  org,
  intentId,
  intent,
  attachments,
}: IncomingIntentDetailProps) {
  const ndaGate = intent?.ndaGate;
  const isLocked =
    Boolean(intent?.confidentialityLevel === 'L2' && ndaGate?.canViewL2 === false) ||
    Boolean(intent?.l2Redacted || intent?.ndaRequired);
  const [requesting, setRequesting] = useState(false);
  const [requestError, setRequestError] = useState<string | null>(null);
  const [requestSentAt, setRequestSentAt] = useState<string | null>(
    intent?.ndaRequestedAt ?? null,
  );
  const canRequest =
    Boolean(intent?.senderOrgId) && Boolean(isLocked) && !requestSentAt;

  const handleRequestNda = async () => {
    if (!intent?.senderOrgId || requesting) return;
    setRequesting(true);
    setRequestError(null);
    try {
      const res = await fetch('/api/nda/mutual/request', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          counterpartyOrgId: intent.senderOrgId,
          intentId,
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => null);
        setRequestError(data?.error ?? 'Failed to request NDA');
        return;
      }
      setRequestSentAt(new Date().toISOString());
    } catch {
      setRequestError('Failed to request NDA');
    } finally {
      setRequesting(false);
    }
  };

  return (
    <OrgShell
      user={user}
      org={org}
      eyebrow="Y Portal"
      title={`Incoming Intent ${intentId}`}
      subtitle="L1 details with NDA-gated L2 content."
      navItems={getYNavItems(org.slug, 'inbox')}
    >
      <Head>
        <title>{org.name} - Incoming Intent {intentId}</title>
      </Head>
      <div style={cardStyle}>
        {!intent ? (
          <p style={{ margin: 0, color: 'var(--danger)' }}>Unable to load intent details.</p>
        ) : (
          <>
            <div style={detailGridStyle}>
              <div>
                <div style={labelStyle}>Title</div>
                <div style={valueStyle}>{intent.title ?? intent.intentName ?? '-'}</div>
              </div>
              <div>
                <div style={labelStyle}>Client org</div>
                <div style={valueStyle}>{intent.clientOrgName ?? '-'}</div>
              </div>
              <div>
                <div style={labelStyle}>Stage</div>
                <div style={valueStyle}>{intent.stage}</div>
              </div>
              <div>
                <div style={labelStyle}>Role</div>
                <div style={valueStyle}>{intent.recipientRole ?? '-'}</div>
              </div>
              <div>
                <div style={labelStyle}>Last activity</div>
                <div style={valueStyle}>{formatDateTime(intent.lastActivityAt)}</div>
              </div>
            </div>
            <div style={badgeRowStyle}>
              <span style={badgeStyle}>{intent.confidentialityLevel}</span>
              {isLocked ? <span style={lockedBadgeStyle}>Locked</span> : null}
            </div>
            <div style={summaryStyle}>
              <div style={labelStyle}>Summary</div>
              <div style={summaryTextStyle}>{intent.goal || '-'}</div>
            </div>
            {intent.client ? (
              <div style={summaryStyle}>
                <div style={labelStyle}>End client</div>
                <div style={summaryTextStyle}>{intent.client}</div>
              </div>
            ) : null}
            {isLocked ? (
              <div style={lockedCardStyle}>
                <strong>L2 details locked</strong>
                <p style={lockedTextStyle}>
                  Mutual NDA acceptance is required to view the source text and L2 attachments.
                </p>
                {requestSentAt ? (
                  <p style={lockedTextStyle}>
                    NDA request sent: {formatDateTime(requestSentAt)}
                  </p>
                ) : null}
                {requestError ? (
                  <p style={{ margin: 0, color: 'var(--danger)' }}>{requestError}</p>
                ) : null}
                {canRequest ? (
                  <button
                    type="button"
                    style={primaryButtonStyle}
                    onClick={handleRequestNda}
                    disabled={requesting}
                  >
                    {requesting ? 'Requesting...' : 'Request mutual NDA'}
                  </button>
                ) : null}
                <a
                  href={`/${org.slug}/incoming-intents/${intentId}/nda?counterpartyOrgId=${encodeURIComponent(
                    intent.senderOrgId ?? '',
                  )}`}
                  style={linkStyle}
                >
                  Accept NDA
                </a>
              </div>
            ) : intent.sourceTextRaw ? (
              <div style={l2BlockStyle}>
                <div style={labelStyle}>Source text</div>
                <pre style={sourceTextStyle}>{intent.sourceTextRaw}</pre>
              </div>
            ) : null}
          </>
        )}
      </div>

      {intent ? (
        <div style={sectionStyle}>
          <h3 style={sectionTitleStyle}>Attachments</h3>
          {attachments.length ? (
            <div style={tableCardStyle}>
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <th style={thStyle}>Name</th>
                    <th style={thStyle}>Size</th>
                    <th style={thStyle}>Level</th>
                    <th style={thStyle}>Date</th>
                    <th style={thStyle}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {attachments.map((attachment) => (
                    <tr key={attachment.id}>
                      <td style={tdStyle}>{attachment.originalName}</td>
                      <td style={tdStyle}>
                        {attachment.sizeBytes ? formatBytes(attachment.sizeBytes) : '-'}
                      </td>
                      <td style={tdStyle}>
                        <span style={badgeStyle}>{attachment.confidentialityLevel}</span>
                      </td>
                    <td style={tdStyle}>{formatDateTime(attachment.createdAt)}</td>
                    <td style={tdStyle}>
                      {attachment.canDownload ? (
                        <a href={`/api/attachments/${attachment.id}`} style={linkStyle}>
                          Download
                        </a>
                      ) : (
                        <a
                          href={`/${org.slug}/incoming-intents/${intentId}/nda`}
                          style={lockedStyle}
                        >
                          Locked (Accept NDA)
                        </a>
                      )}
                    </td>
                  </tr>
                ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p style={mutedStyle}>No attachments shared yet.</p>
          )}
        </div>
      ) : null}
    </OrgShell>
  );
}

const cardStyle = {
  padding: '1rem 1.25rem',
  borderRadius: '12px',
  border: '1px solid var(--border)',
  background: 'var(--surface)',
  boxShadow: 'var(--shadow)',
};

const detailGridStyle = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
  gap: '1rem',
};

const labelStyle = {
  fontSize: '0.7rem',
  letterSpacing: '0.08em',
  textTransform: 'uppercase' as const,
  color: 'var(--muted)',
};

const valueStyle = {
  marginTop: '0.35rem',
  fontWeight: 600,
  color: 'var(--text)',
};

const summaryStyle = {
  marginTop: '1.25rem',
  padding: '1rem',
  borderRadius: '12px',
  border: '1px solid var(--border)',
  background: 'var(--surface-2)',
};

const summaryTextStyle = {
  marginTop: '0.5rem',
  fontSize: '0.95rem',
  color: 'var(--text)',
};

const lockedCardStyle = {
  marginTop: '1.25rem',
  padding: '1rem 1.25rem',
  borderRadius: '12px',
  border: '1px solid var(--border)',
  background: 'var(--surface-2)',
  boxShadow: 'var(--shadow)',
};

const lockedTextStyle = {
  margin: '0.4rem 0 0.6rem',
  color: 'var(--muted)',
};

const l2BlockStyle = {
  marginTop: '1.25rem',
};

const sourceTextStyle = {
  marginTop: '0.5rem',
  padding: '0.75rem 1rem',
  borderRadius: '10px',
  border: '1px solid var(--border)',
  background: 'var(--surface)',
  whiteSpace: 'pre-wrap' as const,
  fontFamily: '"IBM Plex Mono", "Fira Code", monospace',
  fontSize: '0.85rem',
  color: 'var(--text)',
};

const sectionStyle = {
  marginTop: '2rem',
};

const badgeRowStyle = {
  display: 'flex',
  flexWrap: 'wrap' as const,
  gap: '0.5rem',
  marginTop: '1rem',
};

const sectionTitleStyle = {
  margin: '0 0 1rem',
  fontSize: '1.1rem',
};

const tableCardStyle = {
  borderRadius: '12px',
  border: '1px solid var(--border)',
  background: 'var(--surface)',
  overflow: 'hidden',
  boxShadow: 'var(--shadow)',
};

const tableStyle = {
  width: '100%',
  borderCollapse: 'collapse' as const,
};

const thStyle = {
  textAlign: 'left' as const,
  padding: '0.75rem 1rem',
  fontSize: '0.85rem',
  color: 'var(--muted)',
  borderBottom: '1px solid var(--border)',
};

const tdStyle = {
  padding: '0.75rem 1rem',
  borderBottom: '1px solid var(--border)',
  fontSize: '0.95rem',
  color: 'var(--text)',
};

const badgeStyle = {
  display: 'inline-flex',
  padding: '0.15rem 0.5rem',
  borderRadius: '999px',
  background: 'var(--surface-2)',
  border: '1px solid var(--border)',
  fontSize: '0.75rem',
  fontWeight: 600,
  color: 'var(--text)',
};

const lockedBadgeStyle = {
  ...badgeStyle,
  color: 'var(--danger)',
  borderColor: 'var(--danger-border)',
  background: 'var(--danger-bg)',
};

const linkStyle = {
  color: 'var(--text)',
  fontWeight: 600,
  textDecoration: 'none',
};

const primaryButtonStyle = {
  borderRadius: '999px',
  border: 'none',
  padding: '0.55rem 1.1rem',
  background: 'var(--gradient-primary)',
  color: 'var(--text-on-brand)',
  fontWeight: 600,
  cursor: 'pointer',
  boxShadow: 'var(--shadow)',
};

const lockedStyle = {
  color: 'var(--danger)',
  fontWeight: 600,
  textDecoration: 'none',
};

const mutedStyle = {
  margin: 0,
  color: 'var(--muted)',
};

const formatBytes = (value: number) => {
  if (!value) return '0 B';
  if (value < 1024) return `${value} B`;
  const kb = value / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
};

export const getServerSideProps: GetServerSideProps<IncomingIntentDetailProps> = async (ctx) => {
  const result = await requireOrgContext(ctx);
  if (result.redirect) {
    return { redirect: result.redirect };
  }
  const intentId = typeof ctx.params?.id === 'string' ? ctx.params.id : 'intent';
  const payload = await fetchIncomingIntent(result.context!.cookie, intentId);
  return {
    props: {
      user: result.context!.user,
      org: result.context!.org,
      intentId,
      intent: payload?.intent ?? null,
      attachments: payload?.attachments ?? [],
    },
  };
};
