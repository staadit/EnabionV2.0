// Minimal stub so that optional @aws-sdk/client-s3 import does not break compilation
declare module '@aws-sdk/client-s3';
