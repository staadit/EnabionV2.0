
import Head from 'next/head';
import type { GetServerSideProps } from 'next';
import OrgShell from '../../../../components/OrgShell';
import { getXNavItems } from '../../../../lib/org-nav';
import { requireOrgContext, type OrgInfo, type OrgUser } from '../../../../lib/org-context';
import {
  createShareLink,
  listShareLinks,
  revokeShareLink,
  type ShareLink,
} from '../../../../lib/share-links';
import { useEffect, useMemo, useState } from 'react';
import { formatDateTime } from '../../../../lib/date-format';

type IntentTabProps = {
  user: OrgUser;
  org: OrgInfo;
  intentId: string;
  links: ShareLink[];
};

export default function Share({ user, org, intentId, links: initialLinks }: IntentTabProps) {
  const [links, setLinks] = useState(initialLinks);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [loadingList, setLoadingList] = useState(false);
  const activeLink = useMemo(() => findActiveShareLink(links), [links]);
  const ttlDays = activeLink ? computeTtlDays(activeLink.createdAt, activeLink.expiresAt) : null;
  const ttlLabel = ttlDays ? `${ttlDays} days` : 'set by server';

  useEffect(() => {
    const stored = window.localStorage.getItem(`share:url:${intentId}`);
    if (stored) {
      setShareUrl(stored);
    }
    // Always refresh list client-side to ensure we show history with session cookie.
    setLoadingList(true);
    listShareLinks(undefined, intentId)
      .then((items) => setLinks(items))
      .finally(() => setLoadingList(false));
  }, [intentId]);

  const handleCreate = async () => {
    setCreating(true);
    setError(null);
    try {
      const res = await createShareLink(undefined, intentId);
      if (!res) {
        setError('Failed to create share link');
        return;
      }
      const shareUrl = `${window.location.origin}/share/intent/${res.token}`;
      setShareUrl(shareUrl);
      window.localStorage.setItem(`share:url:${intentId}`, shareUrl);
      const refreshed = await listShareLinks(undefined, intentId);
      setLinks(refreshed);
    } catch {
      setError('Failed to create share link');
    } finally {
      setCreating(false);
    }
  };

  const handleRevoke = async (id: string) => {
    setError(null);
    const ok = await revokeShareLink(undefined, intentId, id);
    if (!ok) {
      setError('Failed to revoke link');
      return;
    }
    const refreshed = await listShareLinks(undefined, intentId);
    setLinks(refreshed);
  };

  return (
    <OrgShell
      user={user}
      org={org}
      title="Share"
      subtitle="Generate and manage L1 share links."
      navItems={getXNavItems(org.slug, 'intents')}
    >
      <Head>
        <title>{org.name} - Share</title>
      </Head>
      <div style={cardStyle}>
        <p style={{ marginTop: 0, fontWeight: 600 }}>Generate share link (L1-only)</p>
        <p style={{ margin: '0 0 1rem', color: 'var(--muted)' }}>
          Default TTL: <b>{ttlLabel}</b>. Creating a new link revokes the previous one.
        </p>
        <button style={primaryButton} onClick={handleCreate} disabled={creating}>
          {creating ? 'Generating...' : 'Generate share link'}
        </button>
        {error ? <p style={errorStyle}>{error}</p> : null}
        {shareUrl ? (
          <div style={tokenBox}>
            <div style={labelStyle}>Share URL</div>
            <code style={tokenValue}>{shareUrl}</code>
          </div>
        ) : null}
        {!shareUrl && links.length === 0 && !loadingList ? (
          <p style={mutedStyle}>Share URL was not created yet.</p>
        ) : null}
      </div>

      <div style={sectionStyle}>
        <h3 style={sectionTitleStyle}>Share links</h3>
        {links.length ? (
          <div style={tableCardStyle}>
            <table style={tableStyle}>
              <thead>
                <tr>
                  <th style={thStyle}>Created</th>
                  <th style={thStyle}>Expires</th>
                  <th style={thStyle}>Accesses</th>
                  <th style={thStyle}>Last access</th>
                  <th style={thStyle}>Status</th>
                  <th style={thStyle}>Action</th>
                </tr>
              </thead>
              <tbody>
                {links.map((link) => {
                  const revoked = Boolean(link.revokedAt);
                  const expired = new Date(link.expiresAt).getTime() < Date.now();
                  const status = revoked ? 'Revoked' : expired ? 'Expired' : 'Active';
                  return (
                    <tr key={link.id}>
                      <td style={tdStyle}>{formatDateTime(link.createdAt)}</td>
                      <td style={tdStyle}>{formatDateTime(link.expiresAt)}</td>
                      <td style={tdStyle}>{link.accessCount}</td>
                      <td style={tdStyle}>{link.lastAccessAt ? formatDateTime(link.lastAccessAt) : '-'}</td>
                      <td style={tdStyle}>{status}</td>
                      <td style={tdStyle}>
                        {!revoked && !expired ? (
                          <button style={textButton} onClick={() => handleRevoke(link.id)}>
                            Revoke
                          </button>
                        ) : (
                          <span style={mutedStyle}>-</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <p style={mutedStyle}>Share URL was not created yet.</p>
        )}
      </div>
    </OrgShell>
  );
}

const cardStyle = {
  padding: '1rem 1.25rem',
  borderRadius: '12px',
  border: '1px dashed var(--border)',
  background: 'var(--surface-2)',
  boxShadow: 'var(--shadow)',
};

const primaryButton = {
  borderRadius: '999px',
  border: 'none',
  padding: '0.55rem 1.1rem',
  background: 'var(--gradient-primary)',
  color: 'var(--text-on-brand)',
  fontWeight: 600,
  cursor: 'pointer',
  boxShadow: 'var(--shadow)',
};

const textButton = {
  border: 'none',
  background: 'none',
  color: 'var(--danger)',
  fontWeight: 600,
  cursor: 'pointer',
};

const tokenBox = {
  marginTop: '1rem',
  padding: '0.75rem 0.9rem',
  borderRadius: '10px',
  border: '1px solid var(--border)',
  background: 'var(--surface)',
  wordBreak: 'break-all' as const,
};

const tokenValue = {
  display: 'block',
  marginTop: '0.35rem',
};

const errorStyle = {
  marginTop: '0.75rem',
  color: 'var(--danger)',
  fontWeight: 600,
};

const sectionStyle = {
  marginTop: '2rem',
};

const sectionTitleStyle = {
  margin: '0 0 1rem',
  fontSize: '1.1rem',
  color: 'var(--text)',
};

const tableCardStyle = {
  borderRadius: '12px',
  border: '1px solid var(--border)',
  background: 'var(--surface)',
  overflow: 'hidden',
  boxShadow: 'var(--shadow)',
};

const tableStyle = {
  width: '100%',
  borderCollapse: 'collapse' as const,
};

const thStyle = {
  textAlign: 'left' as const,
  padding: '0.75rem 1rem',
  fontSize: '0.85rem',
  color: 'var(--muted)',
  borderBottom: '1px solid var(--border)',
};

const tdStyle = {
  padding: '0.75rem 1rem',
  borderBottom: '1px solid var(--border)',
  fontSize: '0.95rem',
  color: 'var(--text)',
};

const labelStyle = {
  fontSize: '0.7rem',
  letterSpacing: '0.08em',
  textTransform: 'uppercase' as const,
  color: 'var(--muted)',
};

const mutedStyle = {
  margin: 0,
  color: 'var(--muted)',
};

function findActiveShareLink(links: ShareLink[]) {
  const now = Date.now();
  return (
    links.find((link) => !link.revokedAt && new Date(link.expiresAt).getTime() > now) ?? null
  );
}

function computeTtlDays(createdAt: string, expiresAt: string) {
  const createdTime = new Date(createdAt).getTime();
  const expiresTime = new Date(expiresAt).getTime();
  if (Number.isNaN(createdTime) || Number.isNaN(expiresTime)) {
    return null;
  }
  const diffMs = Math.max(0, expiresTime - createdTime);
  if (!diffMs) {
    return null;
  }
  return Math.max(1, Math.ceil(diffMs / 86400000));
}

export const getServerSideProps: GetServerSideProps<IntentTabProps> = async (ctx) => {
  const result = await requireOrgContext(ctx);
  if (result.redirect) {
    return { redirect: result.redirect };
  }
  const intentId = typeof ctx.params?.id === 'string' ? ctx.params.id : 'intent';
  const { listShareLinksServer } = await import('../../../../lib/share-links.server');
  const links = await listShareLinksServer(ctx.req.headers.cookie, intentId);
  return {
    props: {
      user: result.context!.user,
      org: result.context!.org,
      intentId,
      links,
    },
  };
};
