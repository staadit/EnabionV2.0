export { default, getServerSideProps } from '../[token]';
