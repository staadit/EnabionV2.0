--
-- PostgreSQL database dump
--

\restrict XxJWdyNnoedAfIP6MEmdaW0zAUdpZagCiGWd4PJVnKx9MNcb3X6qh7CrdFyUjMr

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AttachmentSource; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AttachmentSource" AS ENUM (
    'email_ingest',
    'manual_upload',
    'export'
);


ALTER TYPE public."AttachmentSource" OWNER TO enabion;

--
-- Name: AvatarSuggestionDecision; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AvatarSuggestionDecision" AS ENUM (
    'ACCEPTED',
    'REJECTED'
);


ALTER TYPE public."AvatarSuggestionDecision" OWNER TO enabion;

--
-- Name: AvatarSuggestionFeedbackReasonCode; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AvatarSuggestionFeedbackReasonCode" AS ENUM (
    'HELPFUL_STRUCTURING',
    'TOO_GENERIC',
    'INCORRECT_ASSUMPTION',
    'MISSING_CONTEXT',
    'NOT_RELEVANT',
    'ALREADY_KNOWN',
    'OTHER'
);


ALTER TYPE public."AvatarSuggestionFeedbackReasonCode" OWNER TO enabion;

--
-- Name: AvatarSuggestionFeedbackSentiment; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AvatarSuggestionFeedbackSentiment" AS ENUM (
    'UP',
    'DOWN',
    'NEUTRAL'
);


ALTER TYPE public."AvatarSuggestionFeedbackSentiment" OWNER TO enabion;

--
-- Name: AvatarSuggestionKind; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AvatarSuggestionKind" AS ENUM (
    'missing_info',
    'question',
    'risk',
    'rewrite',
    'summary',
    'lead_qualification',
    'next_step'
);


ALTER TYPE public."AvatarSuggestionKind" OWNER TO enabion;

--
-- Name: AvatarSuggestionStatus; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AvatarSuggestionStatus" AS ENUM (
    'ISSUED',
    'ACCEPTED',
    'REJECTED'
);


ALTER TYPE public."AvatarSuggestionStatus" OWNER TO enabion;

--
-- Name: AvatarSuggestionSubjectType; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AvatarSuggestionSubjectType" AS ENUM (
    'INTENT',
    'USER',
    'ORG'
);


ALTER TYPE public."AvatarSuggestionSubjectType" OWNER TO enabion;

--
-- Name: AvatarType; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AvatarType" AS ENUM (
    'SYSTEM',
    'ORG_X',
    'INTENT_COACH'
);


ALTER TYPE public."AvatarType" OWNER TO enabion;

--
-- Name: BlobStorageDriver; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."BlobStorageDriver" AS ENUM (
    'local',
    's3'
);


ALTER TYPE public."BlobStorageDriver" OWNER TO enabion;

--
-- Name: ConfidentialityLevel; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."ConfidentialityLevel" AS ENUM (
    'L1',
    'L2',
    'L3'
);


ALTER TYPE public."ConfidentialityLevel" OWNER TO enabion;

--
-- Name: IntentRecipientRole; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."IntentRecipientRole" AS ENUM (
    'Y',
    'Z'
);


ALTER TYPE public."IntentRecipientRole" OWNER TO enabion;

--
-- Name: IntentRecipientStatus; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."IntentRecipientStatus" AS ENUM (
    'SENT',
    'ACCEPTED',
    'REVOKED'
);


ALTER TYPE public."IntentRecipientStatus" OWNER TO enabion;

--
-- Name: IntentSource; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."IntentSource" AS ENUM (
    'manual',
    'paste',
    'email'
);


ALTER TYPE public."IntentSource" OWNER TO enabion;

--
-- Name: IntentStage; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."IntentStage" AS ENUM (
    'NEW',
    'CLARIFY',
    'MATCH',
    'COMMIT',
    'WON',
    'LOST'
);


ALTER TYPE public."IntentStage" OWNER TO enabion;

--
-- Name: LeadFitBand; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."LeadFitBand" AS ENUM (
    'HIGH',
    'MEDIUM',
    'LOW',
    'NO_FIT'
);


ALTER TYPE public."LeadFitBand" OWNER TO enabion;

--
-- Name: LeadPriority; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."LeadPriority" AS ENUM (
    'P1',
    'P2',
    'P3'
);


ALTER TYPE public."LeadPriority" OWNER TO enabion;

--
-- Name: MatchFeedbackAction; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."MatchFeedbackAction" AS ENUM (
    'SHORTLIST',
    'HIDE',
    'NOT_RELEVANT'
);


ALTER TYPE public."MatchFeedbackAction" OWNER TO enabion;

--
-- Name: MatchFeedbackRating; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."MatchFeedbackRating" AS ENUM (
    'UP',
    'DOWN'
);


ALTER TYPE public."MatchFeedbackRating" OWNER TO enabion;

--
-- Name: NdaChannel; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."NdaChannel" AS ENUM (
    'ui',
    'api'
);


ALTER TYPE public."NdaChannel" OWNER TO enabion;

--
-- Name: NdaType; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."NdaType" AS ENUM (
    'MUTUAL'
);


ALTER TYPE public."NdaType" OWNER TO enabion;

--
-- Name: OrganizationStatus; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."OrganizationStatus" AS ENUM (
    'ACTIVE',
    'SUSPENDED'
);


ALTER TYPE public."OrganizationStatus" OWNER TO enabion;

--
-- Name: ProviderBudgetBucket; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."ProviderBudgetBucket" AS ENUM (
    'UNKNOWN',
    'LT_10K',
    'EUR_10K_50K',
    'EUR_50K_150K',
    'EUR_150K_500K',
    'GT_500K'
);


ALTER TYPE public."ProviderBudgetBucket" OWNER TO enabion;

--
-- Name: ProviderTeamSizeBucket; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."ProviderTeamSizeBucket" AS ENUM (
    'UNKNOWN',
    'SOLO',
    'TEAM_2_10',
    'TEAM_11_50',
    'TEAM_51_200',
    'TEAM_201_PLUS'
);


ALTER TYPE public."ProviderTeamSizeBucket" OWNER TO enabion;

--
-- Name: TrustScoreScope; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."TrustScoreScope" AS ENUM (
    'GLOBAL'
);


ALTER TYPE public."TrustScoreScope" OWNER TO enabion;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AiRateLimitWindow; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."AiRateLimitWindow" (
    id text NOT NULL,
    key text NOT NULL,
    "windowStart" timestamp(3) without time zone NOT NULL,
    count integer NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AiRateLimitWindow" OWNER TO enabion;

--
-- Name: Attachment; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Attachment" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text,
    source public."AttachmentSource" DEFAULT 'manual_upload'::public."AttachmentSource" NOT NULL,
    filename text NOT NULL,
    "blobId" text NOT NULL,
    "createdByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Attachment" OWNER TO enabion;

--
-- Name: AvatarSuggestion; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."AvatarSuggestion" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text,
    "coachRunId" text,
    "avatarType" public."AvatarType" NOT NULL,
    kind public."AvatarSuggestionKind" NOT NULL,
    "subjectType" public."AvatarSuggestionSubjectType" DEFAULT 'INTENT'::public."AvatarSuggestionSubjectType",
    "subjectId" text,
    "targetField" text,
    title text NOT NULL,
    "l1Text" text,
    "evidenceRef" text,
    "proposedPatch" jsonb,
    ctas jsonb,
    metadata jsonb,
    language text,
    status public."AvatarSuggestionStatus" DEFAULT 'ISSUED'::public."AvatarSuggestionStatus" NOT NULL,
    actionable boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "decidedAt" timestamp(3) without time zone,
    "decidedByUserId" text
);


ALTER TABLE public."AvatarSuggestion" OWNER TO enabion;

--
-- Name: AvatarSuggestionFeedback; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."AvatarSuggestionFeedback" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text NOT NULL,
    "suggestionId" text NOT NULL,
    "userId" text,
    decision public."AvatarSuggestionDecision" NOT NULL,
    rating integer,
    sentiment public."AvatarSuggestionFeedbackSentiment",
    "reasonCode" public."AvatarSuggestionFeedbackReasonCode",
    "commentL1" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AvatarSuggestionFeedback" OWNER TO enabion;

--
-- Name: Blob; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Blob" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "storageDriver" public."BlobStorageDriver" DEFAULT 'local'::public."BlobStorageDriver" NOT NULL,
    "objectKey" text NOT NULL,
    "sizeBytes" integer NOT NULL,
    sha256 character(64) NOT NULL,
    "contentType" text NOT NULL,
    confidentiality public."ConfidentialityLevel" DEFAULT 'L1'::public."ConfidentialityLevel" NOT NULL,
    encrypted boolean DEFAULT false NOT NULL,
    "encryptionAlg" text,
    "encryptionKeyId" text,
    "encryptionIvB64" text,
    "encryptionTagB64" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Blob" OWNER TO enabion;

--
-- Name: Event; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Event" (
    id text NOT NULL,
    "schemaVersion" integer NOT NULL,
    type text NOT NULL,
    "occurredAt" timestamp(3) without time zone NOT NULL,
    "recordedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "orgId" text NOT NULL,
    "actorUserId" text,
    "actorOrgId" text,
    "subjectType" text NOT NULL,
    "subjectId" text NOT NULL,
    "lifecycleStep" text DEFAULT 'CLARIFY'::text NOT NULL,
    "pipelineStage" text DEFAULT 'NEW'::text NOT NULL,
    channel text NOT NULL,
    "correlationId" text NOT NULL,
    payload jsonb NOT NULL
);


ALTER TABLE public."Event" OWNER TO enabion;

--
-- Name: Intent; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Intent" (
    id text NOT NULL,
    "intentNumber" integer NOT NULL,
    "intentName" text NOT NULL,
    "orgId" text NOT NULL,
    "createdByUserId" text NOT NULL,
    "ownerUserId" text,
    goal text NOT NULL,
    title text,
    client text,
    language text DEFAULT 'EN'::text NOT NULL,
    tech text[] DEFAULT ARRAY[]::text[],
    industry text[] DEFAULT ARRAY[]::text[],
    region text[] DEFAULT ARRAY[]::text[],
    "budgetBucket" public."ProviderBudgetBucket" DEFAULT 'UNKNOWN'::public."ProviderBudgetBucket" NOT NULL,
    context text,
    scope text,
    kpi text,
    risks text,
    "deadlineAt" timestamp(3) without time zone,
    stage public."IntentStage" DEFAULT 'NEW'::public."IntentStage" NOT NULL,
    "confidentialityLevel" public."ConfidentialityLevel" DEFAULT 'L1'::public."ConfidentialityLevel" NOT NULL,
    source public."IntentSource" DEFAULT 'manual'::public."IntentSource" NOT NULL,
    "sourceTextRaw" text,
    "sourceTextSha256" character(64),
    "sourceTextLength" integer,
    "aiAllowL2" boolean DEFAULT false NOT NULL,
    "aiAllowL2SetAt" timestamp(3) without time zone,
    "aiAllowL2SetByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastActivityAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Intent" OWNER TO enabion;

--
-- Name: IntentCoachRun; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."IntentCoachRun" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text NOT NULL,
    "createdByUserId" text,
    "summaryItems" jsonb NOT NULL,
    instructions text,
    "focusFields" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."IntentCoachRun" OWNER TO enabion;

--
-- Name: IntentRecipient; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."IntentRecipient" (
    id text NOT NULL,
    "intentId" text NOT NULL,
    "recipientOrgId" text NOT NULL,
    "senderOrgId" text NOT NULL,
    "recipientRole" public."IntentRecipientRole" DEFAULT 'Y'::public."IntentRecipientRole" NOT NULL,
    status public."IntentRecipientStatus" DEFAULT 'SENT'::public."IntentRecipientStatus" NOT NULL,
    "ndaRequestedAt" timestamp(3) without time zone,
    "ndaRequestedByOrgId" text,
    "ndaRequestedByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."IntentRecipient" OWNER TO enabion;

--
-- Name: IntentShareLink; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."IntentShareLink" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text NOT NULL,
    "createdByUserId" text NOT NULL,
    "tokenHashSha256" character(64) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone,
    "revokedByUserId" text,
    "lastAccessAt" timestamp(3) without time zone,
    "accessCount" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."IntentShareLink" OWNER TO enabion;

--
-- Name: Intent_intentNumber_seq; Type: SEQUENCE; Schema: public; Owner: enabion
--

CREATE SEQUENCE public."Intent_intentNumber_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Intent_intentNumber_seq" OWNER TO enabion;

--
-- Name: Intent_intentNumber_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: enabion
--

ALTER SEQUENCE public."Intent_intentNumber_seq" OWNED BY public."Intent"."intentNumber";


--
-- Name: MatchFeedback; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."MatchFeedback" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text NOT NULL,
    "matchListId" text NOT NULL,
    "candidateOrgId" text NOT NULL,
    "actorUserId" text,
    action public."MatchFeedbackAction" NOT NULL,
    rating public."MatchFeedbackRating" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MatchFeedback" OWNER TO enabion;

--
-- Name: MatchList; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."MatchList" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text NOT NULL,
    "algorithmVersion" text NOT NULL,
    "createdByUserId" text,
    "resultsJson" jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MatchList" OWNER TO enabion;

--
-- Name: NdaAcceptance; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."NdaAcceptance" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "counterpartyOrgId" text,
    "ndaType" public."NdaType" DEFAULT 'MUTUAL'::public."NdaType" NOT NULL,
    "ndaVersion" text NOT NULL,
    "enHashSha256" character(64) NOT NULL,
    "acceptedByUserId" text NOT NULL,
    "acceptedAt" timestamp(3) without time zone NOT NULL,
    language text NOT NULL,
    channel public."NdaChannel" NOT NULL,
    "typedName" text NOT NULL,
    "typedRole" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."NdaAcceptance" OWNER TO enabion;

--
-- Name: NdaDocument; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."NdaDocument" (
    id text NOT NULL,
    "ndaType" public."NdaType" DEFAULT 'MUTUAL'::public."NdaType" NOT NULL,
    "ndaVersion" text NOT NULL,
    "enMarkdown" text NOT NULL,
    "summaryPl" text,
    "summaryDe" text,
    "summaryNl" text,
    "enHashSha256" character(64) NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NdaDocument" OWNER TO enabion;

--
-- Name: OrgAvatarProfile; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."OrgAvatarProfile" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "profileVersion" text NOT NULL,
    markets jsonb,
    industries jsonb,
    "clientTypes" jsonb,
    "servicePortfolio" jsonb,
    "techStack" jsonb,
    "excludedSectors" jsonb,
    constraints jsonb,
    "createdByUserId" text,
    "updatedByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."OrgAvatarProfile" OWNER TO enabion;

--
-- Name: OrgLeadQualification; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."OrgLeadQualification" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text NOT NULL,
    "fitBand" public."LeadFitBand" NOT NULL,
    priority public."LeadPriority" NOT NULL,
    reasons jsonb,
    "createdByUserId" text,
    "updatedByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."OrgLeadQualification" OWNER TO enabion;

--
-- Name: Organization; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    status public."OrganizationStatus" DEFAULT 'ACTIVE'::public."OrganizationStatus" NOT NULL,
    "defaultLanguage" text DEFAULT 'EN'::text NOT NULL,
    "policyAiEnabled" boolean DEFAULT true NOT NULL,
    "policyShareLinksEnabled" boolean DEFAULT false NOT NULL,
    "policyEmailIngestEnabled" boolean DEFAULT false NOT NULL,
    "providerLanguages" text[] DEFAULT ARRAY[]::text[],
    "providerRegions" text[] DEFAULT ARRAY[]::text[],
    "providerTags" text[] DEFAULT ARRAY[]::text[],
    "providerBudgetBucket" public."ProviderBudgetBucket" DEFAULT 'UNKNOWN'::public."ProviderBudgetBucket" NOT NULL,
    "providerTeamSizeBucket" public."ProviderTeamSizeBucket" DEFAULT 'UNKNOWN'::public."ProviderTeamSizeBucket" NOT NULL,
    "trustScoreLatestId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Organization" OWNER TO enabion;

--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone
);


ALTER TABLE public."PasswordResetToken" OWNER TO enabion;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


ALTER TABLE public."Session" OWNER TO enabion;

--
-- Name: ThemePalette; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."ThemePalette" (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    "tokensJson" jsonb NOT NULL,
    "isGlobalDefault" boolean DEFAULT false NOT NULL,
    "createdByUserId" text,
    "updatedByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ThemePalette" OWNER TO enabion;

--
-- Name: ThemePaletteRevision; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."ThemePaletteRevision" (
    id text NOT NULL,
    "paletteId" text NOT NULL,
    revision integer NOT NULL,
    "tokensJson" jsonb NOT NULL,
    "createdByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ThemePaletteRevision" OWNER TO enabion;

--
-- Name: TrustScoreSnapshot; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."TrustScoreSnapshot" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "subjectOrgId" text NOT NULL,
    scope public."TrustScoreScope" DEFAULT 'GLOBAL'::public."TrustScoreScope" NOT NULL,
    "scoreOverall" integer NOT NULL,
    "scoreProfile" integer,
    "scoreResponsiveness" integer,
    "scoreBehaviour" integer,
    "statusLabel" text NOT NULL,
    "explanationPublic" jsonb,
    "explanationInternal" jsonb,
    "triggerReason" text,
    "actorUserId" text,
    "algorithmVersion" text NOT NULL,
    "computedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."TrustScoreSnapshot" OWNER TO enabion;

--
-- Name: User; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    "deactivatedAt" timestamp(3) without time zone,
    "passwordHash" text,
    "passwordUpdatedAt" timestamp(3) without time zone,
    "lastLoginAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."User" OWNER TO enabion;

--
-- Name: UserOnboardingState; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."UserOnboardingState" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "userId" text NOT NULL,
    version text NOT NULL,
    "currentStep" text,
    "completedSteps" jsonb,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserOnboardingState" OWNER TO enabion;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO enabion;

--
-- Name: Intent intentNumber; Type: DEFAULT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent" ALTER COLUMN "intentNumber" SET DEFAULT nextval('public."Intent_intentNumber_seq"'::regclass);


--
-- Data for Name: AiRateLimitWindow; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."AiRateLimitWindow" (id, key, "windowStart", count, "updatedAt") FROM stdin;
cmkmi162j001613o8ugv0nz9l	tenant:cmkmhjkg70000as8pwosymxt8:useCase:summary_internal	2026-01-20 11:16:00	1	2026-01-20 11:16:40.313
cmkmi162n001713o88ahxcgj7	user:cmkmhjkl60004as8parglk6ln:useCase:summary_internal	2026-01-20 11:16:00	1	2026-01-20 11:16:40.313
cmkmi1bs5001813o8yth509ce	tenant:cmkmhjkg70000as8pwosymxt8:useCase:intent_structuring	2026-01-20 11:16:00	1	2026-01-20 11:16:47.716
cmkmi1bs8001913o8xmvvwnfw	user:cmkmhjkl60004as8parglk6ln:useCase:intent_structuring	2026-01-20 11:16:00	1	2026-01-20 11:16:47.716
cmkmioq3h002t13o8zju04is2	tenant:cmkmhjkg70000as8pwosymxt8:useCase:summary_internal	2026-01-20 11:34:00	1	2026-01-20 11:34:59.356
cmkmioq3l002u13o894u5zrah	user:cmkmhjkl60004as8parglk6ln:useCase:summary_internal	2026-01-20 11:34:00	1	2026-01-20 11:34:59.356
cmkmiov81002v13o8w89l12ef	tenant:cmkmhjkg70000as8pwosymxt8:useCase:intent_structuring	2026-01-20 11:35:00	1	2026-01-20 11:35:06
cmkmiov86002w13o8541wd392	user:cmkmhjkl60004as8parglk6ln:useCase:intent_structuring	2026-01-20 11:35:00	1	2026-01-20 11:35:06
\.


--
-- Data for Name: Attachment; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Attachment" (id, "orgId", "intentId", source, filename, "blobId", "createdByUserId", "createdAt") FROM stdin;
\.


--
-- Data for Name: AvatarSuggestion; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."AvatarSuggestion" (id, "orgId", "intentId", "coachRunId", "avatarType", kind, "subjectType", "subjectId", "targetField", title, "l1Text", "evidenceRef", "proposedPatch", ctas, metadata, language, status, actionable, "createdAt", "decidedAt", "decidedByUserId") FROM stdin;
c1f0b3ec-2c3e-4f27-aba3-db184060549b	cmkmhjkg70000as8pwosymxt8	cmkmhjkp4000eas8pi99mtn41	\N	ORG_X	lead_qualification	INTENT	cmkmhjkp4000eas8pi99mtn41	\N	Organization fit suggestion	Fit LOW, priority P3.	\N	\N	\N	{"fitBand": "LOW", "matches": {"markets": [], "techStack": [], "industries": [], "clientTypes": [], "excludedSectors": [], "servicePortfolio": []}, "reasons": ["insufficient_signals"], "priority": "P3"}	EN	ISSUED	t	2026-01-20 11:16:10.867	\N	\N
f0db7a55-487f-499b-a6fb-04cef089f818	cmkmhjkg70000as8pwosymxt8	cmkmhjkpc000ias8p8gv2ihcx	\N	ORG_X	lead_qualification	INTENT	cmkmhjkpc000ias8p8gv2ihcx	\N	Organization fit suggestion	Fit LOW, priority P3.	\N	\N	\N	{"fitBand": "LOW", "matches": {"markets": [], "techStack": [], "industries": [], "clientTypes": [], "excludedSectors": [], "servicePortfolio": []}, "reasons": ["insufficient_signals"], "priority": "P3"}	EN	ISSUED	t	2026-01-20 11:16:10.879	\N	\N
ef92feb8-fb1f-4bbf-949c-99b17d8d95e8	cmkmhjkg70000as8pwosymxt8	cmkmhjkp8000gas8pnoxfandy	\N	ORG_X	lead_qualification	INTENT	cmkmhjkp8000gas8pnoxfandy	\N	Organization fit suggestion	Fit LOW, priority P3.	\N	\N	\N	{"fitBand": "LOW", "matches": {"markets": [], "techStack": [], "industries": [], "clientTypes": [], "excludedSectors": [], "servicePortfolio": []}, "reasons": ["insufficient_signals"], "priority": "P3"}	EN	ISSUED	t	2026-01-20 11:16:10.936	\N	\N
9a820c75-ea9e-49d3-8738-2f5dc5e35fca	cmkmhjkg70000as8pwosymxt8	cmkmhjkp0000cas8ph3q8rm5n	\N	ORG_X	lead_qualification	INTENT	cmkmhjkp0000cas8ph3q8rm5n	\N	Organization fit suggestion	Fit LOW, priority P3.	\N	\N	\N	{"fitBand": "LOW", "matches": {"markets": [], "techStack": [], "industries": [], "clientTypes": [], "excludedSectors": [], "servicePortfolio": []}, "reasons": ["insufficient_signals"], "priority": "P3"}	EN	ISSUED	t	2026-01-20 11:16:10.941	\N	\N
b2005ae9-0fab-448e-bf0c-d054929f112d	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	rewrite	INTENT	cmkmhjkou000aas8p3vlddk03	goal	Goal	Increase qualified inbound leads for logistics SaaS.	ai:intent_structuring	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
4e8ad080-c54c-4779-bc01-bb386b053c30	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	rewrite	INTENT	cmkmhjkou000aas8p3vlddk03	context	Context	Focus on targeted marketing strategies for logistics sector.	ai:intent_structuring	{"fields": {"context": "Focus on targeted marketing strategies for logistics sector."}}	\N	\N	EN	ISSUED	t	2026-01-20 11:16:47.705	\N	\N
6a414a78-8de8-406c-bdb9-dd881ed6e95e	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	rewrite	INTENT	cmkmhjkou000aas8p3vlddk03	scope	Scope	Expand outreach to small and medium-sized logistics companies.	ai:intent_structuring	{"fields": {"scope": "Expand outreach to small and medium-sized logistics companies."}}	\N	\N	EN	ISSUED	t	2026-01-20 11:16:47.705	\N	\N
5bac97b2-e419-4ee9-8b09-c1aa9d6b690a	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	rewrite	INTENT	cmkmhjkou000aas8p3vlddk03	kpi	KPIs	Track lead conversion rates and engagement metrics.	ai:intent_structuring	{"fields": {"kpi": "Track lead conversion rates and engagement metrics."}}	\N	\N	EN	ISSUED	t	2026-01-20 11:16:47.705	\N	\N
00011e57-bfdb-4af7-a5fc-a9d25c602589	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	rewrite	INTENT	cmkmhjkou000aas8p3vlddk03	risks	Risks	Potential market saturation and competition.	ai:intent_structuring	{"fields": {"risks": "Potential market saturation and competition."}}	\N	\N	EN	ISSUED	t	2026-01-20 11:16:47.705	\N	\N
1c8d1ecb-411e-4052-95ab-4b6cfadb8568	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	missing_info	INTENT	cmkmhjkou000aas8p3vlddk03	context	Missing Context	Add business background and key constraints.	field:context empty	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
8d5fa4c6-1113-48bc-926b-eece91606250	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	missing_info	INTENT	cmkmhjkou000aas8p3vlddk03	scope	Missing Scope	Add scope boundaries, deliverables, or exclusions.	field:scope empty	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
9e994c66-c738-4e28-8e16-001619259716	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	missing_info	INTENT	cmkmhjkou000aas8p3vlddk03	kpi	Missing KPIs	Add success metrics or measurable outcomes.	field:kpi empty	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
39d9a532-d74f-4b11-a639-9172adcb9598	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	missing_info	INTENT	cmkmhjkou000aas8p3vlddk03	risks	Missing Risks	Add known risks or dependencies that could affect delivery.	field:risks empty	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
a136aff2-5b14-484f-b1ac-21796c9fe454	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	missing_info	INTENT	cmkmhjkou000aas8p3vlddk03	deadlineAt	Missing Timeline	Add a target start date and deadline or timeline window.	field:deadlineAt empty	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
29f5a2a1-f241-4a06-9f66-9954edcbfa8e	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	question	INTENT	cmkmhjkou000aas8p3vlddk03	context	Clarify Context	What is the business context and background?	field:context empty	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
762cabb0-9f28-4acc-8775-641a01657bc9	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	question	INTENT	cmkmhjkou000aas8p3vlddk03	scope	Clarify Scope	What is in scope and what is explicitly out of scope?	field:scope empty	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
ee6a2f3c-6bb6-4ec5-89ca-1f769ba08bfd	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	question	INTENT	cmkmhjkou000aas8p3vlddk03	kpi	Clarify KPIs	Which KPIs define success for this intent?	field:kpi empty	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
b5efcfce-4cf9-4ec3-bac1-e239ce2e044d	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	question	INTENT	cmkmhjkou000aas8p3vlddk03	risks	Clarify Risks	What are the known risks or dependencies?	field:risks empty	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
b8d448ba-591b-4091-922f-6e2aff87cef5	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDHXZQH0X2ZTQKWPYQPEB1B	INTENT_COACH	question	INTENT	cmkmhjkou000aas8p3vlddk03	deadlineAt	Clarify Timeline	What is the target start date and deadline?	field:deadlineAt empty	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:16:47.705	\N	\N
95e1f43a-40a3-4e8c-ab20-69613e914028	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDJZH067YX6PZPTXA03KD0M	INTENT_COACH	rewrite	INTENT	cmkmhjkou000aas8p3vlddk03	goal	Goal	Increase qualified inbound leads for logistics SaaS.	ai:intent_structuring	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:35:05.991	\N	\N
b2a31006-7b41-486d-9653-0f0614ba3be0	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDJZH067YX6PZPTXA03KD0M	INTENT_COACH	rewrite	INTENT	cmkmhjkou000aas8p3vlddk03	context	Context	Attribution for paid channels needs to be established.	ai:intent_structuring	{"fields": {"context": "Attribution for paid channels needs to be established."}}	\N	\N	EN	ISSUED	t	2026-01-20 11:35:05.991	\N	\N
a8f091ec-1977-4f89-a42a-597c705758b4	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDJZH067YX6PZPTXA03KD0M	INTENT_COACH	rewrite	INTENT	cmkmhjkou000aas8p3vlddk03	scope	Scope	SEO, paid search, HubSpot automation, landing pages, funnel analytics.	ai:intent_structuring	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:35:05.991	\N	\N
b583050b-1b19-4ca7-9e1a-88128b12551e	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDJZH067YX6PZPTXA03KD0M	INTENT_COACH	rewrite	INTENT	cmkmhjkou000aas8p3vlddk03	kpi	KPIs	3x MQL volume, CAC -20%, trial-to-paid 2%+.	ai:intent_structuring	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:35:05.991	\N	\N
c3230871-e816-4a6d-8b18-b4191bf9f234	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	01KFDJZH067YX6PZPTXA03KD0M	INTENT_COACH	rewrite	INTENT	cmkmhjkou000aas8p3vlddk03	risks	Risks	Limited internal marketing resources; EU compliance constraints.	ai:intent_structuring	\N	\N	\N	EN	ISSUED	f	2026-01-20 11:35:05.991	\N	\N
34f7f415-3e5b-44a4-886a-c6bef61e7b59	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	\N	ORG_X	lead_qualification	INTENT	cmkmhjkou000aas8p3vlddk03	\N	Organization fit suggestion	Fit LOW, priority P3.	\N	\N	\N	{"fitBand": "LOW", "matches": {"markets": [], "techStack": [], "industries": [], "clientTypes": [], "excludedSectors": [], "servicePortfolio": []}, "reasons": ["insufficient_signals"], "decision": "REJECTED", "priority": "P3"}	EN	REJECTED	t	2026-01-20 11:16:10.895	2026-01-20 11:52:59.961	cmkmhjkl60004as8parglk6ln
f66c3221-cb11-4417-a74f-6b42178e3b4b	cmkmhq01b0001l0zlo8mzhe7v	cmkmk7mdp0011sp767z45gw2m	\N	ORG_X	lead_qualification	INTENT	cmkmk7mdp0011sp767z45gw2m	\N	Organization fit suggestion	Fit LOW, priority P3.	\N	\N	\N	{"fitBand": "LOW", "matches": {"markets": [], "techStack": [], "industries": [], "clientTypes": [], "excludedSectors": [], "servicePortfolio": []}, "reasons": ["insufficient_signals"], "priority": "P3"}	EN	ISSUED	t	2026-01-20 12:17:41.132	\N	\N
\.


--
-- Data for Name: AvatarSuggestionFeedback; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."AvatarSuggestionFeedback" (id, "orgId", "intentId", "suggestionId", "userId", decision, rating, sentiment, "reasonCode", "commentL1", "createdAt") FROM stdin;
\.


--
-- Data for Name: Blob; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Blob" (id, "orgId", "storageDriver", "objectKey", "sizeBytes", sha256, "contentType", confidentiality, encrypted, "encryptionAlg", "encryptionKeyId", "encryptionIvB64", "encryptionTagB64", "createdAt") FROM stdin;
\.


--
-- Data for Name: Event; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Event" (id, "schemaVersion", type, "occurredAt", "recordedAt", "orgId", "actorUserId", "actorOrgId", "subjectType", "subjectId", "lifecycleStep", "pipelineStage", channel, "correlationId", payload) FROM stdin;
01KFDHJVGRPWF021H3KMG9YTNX	1	USER_LOGGED_IN	2026-01-20 11:10:35.543	2026-01-20 11:10:35.544	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	\N	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	api	01KFDHJVGQFC0D4VZTE3NZEKJS	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkj80002as8pcub1p8ou", "sessionId": "cmkmhtclq0002zrnrsvz8szht", "payloadVersion": 1}
01KFDHT8C5QJ2VMAPCN3RH1328	1	USER_LOGGED_IN	2026-01-20 11:14:38.083	2026-01-20 11:14:38.085	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	\N	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	api	01KFDHT8C4D3EVNRDSCC7WRDK3	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkj80002as8pcub1p8ou", "sessionId": "cmkmhyjqz000213o8ik41nxke", "payloadVersion": 1}
01KFDHVAP1MAMYEKFPFWAEEEK4	1	USER_LOGGED_IN	2026-01-20 11:15:13.217	2026-01-20 11:15:13.217	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	\N	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	api	01KFDHVAP1G8TP7Q6HD89VQE3V	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkj80002as8pcub1p8ou", "sessionId": "cmkmhzaux000513o8ijwhl11u", "payloadVersion": 1}
01KFDHVGYCWGS37JY43BSQFGT5	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:19.627	2026-01-20 11:15:19.628	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHVGYB4Q9SA3ASMHYEE3HW	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 3, "payloadVersion": 1}
01KFDHVQG0ZB46Y54ZQ6PZT7DY	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:26.336	2026-01-20 11:15:26.336	cmkmhq01f0002l0zlsbq87413	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHVQG0YY468PVYT76XW5C0	{"action": "TENANT_VIEW", "targetId": "cmkmhq01f0002l0zlsbq87413", "targetType": "TENANT", "targetOrgId": "cmkmhq01f0002l0zlsbq87413", "payloadVersion": 1}
01KFDHVQGQDK12HHVM723V6EE5	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:26.359	2026-01-20 11:15:26.359	cmkmhq01f0002l0zlsbq87413	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHVQGQDZSAXCHT19MMBR5T	{"action": "TENANT_USERS_LIST", "targetId": "cmkmhq01f0002l0zlsbq87413", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmkmhq01f0002l0zlsbq87413", "payloadVersion": 1}
01KFDHVT7X3CY1A9DVEBMPB1J4	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:29.148	2026-01-20 11:15:29.149	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHVT7WWF3ESR8PT9WEBWMF	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 3, "payloadVersion": 1}
01KFDHVVEAVEMN64980FY9XDHN	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:30.378	2026-01-20 11:15:30.378	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHVVEA5M3KHEKERMBV487K	{"action": "TENANT_VIEW", "targetId": "cmkmhjkg70000as8pwosymxt8", "targetType": "TENANT", "targetOrgId": "cmkmhjkg70000as8pwosymxt8", "payloadVersion": 1}
01KFDHVVEHDSAFG1WS2GMK5D8G	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:30.384	2026-01-20 11:15:30.385	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHVVEGC4PH4W9N7QFY0QRB	{"action": "TENANT_USERS_LIST", "targetId": "cmkmhjkg70000as8pwosymxt8", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmkmhjkg70000as8pwosymxt8", "payloadVersion": 1}
01KFDHW1H65QWSBBEGE13BX8E2	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:36.614	2026-01-20 11:15:36.614	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHW1H6CYR8W1TT6W7J3NXB	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 3, "payloadVersion": 1}
01KFDHW2Q3GS93QBB2PS9PNC0A	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:37.827	2026-01-20 11:15:37.827	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHW2Q3M0JR2TWZG06CK4CJ	{"action": "TENANT_USERS_LIST", "targetId": "cmkmhq01b0001l0zlo8mzhe7v", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmkmhq01b0001l0zlo8mzhe7v", "payloadVersion": 1}
01KFDHW2QK9XRBG08M19J4RMRN	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:37.843	2026-01-20 11:15:37.843	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHW2QK3W7J1PQCFA1HAPTX	{"action": "TENANT_VIEW", "targetId": "cmkmhq01b0001l0zlo8mzhe7v", "targetType": "TENANT", "targetOrgId": "cmkmhq01b0001l0zlo8mzhe7v", "payloadVersion": 1}
01KFDHW7EDN8PN87DE8SAE4W16	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:42.668	2026-01-20 11:15:42.669	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHW7EC358W1Z4QK7VF75WF	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 3, "payloadVersion": 1}
01KFDHW8DR5Y68RY0QYWHK53WN	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:43.672	2026-01-20 11:15:43.672	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHW8DR3E15HGQ4BR6YY9WT	{"action": "TENANT_VIEW", "targetId": "cmkmhjkg70000as8pwosymxt8", "targetType": "TENANT", "targetOrgId": "cmkmhjkg70000as8pwosymxt8", "payloadVersion": 1}
01KFDHW8DZD5K7PA19Y209CSG1	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:15:43.678	2026-01-20 11:15:43.679	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDHW8DYF8GMTV4M2RH2XQN8	{"action": "TENANT_USERS_LIST", "targetId": "cmkmhjkg70000as8pwosymxt8", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmkmhjkg70000as8pwosymxt8", "payloadVersion": 1}
01KFDHWF9MHARQTZZM7N2ZBFGP	1	USER_LOGGED_OUT	2026-01-20 11:15:50.708	2026-01-20 11:15:50.708	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	\N	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	api	01KFDHWF9MW25NR9S07D35M7ZV	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkj80002as8pcub1p8ou", "sessionId": "cmkmhzaux000513o8ijwhl11u", "payloadVersion": 1}
01KFDHWQ4ABNJ1VJDC5SY6AXY1	1	USER_LOGGED_IN	2026-01-20 11:15:58.73	2026-01-20 11:15:58.73	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDHWQ4AYMMQ0VCWG6GVQ7XV	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmi09z7000813o8gi06z3y3", "payloadVersion": 1}
01KFDHX2ZZK90P6GQX4BAP3S17	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:10.879	2026-01-20 11:16:10.879	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkp4000eas8pi99mtn41	CLARIFY	NEW	ui	c1f0b3ec-2c3e-4f27-aba3-db184060549b	{"fitBand": "LOW", "intentId": "cmkmhjkp4000eas8pi99mtn41", "priority": "P3", "avatarType": "ORG_X", "suggestionId": "c1f0b3ec-2c3e-4f27-aba3-db184060549b", "payloadVersion": 1, "suggestionKind": "lead_qualification", "suggestionL1Text": "Fit LOW, priority P3."}
01KFDJNP0G1V78FY7JQCG6946E	1	INTENT_VIEWED	2026-01-20 11:29:36.784	2026-01-20 11:29:36.784	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDJNP0GCRBJPX62E41BA562	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDHX307GH7C0NEZNXVPG7NS	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:10.887	2026-01-20 11:16:10.887	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkpc000ias8p8gv2ihcx	CLARIFY	NEW	ui	f0db7a55-487f-499b-a6fb-04cef089f818	{"fitBand": "LOW", "intentId": "cmkmhjkpc000ias8p8gv2ihcx", "priority": "P3", "avatarType": "ORG_X", "suggestionId": "f0db7a55-487f-499b-a6fb-04cef089f818", "payloadVersion": 1, "suggestionKind": "lead_qualification", "suggestionL1Text": "Fit LOW, priority P3."}
01KFDHX321S90JTBYMCDXCADSR	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:10.945	2026-01-20 11:16:10.945	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkp8000gas8pnoxfandy	CLARIFY	NEW	ui	ef92feb8-fb1f-4bbf-949c-99b17d8d95e8	{"fitBand": "LOW", "intentId": "cmkmhjkp8000gas8pnoxfandy", "priority": "P3", "avatarType": "ORG_X", "suggestionId": "ef92feb8-fb1f-4bbf-949c-99b17d8d95e8", "payloadVersion": 1, "suggestionKind": "lead_qualification", "suggestionL1Text": "Fit LOW, priority P3."}
01KFDHX30MZKA4RASARVT2PHBW	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:10.9	2026-01-20 11:16:10.901	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	CLARIFY	NEW	ui	34f7f415-3e5b-44a4-886a-c6bef61e7b59	{"fitBand": "LOW", "intentId": "cmkmhjkou000aas8p3vlddk03", "priority": "P3", "avatarType": "ORG_X", "suggestionId": "34f7f415-3e5b-44a4-886a-c6bef61e7b59", "payloadVersion": 1, "suggestionKind": "lead_qualification", "suggestionL1Text": "Fit LOW, priority P3."}
01KFDHX324YH9M9KFK2GMRY2E3	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:10.948	2026-01-20 11:16:10.948	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkp0000cas8ph3q8rm5n	CLARIFY	NEW	ui	9a820c75-ea9e-49d3-8738-2f5dc5e35fca	{"fitBand": "LOW", "intentId": "cmkmhjkp0000cas8ph3q8rm5n", "priority": "P3", "avatarType": "ORG_X", "suggestionId": "9a820c75-ea9e-49d3-8738-2f5dc5e35fca", "payloadVersion": 1, "suggestionKind": "lead_qualification", "suggestionL1Text": "Fit LOW, priority P3."}
01KFDHX6NFTB876P3NPZBTR9ZG	1	INTENT_PIPELINE_STAGE_CHANGED	2026-01-20 11:16:14.633	2026-01-20 11:16:14.639	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkpc000ias8p8gv2ihcx	CLARIFY	CLARIFY	ui	01KFDHX6NFQ62FD2GXRGXDMEYH	{"toStage": "CLARIFY", "intentId": "cmkmhjkpc000ias8p8gv2ihcx", "fromStage": "NEW", "payloadVersion": 1}
01KFDHX6PZXER8BEVCA8CB9FGH	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:16:14.672	2026-01-20 11:16:14.687	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	TRUSTSCORE_SNAPSHOT	cmkmi0mab000n13o8g4bo817t	CLARIFY	NEW	system	01KFDHX6PG2PG1T8KM7WF6RJNG	{"orgId": "cmkmhjkg70000as8pwosymxt8", "reason": "INTENT_STAGE_CHANGED", "statusLabel": "Low trust / problematic history", "scoreOverall": 30, "scoreProfile": 14, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 14% complete", "Median response time: 168+h", "Pipeline hygiene: 0% intents with owner + final status"], "scoreResponsiveness": 20, "trustScoreSnapshotId": "cmkmi0mab000n13o8g4bo817t"}
01KFDHX825R6PNYVQEEEY2C60D	1	INTENT_PIPELINE_STAGE_CHANGED	2026-01-20 11:16:16.064	2026-01-20 11:16:16.069	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkp4000eas8pi99mtn41	MATCH_ALIGN	MATCH	ui	01KFDHX824AFQ9ZRKJWJ51ZTEQ	{"toStage": "MATCH", "intentId": "cmkmhjkp4000eas8pi99mtn41", "fromStage": "NEW", "payloadVersion": 1}
01KFDHX830JZJXAZKE5BPNQN35	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:16:16.088	2026-01-20 11:16:16.096	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	TRUSTSCORE_SNAPSHOT	cmkmi0ndn000q13o8n416uskc	CLARIFY	NEW	system	01KFDHX82RQVFBNY9EXHMRYGHJ	{"orgId": "cmkmhjkg70000as8pwosymxt8", "reason": "INTENT_STAGE_CHANGED", "statusLabel": "Low trust / problematic history", "scoreOverall": 30, "scoreProfile": 14, "previousScore": 30, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 14% complete", "Median response time: 168+h", "Pipeline hygiene: 0% intents with owner + final status"], "previousStatusLabel": "Low trust / problematic history", "scoreResponsiveness": 20, "trustScoreSnapshotId": "cmkmi0ndn000q13o8n416uskc"}
01KFDHX9N8G52101H3MK4CR4EZ	1	INTENT_PIPELINE_STAGE_CHANGED	2026-01-20 11:16:17.699	2026-01-20 11:16:17.704	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHX9N7QFMJ82GEG1XFKCAP	{"toStage": "COMMIT", "intentId": "cmkmhjkou000aas8p3vlddk03", "fromStage": "NEW", "payloadVersion": 1}
01KFDHX9P3DD0MHXMMT9468MRN	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:16:17.724	2026-01-20 11:16:17.731	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	TRUSTSCORE_SNAPSHOT	cmkmi0on2000t13o8sqbjziso	CLARIFY	NEW	system	01KFDHX9NWHK4JWN8K3Q2GYX4R	{"orgId": "cmkmhjkg70000as8pwosymxt8", "reason": "INTENT_STAGE_CHANGED", "statusLabel": "Neutral / standard", "scoreOverall": 50, "scoreProfile": 14, "previousScore": 30, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 14% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"], "previousStatusLabel": "Low trust / problematic history", "scoreResponsiveness": 100, "trustScoreSnapshotId": "cmkmi0on2000t13o8sqbjziso"}
01KFDHXVV9M45S1CSZKJ0DPS6F	1	INTENT_VIEWED	2026-01-20 11:16:36.329	2026-01-20 11:16:36.329	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXVV9QC1H4XZG4HT10G8T	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDHXZR2V7DK39VQS7Q234G3	1	AI_GATEWAY_REQUESTED	2026-01-20 11:16:40.322	2026-01-20 11:16:40.322	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	AI_GATEWAY	f29ece57-7d03-4981-a77e-4c750c168878	CLARIFY	NEW	system	f29ece57-7d03-4981-a77e-4c750c168878	{"model": "gpt-4o-mini", "userId": "cmkmhjkl60004as8parglk6ln", "useCase": "summary_internal", "tenantId": "cmkmhjkg70000as8pwosymxt8", "requestId": "f29ece57-7d03-4981-a77e-4c750c168878", "containsL2": false, "inputClass": "L1", "totalChars": 393, "contentHash": "02db87bb0dbb121fa0e919c054f72776d0db684780e6ebd4937f7a0c4c775f65", "messageCount": 2, "payloadVersion": 1}
01KFDHY6YM99AG1HGYS8SPQ2TN	1	AI_GATEWAY_SUCCEEDED	2026-01-20 11:16:47.7	2026-01-20 11:16:47.7	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	AI_GATEWAY	f29ece57-7d03-4981-a77e-4c750c168878	CLARIFY	NEW	system	f29ece57-7d03-4981-a77e-4c750c168878	{"model": "gpt-4o-mini-2024-07-18", "userId": "cmkmhjkl60004as8parglk6ln", "useCase": "summary_internal", "tenantId": "cmkmhjkg70000as8pwosymxt8", "latencyMs": 7374, "requestId": "f29ece57-7d03-4981-a77e-4c750c168878", "inputTokens": 103, "totalTokens": 317, "outputTokens": 214, "payloadVersion": 1}
01KFDHY6ZBASWR7M0EF2YV3GY1	1	AI_GATEWAY_REQUESTED	2026-01-20 11:16:47.723	2026-01-20 11:16:47.723	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	AI_GATEWAY	2d776c33-a55f-4628-8432-ce2372edc0bb	CLARIFY	NEW	system	2d776c33-a55f-4628-8432-ce2372edc0bb	{"model": "gpt-4o-mini", "userId": "cmkmhjkl60004as8parglk6ln", "useCase": "intent_structuring", "tenantId": "cmkmhjkg70000as8pwosymxt8", "requestId": "2d776c33-a55f-4628-8432-ce2372edc0bb", "containsL2": false, "inputClass": "L1", "totalChars": 528, "contentHash": "ac375ce2f214aa7987d660366d8b649aea6c8fb2c61483b47ddf8d12fc7f22d4", "messageCount": 2, "payloadVersion": 1}
01KFDM0G9ZVXB94W5A3WMKJWND	1	AVATAR_SUGGESTION_REJECTED	2026-01-20 11:52:59.961	2026-01-20 11:52:59.967	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	34f7f415-3e5b-44a4-886a-c6bef61e7b59	{"intentId": "cmkmhjkou000aas8p3vlddk03", "suggestionId": "34f7f415-3e5b-44a4-886a-c6bef61e7b59", "payloadVersion": 1}
01KFDHYCQ2HS7AVNKQRS17ZA21	1	AI_GATEWAY_SUCCEEDED	2026-01-20 11:16:53.602	2026-01-20 11:16:53.603	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	AI_GATEWAY	2d776c33-a55f-4628-8432-ce2372edc0bb	CLARIFY	NEW	system	2d776c33-a55f-4628-8432-ce2372edc0bb	{"model": "gpt-4o-mini-2024-07-18", "userId": "cmkmhjkl60004as8parglk6ln", "useCase": "intent_structuring", "tenantId": "cmkmhjkg70000as8pwosymxt8", "latencyMs": 5875, "requestId": "2d776c33-a55f-4628-8432-ce2372edc0bb", "inputTokens": 142, "totalTokens": 361, "outputTokens": 219, "payloadVersion": 1}
01KFDHYCRKS0G56QRT6MDRCA8S	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.651	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "b2005ae9-0fab-448e-bf0c-d054929f112d", "suggestionRef": "ai:intent_structuring", "payloadVersion": 1, "suggestionKind": "rewrite", "suggestionL1Text": "Increase qualified inbound leads for logistics SaaS."}
01KFDHYCRWM97NJCXAC8A0B983	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.66	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "4e8ad080-c54c-4779-bc01-bb386b053c30", "suggestionRef": "ai:intent_structuring", "payloadVersion": 1, "suggestionKind": "rewrite", "suggestionL1Text": "Focus on targeted marketing strategies for logistics sector."}
01KFDHYCS3HMCS143JS9CGZ4SH	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.667	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "6a414a78-8de8-406c-bdb9-dd881ed6e95e", "suggestionRef": "ai:intent_structuring", "payloadVersion": 1, "suggestionKind": "rewrite", "suggestionL1Text": "Expand outreach to small and medium-sized logistics companies."}
01KFDHYCSBDT5QVN199HCR20H7	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.675	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "5bac97b2-e419-4ee9-8b09-c1aa9d6b690a", "suggestionRef": "ai:intent_structuring", "payloadVersion": 1, "suggestionKind": "rewrite", "suggestionL1Text": "Track lead conversion rates and engagement metrics."}
01KFDHYCSJ2T4Y32HP3RFHJX8Z	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.683	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "00011e57-bfdb-4af7-a5fc-a9d25c602589", "suggestionRef": "ai:intent_structuring", "payloadVersion": 1, "suggestionKind": "rewrite", "suggestionL1Text": "Potential market saturation and competition."}
01KFDHYCSTP27N004JGR7WMCBW	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.69	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "1c8d1ecb-411e-4052-95ab-4b6cfadb8568", "suggestionRef": "field:context empty", "payloadVersion": 1, "suggestionKind": "missing_info", "suggestionL1Text": "Add business background and key constraints."}
01KFDHYCT2BMACQD033N0APCSZ	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.698	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "8d5fa4c6-1113-48bc-926b-eece91606250", "suggestionRef": "field:scope empty", "payloadVersion": 1, "suggestionKind": "missing_info", "suggestionL1Text": "Add scope boundaries, deliverables, or exclusions."}
01KFDHYCT9G5K26DVHP53594PT	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.705	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "9e994c66-c738-4e28-8e16-001619259716", "suggestionRef": "field:kpi empty", "payloadVersion": 1, "suggestionKind": "missing_info", "suggestionL1Text": "Add success metrics or measurable outcomes."}
01KFDHYCTHM565PXN2A8H9FFWN	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.713	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "39d9a532-d74f-4b11-a639-9172adcb9598", "suggestionRef": "field:risks empty", "payloadVersion": 1, "suggestionKind": "missing_info", "suggestionL1Text": "Add known risks or dependencies that could affect delivery."}
01KFDHYCTR7FV9Q3C34YY4NAAW	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.72	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "a136aff2-5b14-484f-b1ac-21796c9fe454", "suggestionRef": "field:deadlineAt empty", "payloadVersion": 1, "suggestionKind": "missing_info", "suggestionL1Text": "Add a target start date and deadline or timeline window."}
01KFDHYCV0GC9KF40QZSR3TJMJ	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.728	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "29f5a2a1-f241-4a06-9f66-9954edcbfa8e", "suggestionRef": "field:context empty", "payloadVersion": 1, "suggestionKind": "question", "suggestionL1Text": "What is the business context and background?"}
01KFDHYCV8TP94D8TWGM7RPBQQ	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.736	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "762cabb0-9f28-4acc-8775-641a01657bc9", "suggestionRef": "field:scope empty", "payloadVersion": 1, "suggestionKind": "question", "suggestionL1Text": "What is in scope and what is explicitly out of scope?"}
01KFDHZAH80MBH645G3DBFXKMW	1	MATCH_LIST_CREATED	2026-01-20 11:17:24.131	2026-01-20 11:17:24.136	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	MATCH_ALIGN	MATCH	ui	01KFDHZAH8K44F9MKPD1936NCE	{"intentId": "cmkmhjkou000aas8p3vlddk03", "matchListId": "cmkmi23vo001d13o82jkazh58", "topCandidates": [], "payloadVersion": 1, "algorithmVersion": "rule-v1"}
01KFDHYCVGBDGFQXQMBGDGVYRS	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.744	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "ee6a2f3c-6bb6-4ec5-89ca-1f769ba08bfd", "suggestionRef": "field:kpi empty", "payloadVersion": 1, "suggestionKind": "question", "suggestionL1Text": "Which KPIs define success for this intent?"}
01KFDHYCVQMHE2JWG1C8ZM9JVE	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.752	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "b5efcfce-4cf9-4ec3-bac1-e239ce2e044d", "suggestionRef": "field:risks empty", "payloadVersion": 1, "suggestionKind": "question", "suggestionL1Text": "What are the known risks or dependencies?"}
01KFDHYCVY3K85FKGQRC28BAJB	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:16:47.705	2026-01-20 11:16:53.759	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHXZQH0X2ZTQKWPYQPEB1B	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "b8d448ba-591b-4091-922f-6e2aff87cef5", "suggestionRef": "field:deadlineAt empty", "payloadVersion": 1, "suggestionKind": "question", "suggestionL1Text": "What is the target start date and deadline?"}
01KFDHZ7D24RKSXFWF7EMQ8YXV	1	INTENT_VIEWED	2026-01-20 11:17:20.93	2026-01-20 11:17:20.93	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDHZ7D112FCN3NAJPN60G9Y	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDHZAJ46TA7ZGCGATD9VFZB	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:17:24.157	2026-01-20 11:17:24.167	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	TRUSTSCORE_SNAPSHOT	cmkmi23wf001g13o8k7keull8	CLARIFY	NEW	system	01KFDHZAHXSJS6WXFRE867N4NH	{"orgId": "cmkmhjkg70000as8pwosymxt8", "reason": "MATCH_LIST_CREATED", "statusLabel": "Neutral / standard", "scoreOverall": 50, "scoreProfile": 14, "previousScore": 50, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 14% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"], "previousStatusLabel": "Neutral / standard", "scoreResponsiveness": 100, "trustScoreSnapshotId": "cmkmi23wf001g13o8k7keull8"}
01KFDJ4245SJCVYE009GQF5YYE	1	USER_LOGGED_IN	2026-01-20 11:19:59.365	2026-01-20 11:19:59.366	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	\N	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	api	01KFDJ42451E1YRDC15PZ2QRRE	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkj80002as8pcub1p8ou", "sessionId": "cmkmi5fnk001j13o8ux0dw9y4", "payloadVersion": 1}
01KFDJ6DD3NPFPCGJSFM3J5QBN	1	USER_LOGGED_OUT	2026-01-20 11:21:16.451	2026-01-20 11:21:16.451	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDJ6DD30XQXMSXXVTRVDFSP	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmi09z7000813o8gi06z3y3", "payloadVersion": 1}
01KFDJ6HEY4RX85K3YG6NG7ZPY	1	USER_LOGGED_IN	2026-01-20 11:21:20.605	2026-01-20 11:21:20.606	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	\N	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	api	01KFDJ6HEX55KGDVGZAQNYAHEW	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkj80002as8pcub1p8ou", "sessionId": "cmkmi76c8001m13o8ifnim1ab", "payloadVersion": 1}
01KFDJ6SVVB8KEF0KHASTVWPWF	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:21:29.211	2026-01-20 11:21:29.211	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDJ6SVVGAW8BPFN9WCPYYKS	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 3, "payloadVersion": 1}
01KFDJ6W48GZFXA0AX4N96HQHZ	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:21:31.528	2026-01-20 11:21:31.528	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDJ6W48FQEF6EZP14WWTS00	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 1, "payloadVersion": 1}
01KFDJ70F74FH65WJJ5QHZQDZS	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:21:35.975	2026-01-20 11:21:35.975	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDJ70F74KPXDQVVZ9T4445M	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 1, "payloadVersion": 1}
01KFDJ73ZKY6CJDJEMQZG1J39J	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:21:39.571	2026-01-20 11:21:39.571	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDJ73ZK5RWJ5EBPF80AJJDE	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 3, "payloadVersion": 1}
01KFDJ75N4A01WZJB3AH28FFFG	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:21:41.283	2026-01-20 11:21:41.284	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDJ75N38QJ1S6B95DC5J3X5	{"action": "TENANT_VIEW", "targetId": "cmkmhjkg70000as8pwosymxt8", "targetType": "TENANT", "targetOrgId": "cmkmhjkg70000as8pwosymxt8", "payloadVersion": 1}
01KFDJ75NQY6VX1BZAEBYH2FCH	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:21:41.302	2026-01-20 11:21:41.303	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDJ75NP9EMA0EYNXVHPDTFK	{"action": "TENANT_USERS_LIST", "targetId": "cmkmhjkg70000as8pwosymxt8", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmkmhjkg70000as8pwosymxt8", "payloadVersion": 1}
01KFDJ795KT301WWYFHXE3YDXY	1	PLATFORM_ADMIN_AUDIT	2026-01-20 11:21:44.882	2026-01-20 11:21:44.883	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	system	01KFDJ795JRQQQQ1E6M45HSN5M	{"action": "USER_VIEW", "targetId": "cmkmhjkj80002as8pcub1p8ou", "targetType": "USER", "targetOrgId": "cmkmhjkg70000as8pwosymxt8", "targetUserId": "cmkmhjkj80002as8pcub1p8ou", "payloadVersion": 1}
01KFDJ7K7WDSADS515ABV57TMD	1	USER_LOGGED_OUT	2026-01-20 11:21:55.195	2026-01-20 11:21:55.196	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	\N	USER	cmkmhjkj80002as8pcub1p8ou	CLARIFY	NEW	api	01KFDJ7K7VNJ2QM7355AQ3VE28	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkj80002as8pcub1p8ou", "sessionId": "cmkmi76c8001m13o8ifnim1ab", "payloadVersion": 1}
01KFDJ9KQBJ0NXJEJHE65E9TEY	1	USER_LOGGED_IN	2026-01-20 11:23:01.226	2026-01-20 11:23:01.227	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDJ9KQA9NYK92J3D4EX2KNH	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmi9bz7001u13o8yub7n8yg", "payloadVersion": 1}
01KFDJEWK5PW0ZXJA31JWCV5FX	1	INTENT_VIEWED	2026-01-20 11:25:54.149	2026-01-20 11:25:54.149	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDJEWK5VVBFT1Y4PHVXW23J	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDJF3FQSRRBC8M1NS5FNX3Y	1	MATCH_LIST_CREATED	2026-01-20 11:26:01.2	2026-01-20 11:26:01.207	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	MATCH_ALIGN	MATCH	ui	01KFDJF3FQF1CV2GM0MADQT18H	{"intentId": "cmkmhjkou000aas8p3vlddk03", "matchListId": "cmkmid6up001y13o80axzmb9q", "topCandidates": [], "payloadVersion": 1, "algorithmVersion": "rule-v1"}
01KFDJF3HYSSBHGMECGHXCSF49	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:26:01.265	2026-01-20 11:26:01.278	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	TRUSTSCORE_SNAPSHOT	cmkmid6wl002113o8bbm00scz	CLARIFY	NEW	system	01KFDJF3HHB64RZ56XZMWXTBEP	{"orgId": "cmkmhjkg70000as8pwosymxt8", "reason": "MATCH_LIST_CREATED", "statusLabel": "Neutral / standard", "scoreOverall": 50, "scoreProfile": 14, "previousScore": 50, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 14% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"], "previousStatusLabel": "Neutral / standard", "scoreResponsiveness": 100, "trustScoreSnapshotId": "cmkmid6wl002113o8bbm00scz"}
01KFDJF7499B8K6CQ49FEYQJYW	1	INTENT_VIEWED	2026-01-20 11:26:04.937	2026-01-20 11:26:04.937	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkp4000eas8pi99mtn41	MATCH_ALIGN	MATCH	ui	01KFDJF74831E59K7BMRS8PC7V	{"intentId": "cmkmhjkp4000eas8pi99mtn41", "viewContext": "owner", "payloadVersion": 1}
01KFDJKCHKREP8FTKHNHMF3QGQ	1	INTENT_VIEWED	2026-01-20 11:28:21.555	2026-01-20 11:28:21.555	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDJKCHK73NT265PGQXC9751	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDJFAP8F64HRNEKSDSH6ZBF	1	MATCH_LIST_CREATED	2026-01-20 11:26:08.58	2026-01-20 11:26:08.584	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkp4000eas8pi99mtn41	MATCH_ALIGN	MATCH	ui	01KFDJFAP8JRRBN7FV4X4E6VWM	{"intentId": "cmkmhjkp4000eas8pi99mtn41", "matchListId": "cmkmidcjp002513o8h3c4tbf3", "topCandidates": [], "payloadVersion": 1, "algorithmVersion": "rule-v1"}
01KFDJFEBJM0ESM9V1F1NA1G3D	1	INTENT_VIEWED	2026-01-20 11:26:12.338	2026-01-20 11:26:12.339	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkpc000ias8p8gv2ihcx	CLARIFY	CLARIFY	ui	01KFDJFEBJPEJ0HNDGP8YK8G53	{"intentId": "cmkmhjkpc000ias8p8gv2ihcx", "viewContext": "owner", "payloadVersion": 1}
01KFDJFAQ1RX2NWTJHXFQKBV20	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:26:08.603	2026-01-20 11:26:08.609	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	TRUSTSCORE_SNAPSHOT	cmkmidckd002813o8kk6v2oqj	CLARIFY	NEW	system	01KFDJFAPV3VMRV0MCJ10SWKYF	{"orgId": "cmkmhjkg70000as8pwosymxt8", "reason": "MATCH_LIST_CREATED", "statusLabel": "Neutral / standard", "scoreOverall": 50, "scoreProfile": 14, "previousScore": 50, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 14% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"], "previousStatusLabel": "Neutral / standard", "scoreResponsiveness": 100, "trustScoreSnapshotId": "cmkmidckd002813o8kk6v2oqj"}
01KFDJFKDG2DMJFQCV8V7W94F4	1	MATCH_LIST_CREATED	2026-01-20 11:26:17.515	2026-01-20 11:26:17.52	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkpc000ias8p8gv2ihcx	MATCH_ALIGN	MATCH	ui	01KFDJFKDGJMA06NDXHBRZGJ9K	{"intentId": "cmkmhjkpc000ias8p8gv2ihcx", "matchListId": "cmkmidjfw002c13o8vtiwoh08", "topCandidates": [], "payloadVersion": 1, "algorithmVersion": "rule-v1"}
01KFDJFKF4GW6YGG35HGTJBB6D	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:26:17.565	2026-01-20 11:26:17.573	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	TRUSTSCORE_SNAPSHOT	cmkmidjhb002f13o8ls0qexcg	CLARIFY	NEW	system	01KFDJFKEXE423QBKS0M2Y47YW	{"orgId": "cmkmhjkg70000as8pwosymxt8", "reason": "MATCH_LIST_CREATED", "statusLabel": "Neutral / standard", "scoreOverall": 50, "scoreProfile": 14, "previousScore": 50, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 14% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"], "previousStatusLabel": "Neutral / standard", "scoreResponsiveness": 100, "trustScoreSnapshotId": "cmkmidjhb002f13o8ls0qexcg"}
01KFDJYGW48TJ8CB1H3RZQ86M2	1	INTENT_VIEWED	2026-01-20 11:34:26.436	2026-01-20 11:34:26.437	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDJYGW4N2H9P9PWYH8Y8FNK	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDJYKK892NXCSBBP356WG7M	1	MATCH_LIST_CREATED	2026-01-20 11:34:29.215	2026-01-20 11:34:29.224	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	MATCH_ALIGN	MATCH	ui	01KFDJYKK8GXEMHNRYFYBJCDA3	{"intentId": "cmkmhjkou000aas8p3vlddk03", "matchListId": "cmkmio2ua002n13o8ogon1gf2", "topCandidates": ["cmkmhq01b0001l0zlo8mzhe7v", "cmkmhq01f0002l0zlsbq87413"], "payloadVersion": 1, "algorithmVersion": "rule-v1"}
01KFDJYKMYNQXSC5T8GBTXCM3D	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:34:29.269	2026-01-20 11:34:29.278	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	TRUSTSCORE_SNAPSHOT	cmkmio2vr002q13o86nsst6o9	CLARIFY	NEW	system	01KFDJYKMN7JW2C5WHFV27P2F8	{"orgId": "cmkmhjkg70000as8pwosymxt8", "reason": "MATCH_LIST_CREATED", "statusLabel": "Neutral / standard", "scoreOverall": 55, "scoreProfile": 50, "previousScore": 50, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 50% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"], "previousStatusLabel": "Neutral / standard", "scoreResponsiveness": 100, "trustScoreSnapshotId": "cmkmio2vr002q13o86nsst6o9"}
01KFDJZ9WPYFGH3TRWME1E52P8	1	INTENT_VIEWED	2026-01-20 11:34:52.054	2026-01-20 11:34:52.054	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDJZ9WPTQB050AH7HGWQM8J	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDJZH14SR5GZRXN0R2A0E6P	1	AI_GATEWAY_REQUESTED	2026-01-20 11:34:59.364	2026-01-20 11:34:59.364	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	AI_GATEWAY	43a48d0a-1760-4119-a4c0-83d5f4bb28a3	CLARIFY	NEW	system	43a48d0a-1760-4119-a4c0-83d5f4bb28a3	{"model": "gpt-4o-mini", "userId": "cmkmhjkl60004as8parglk6ln", "useCase": "summary_internal", "tenantId": "cmkmhjkg70000as8pwosymxt8", "requestId": "43a48d0a-1760-4119-a4c0-83d5f4bb28a3", "containsL2": false, "inputClass": "L1", "totalChars": 709, "contentHash": "cdb35b047068358bf915d1c3297f4a601490e7662bc37f1b304c3100d48be8ae", "messageCount": 2, "payloadVersion": 1}
01KFDJZQG1TWQVJTQSGBXHND40	1	AI_GATEWAY_SUCCEEDED	2026-01-20 11:35:05.985	2026-01-20 11:35:05.985	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	AI_GATEWAY	43a48d0a-1760-4119-a4c0-83d5f4bb28a3	CLARIFY	NEW	system	43a48d0a-1760-4119-a4c0-83d5f4bb28a3	{"model": "gpt-4o-mini-2024-07-18", "userId": "cmkmhjkl60004as8parglk6ln", "useCase": "summary_internal", "tenantId": "cmkmhjkg70000as8pwosymxt8", "latencyMs": 6616, "requestId": "43a48d0a-1760-4119-a4c0-83d5f4bb28a3", "inputTokens": 187, "totalTokens": 403, "outputTokens": 216, "payloadVersion": 1}
01KFDJZQGSGK301J7770Y83NH8	1	AI_GATEWAY_REQUESTED	2026-01-20 11:35:06.009	2026-01-20 11:35:06.009	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	AI_GATEWAY	b02213e4-585f-4ffe-af5d-f92eba74d04e	CLARIFY	NEW	system	b02213e4-585f-4ffe-af5d-f92eba74d04e	{"model": "gpt-4o-mini", "userId": "cmkmhjkl60004as8parglk6ln", "useCase": "intent_structuring", "tenantId": "cmkmhjkg70000as8pwosymxt8", "requestId": "b02213e4-585f-4ffe-af5d-f92eba74d04e", "containsL2": false, "inputClass": "L1", "totalChars": 844, "contentHash": "dad2feee731364a2fe768c9e8f7cc516f5196e20ea8af2f16fbd485646876c01", "messageCount": 2, "payloadVersion": 1}
01KFDJZWP330VMFCC5D2D7QEZZ	1	AI_GATEWAY_SUCCEEDED	2026-01-20 11:35:11.299	2026-01-20 11:35:11.299	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	AI_GATEWAY	b02213e4-585f-4ffe-af5d-f92eba74d04e	CLARIFY	NEW	system	b02213e4-585f-4ffe-af5d-f92eba74d04e	{"model": "gpt-4o-mini-2024-07-18", "userId": "cmkmhjkl60004as8parglk6ln", "useCase": "intent_structuring", "tenantId": "cmkmhjkg70000as8pwosymxt8", "latencyMs": 5281, "requestId": "b02213e4-585f-4ffe-af5d-f92eba74d04e", "inputTokens": 226, "totalTokens": 371, "outputTokens": 145, "payloadVersion": 1}
01KFDJZWPTCQV83W1936WCHNZR	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:35:05.991	2026-01-20 11:35:11.322	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDJZH067YX6PZPTXA03KD0M	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "95e1f43a-40a3-4e8c-ab20-69613e914028", "suggestionRef": "ai:intent_structuring", "payloadVersion": 1, "suggestionKind": "rewrite", "suggestionL1Text": "Increase qualified inbound leads for logistics SaaS."}
01KFDJZWQ5TSDBSPJS86Y3V1XJ	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:35:05.991	2026-01-20 11:35:11.334	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDJZH067YX6PZPTXA03KD0M	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "b2a31006-7b41-486d-9653-0f0614ba3be0", "suggestionRef": "ai:intent_structuring", "payloadVersion": 1, "suggestionKind": "rewrite", "suggestionL1Text": "Attribution for paid channels needs to be established."}
01KFDJZWQE3KKTA49PB2F7SY94	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:35:05.991	2026-01-20 11:35:11.342	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDJZH067YX6PZPTXA03KD0M	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "a8f091ec-1977-4f89-a42a-597c705758b4", "suggestionRef": "ai:intent_structuring", "payloadVersion": 1, "suggestionKind": "rewrite", "suggestionL1Text": "SEO, paid search, HubSpot automation, landing pages, funnel analytics."}
01KFDJZWQPC522MZ90MVX43K6Q	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:35:05.991	2026-01-20 11:35:11.35	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDJZH067YX6PZPTXA03KD0M	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "b583050b-1b19-4ca7-9e1a-88128b12551e", "suggestionRef": "ai:intent_structuring", "payloadVersion": 1, "suggestionKind": "rewrite", "suggestionL1Text": "3x MQL volume, CAC -20%, trial-to-paid 2%+."}
01KFDJZWQY749PRGDX74D5NGE7	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 11:35:05.991	2026-01-20 11:35:11.358	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDJZH067YX6PZPTXA03KD0M	{"intentId": "cmkmhjkou000aas8p3vlddk03", "avatarType": "INTENT_COACH", "suggestionId": "c3230871-e816-4a6d-8b18-b4191bf9f234", "suggestionRef": "ai:intent_structuring", "payloadVersion": 1, "suggestionKind": "rewrite", "suggestionL1Text": "Limited internal marketing resources; EU compliance constraints."}
01KFDK093V5KRV09DCJE5S1ENP	1	INTENT_VIEWED	2026-01-20 11:35:24.027	2026-01-20 11:35:24.027	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkp4000eas8pi99mtn41	MATCH_ALIGN	MATCH	ui	01KFDK093VA5DV1J9K7J8H5FVS	{"intentId": "cmkmhjkp4000eas8pi99mtn41", "viewContext": "owner", "payloadVersion": 1}
01KFDK0CHAJ8PAACBF5FYF75ZT	1	MATCH_LIST_CREATED	2026-01-20 11:35:27.525	2026-01-20 11:35:27.53	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkp4000eas8pi99mtn41	MATCH_ALIGN	MATCH	ui	01KFDK0CHA6DCMPYKM51171YQD	{"intentId": "cmkmhjkp4000eas8pi99mtn41", "matchListId": "cmkmipbty003013o8fb5cc6dz", "topCandidates": ["cmkmhq01b0001l0zlo8mzhe7v", "cmkmhq01f0002l0zlsbq87413"], "payloadVersion": 1, "algorithmVersion": "rule-v1"}
01KFDK3VRYFCNHT4MG4S0DD3JC	1	INTENT_VIEWED	2026-01-20 11:37:21.438	2026-01-20 11:37:21.438	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDK3VRXSTQ418JXZ1A35T2H	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDK59HAPGX8KB9591R44DTN	1	MATCH_FEEDBACK_RECORDED	2026-01-20 11:38:08.294	2026-01-20 11:38:08.298	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	MATCH_ALIGN	MATCH	ui	01KFDK59HAV1PF3PDTFWEJZJ97	{"action": "SHORTLIST", "rating": "up", "intentId": "cmkmhjkou000aas8p3vlddk03", "matchListId": "cmkmio2ua002n13o8ogon1gf2", "candidateOrgId": "cmkmhq01b0001l0zlo8mzhe7v", "payloadVersion": 1, "candidateOrgName": "Enabion Dev User2", "candidateOrgSlug": "enabion-dev-user2"}
01KFDK5K7FYHQRSACP98D51N84	1	MATCH_LIST_CREATED	2026-01-20 11:38:18.218	2026-01-20 11:38:18.223	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	MATCH_ALIGN	MATCH	ui	01KFDK5K7FF4329MWM8J7NR06F	{"intentId": "cmkmhjkou000aas8p3vlddk03", "matchListId": "cmkmiszjg003913o84e9jxrld", "topCandidates": ["cmkmhq01b0001l0zlo8mzhe7v", "cmkmhq01f0002l0zlsbq87413"], "payloadVersion": 1, "algorithmVersion": "rule-v1"}
01KFDK73RD45DX83QJG95P8F6G	1	INTENT_VIEWED	2026-01-20 11:39:07.917	2026-01-20 11:39:07.917	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDK73RDP12ZDVHMEVT2WYBX	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDK0CJ1K7529MH06TGVNC34	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:35:27.547	2026-01-20 11:35:27.553	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	TRUSTSCORE_SNAPSHOT	cmkmipbuk003313o8dizxqbn0	CLARIFY	NEW	system	01KFDK0CHVS4HBRE9MKD04DH32	{"orgId": "cmkmhjkg70000as8pwosymxt8", "reason": "MATCH_LIST_CREATED", "statusLabel": "Neutral / standard", "scoreOverall": 55, "scoreProfile": 50, "previousScore": 55, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 50% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"], "previousStatusLabel": "Neutral / standard", "scoreResponsiveness": 100, "trustScoreSnapshotId": "cmkmipbuk003313o8dizxqbn0"}
01KFDK5K8132M0F32FAPRZZ6P0	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:38:18.237	2026-01-20 11:38:18.241	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	TRUSTSCORE_SNAPSHOT	cmkmiszjy003c13o89kh0uq5v	CLARIFY	NEW	system	01KFDK5K7XYR7226B2031C9RQS	{"orgId": "cmkmhjkg70000as8pwosymxt8", "reason": "MATCH_LIST_CREATED", "statusLabel": "Neutral / standard", "scoreOverall": 55, "scoreProfile": 50, "previousScore": 55, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 50% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"], "previousStatusLabel": "Neutral / standard", "scoreResponsiveness": 100, "trustScoreSnapshotId": "cmkmiszjy003c13o89kh0uq5v"}
01KFDKH43Z92WP8QGKGZCQA8EB	1	USER_LOGGED_OUT	2026-01-20 11:44:35.967	2026-01-20 11:44:35.968	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDKH43Z7N2SSZ1TYPVG6P8A	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmi9bz7001u13o8yub7n8yg", "payloadVersion": 1}
01KFDKH68MR6Y2FSJMNYMC00TA	1	USER_LOGGED_IN	2026-01-20 11:44:38.164	2026-01-20 11:44:38.164	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDKH68MDC5ZWTS9HBRX33FQ	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmj14pa0002sp76gx2zl70n", "payloadVersion": 1}
01KFDKHR7MW4M5FXWW992CJCTJ	1	USER_LOGGED_OUT	2026-01-20 11:44:56.563	2026-01-20 11:44:56.564	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDKHR7KWDFXNDGC6S5SGEXG	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmj14pa0002sp76gx2zl70n", "payloadVersion": 1}
01KFDKHTNB494D266CB9AQTNMD	1	USER_LOGGED_IN	2026-01-20 11:44:59.051	2026-01-20 11:44:59.052	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDKHTNBD02D4XH7ZPJPD0S4	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmj1ktj0005sp76nopvknci", "payloadVersion": 1}
01KFDKK9GF3NZD90Q4KNFD7QYT	1	USER_LOGGED_OUT	2026-01-20 11:45:47.022	2026-01-20 11:45:47.023	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDKK9GEYEJQJR0C8WFRDXCA	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmj1ktj0005sp76nopvknci", "payloadVersion": 1}
01KFDKKC9Y0WYQ8PFP5DSSHHJ8	1	USER_LOGGED_IN	2026-01-20 11:45:49.886	2026-01-20 11:45:49.887	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDKKC9YTF786K2VVFDQFKRK	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmj2o1m0008sp761hgxp30w", "payloadVersion": 1}
01KFDKKDTS67HCEEAD38WVF65Q	1	INTENT_VIEWED	2026-01-20 11:45:51.449	2026-01-20 11:45:51.449	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDKKDTREQA8MMENGRNNRR7J	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDKKQH2AV43H3C1HXGZP11Y	1	USER_LOGGED_OUT	2026-01-20 11:46:01.378	2026-01-20 11:46:01.379	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDKKQH2JDS5V5257CRE169C	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmj2o1m0008sp761hgxp30w", "payloadVersion": 1}
01KFDKKXNP57T7GHBJ189G5728	1	USER_LOGGED_IN	2026-01-20 11:46:07.669	2026-01-20 11:46:07.67	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkmt0006as8pffhi7qej	\N	USER	cmkmhjkmt0006as8pffhi7qej	CLARIFY	NEW	api	01KFDKKXNNQXS79GBX830EP4FN	{"orgId": "cmkmhq01b0001l0zlo8mzhe7v", "userId": "cmkmhjkmt0006as8pffhi7qej", "sessionId": "cmkmj31rj000dsp76imit3d2l", "payloadVersion": 1}
01KFDKM56AGCYWA2K4NQYPXA4R	1	TRUSTSCORE_RECALCULATED	2026-01-20 11:46:15.359	2026-01-20 11:46:15.37	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkmt0006as8pffhi7qej	cmkmhq01b0001l0zlo8mzhe7v	TRUSTSCORE_SNAPSHOT	cmkmj37pe000gsp76sw36rsjm	CLARIFY	NEW	system	01KFDKM55Z264AWNXDJ2G06CJC	{"orgId": "cmkmhq01b0001l0zlo8mzhe7v", "reason": "INITIAL", "statusLabel": "New / No history yet", "scoreOverall": 50, "scoreProfile": 50, "payloadVersion": 1, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 50% complete", "No response data yet", "No pipeline history yet"], "trustScoreSnapshotId": "cmkmj37pe000gsp76sw36rsjm"}
01KFDKMGAB3ENNGDD3DV0Y2MWW	1	USER_LOGGED_OUT	2026-01-20 11:46:26.763	2026-01-20 11:46:26.763	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkmt0006as8pffhi7qej	\N	USER	cmkmhjkmt0006as8pffhi7qej	CLARIFY	NEW	api	01KFDKMGABB9E98J3EJ3G5PR6B	{"orgId": "cmkmhq01b0001l0zlo8mzhe7v", "userId": "cmkmhjkmt0006as8pffhi7qej", "sessionId": "cmkmj31rj000dsp76imit3d2l", "payloadVersion": 1}
01KFDKMMR20P5XF1W84GKERK79	1	USER_LOGGED_IN	2026-01-20 11:46:31.297	2026-01-20 11:46:31.298	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDKMMR1RQ12SB8W0X9V719A	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmj3jzw000jsp76yi6z4xam", "payloadVersion": 1}
01KFDKN6HDN88SZM34RPRY1FB2	1	USER_LOGGED_IN	2026-01-20 11:46:49.517	2026-01-20 11:46:49.518	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDKN6HDV29WDQBE0XCRNKAG	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmj3y21000msp76k7z2gfmw", "payloadVersion": 1}
01KFDKZ24ZQDNZP2BG3V1D5635	1	USER_LOGGED_IN	2026-01-20 11:52:12.703	2026-01-20 11:52:12.704	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDKZ24ZWF7Q0TV99MC972AY	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmjavfe000psp766wtzdjes", "payloadVersion": 1}
01KFDKZ8FPVTH1A97WGBCTB933	1	INTENT_VIEWED	2026-01-20 11:52:19.19	2026-01-20 11:52:19.19	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDKZ8FPCPSN1V0YQSY03RFP	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDKZXJVDZVGWT9K8852FPB2	1	INTENT_VIEWED	2026-01-20 11:52:40.795	2026-01-20 11:52:40.795	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	INTENT	cmkmhjkou000aas8p3vlddk03	COMMIT_ASSURE	COMMIT	ui	01KFDKZXJV00J3B7NF4J28KY7E	{"intentId": "cmkmhjkou000aas8p3vlddk03", "viewContext": "owner", "payloadVersion": 1}
01KFDNA4SBDW7EY9N05PS9V39N	1	USER_LOGGED_OUT	2026-01-20 12:15:44.426	2026-01-20 12:15:44.427	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	\N	USER	cmkmhjkl60004as8parglk6ln	CLARIFY	NEW	api	01KFDNA4SANP0PM91T9BNRKY5J	{"orgId": "cmkmhjkg70000as8pwosymxt8", "userId": "cmkmhjkl60004as8parglk6ln", "sessionId": "cmkmjavfe000psp766wtzdjes", "payloadVersion": 1}
01KFDNAA1YVWSCXYM13CGFX6AM	1	USER_LOGGED_IN	2026-01-20 12:15:49.822	2026-01-20 12:15:49.822	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkmt0006as8pffhi7qej	\N	USER	cmkmhjkmt0006as8pffhi7qej	CLARIFY	NEW	api	01KFDNAA1YZCJHP9SEJ7DB2W2W	{"orgId": "cmkmhq01b0001l0zlo8mzhe7v", "userId": "cmkmhjkmt0006as8pffhi7qej", "sessionId": "cmkmk58vq000zsp76oznq9mvf", "payloadVersion": 1}
01KFDNDP8MMAM9P0NG0986J076	1	INTENT_CREATED	2026-01-20 12:17:40.619	2026-01-20 12:17:40.629	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkmt0006as8pffhi7qej	cmkmhq01b0001l0zlo8mzhe7v	INTENT	cmkmk7mdp0011sp767z45gw2m	CLARIFY	NEW	ui	01KFDNDP8MPT5WJY5Z10MMW60T	{"kpi": "in 3 months", "goal": "Implement SAP in tech dep.", "risks": "low budget", "scope": "Onlu tech dep.", "title": "SAP01", "source": "manual", "context": "we don't have sap", "intentId": "cmkmk7mdp0011sp767z45gw2m", "language": "EN", "deadlineAt": "2026-03-31T00:00:00.000Z", "payloadVersion": 1, "confidentialityLevel": "L1"}
01KFDNDPAC46WESJ31X12D0XN7	1	TRUSTSCORE_RECALCULATED	2026-01-20 12:17:40.674	2026-01-20 12:17:40.685	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkmt0006as8pffhi7qej	cmkmhq01b0001l0zlo8mzhe7v	TRUSTSCORE_SNAPSHOT	cmkmk7mf90014sp76m2xu0kyb	CLARIFY	NEW	system	01KFDNDPA2DC9VWNB11ZS2CN3B	{"orgId": "cmkmhq01b0001l0zlo8mzhe7v", "reason": "INTENT_CREATED", "statusLabel": "Low trust / problematic history", "scoreOverall": 35, "scoreProfile": 50, "previousScore": 50, "payloadVersion": 1, "scoreBehaviour": 0, "algorithmVersion": "trustscore_mvp_v1", "explanationPublic": ["Profile 50% complete", "Median response time: 168+h", "Pipeline hygiene: 0% intents with owner + final status"], "previousStatusLabel": "New / No history yet", "scoreResponsiveness": 20, "trustScoreSnapshotId": "cmkmk7mf90014sp76m2xu0kyb"}
01KFDNDPHJFW0WBYFKQMPWDCYD	1	INTENT_VIEWED	2026-01-20 12:17:40.914	2026-01-20 12:17:40.914	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkmt0006as8pffhi7qej	cmkmhq01b0001l0zlo8mzhe7v	INTENT	cmkmk7mdp0011sp767z45gw2m	CLARIFY	NEW	ui	01KFDNDPHHXS9HBRX3R4P34X8M	{"intentId": "cmkmk7mdp0011sp767z45gw2m", "viewContext": "owner", "payloadVersion": 1}
01KFDNDPRFTCBJHKDPJYGD8KXH	1	AVATAR_SUGGESTION_ISSUED	2026-01-20 12:17:41.135	2026-01-20 12:17:41.136	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkmt0006as8pffhi7qej	cmkmhq01b0001l0zlo8mzhe7v	INTENT	cmkmk7mdp0011sp767z45gw2m	CLARIFY	NEW	ui	f66c3221-cb11-4417-a74f-6b42178e3b4b	{"fitBand": "LOW", "intentId": "cmkmk7mdp0011sp767z45gw2m", "priority": "P3", "avatarType": "ORG_X", "suggestionId": "f66c3221-cb11-4417-a74f-6b42178e3b4b", "payloadVersion": 1, "suggestionKind": "lead_qualification", "suggestionL1Text": "Fit LOW, priority P3."}
\.


--
-- Data for Name: Intent; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Intent" (id, "intentNumber", "intentName", "orgId", "createdByUserId", "ownerUserId", goal, title, client, language, tech, industry, region, "budgetBucket", context, scope, kpi, risks, "deadlineAt", stage, "confidentialityLevel", source, "sourceTextRaw", "sourceTextSha256", "sourceTextLength", "aiAllowL2", "aiAllowL2SetAt", "aiAllowL2SetByUserId", "createdAt", "updatedAt", "lastActivityAt") FROM stdin;
cmkmhjkp0000cas8ph3q8rm5n	2	Seed Intent 2	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkj80002as8pcub1p8ou	Modernize the patient mobile experience and improve retention.	Mobile App Revamp for Healthcare	Nordic Health	EN	{react-native,mobile,analytics,ux}	{healthcare,mobile}	{EU,US}	EUR_150K_500K	App ratings dropped to 3.2; onboarding is a major churn driver.	UX audit, design system, React Native rebuild, analytics integration.	NPS +15, retention +20%, crash rate <1%.	Legacy API constraints; HIPAA and data privacy requirements.	2026-05-20 11:32:29.112	NEW	L1	manual	\N	\N	\N	f	\N	\N	2026-01-20 11:02:59.46	2026-01-20 11:32:29.185	2026-01-20 11:16:10.948
cmkmhjkp8000gas8pnoxfandy	4	Seed Intent 4	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkj80002as8pcub1p8ou	Launch a two-sided marketplace MVP within 8 weeks.	Marketplace Launch MVP	UrbanCommerce	EN	{marketplace,payments,backend,react}	{ecommerce,marketplace}	{EU}	EUR_10K_50K	Need rapid validation of supply and demand in two pilot cities.	Marketplace core flows, payments, moderation tools, seller onboarding.	500 listings, 1k buyers, 15% repeat purchase.	Supply acquisition; compliance with local regulations.	2026-03-21 11:32:29.112	NEW	L1	manual	\N	\N	\N	f	\N	\N	2026-01-20 11:02:59.469	2026-01-20 11:32:29.194	2026-01-20 11:16:10.945
cmkmhjkpc000ias8p8gv2ihcx	5	Seed Intent 5	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkj80002as8pcub1p8ou	Migrate analytics stack to a unified lakehouse.	Data Platform Upgrade	FinCore	EN	{data-lake,etl,bi,snowflake}	{fintech,analytics}	{EU,US}	GT_500K	Multiple warehouses cause data drift and slow reporting.	Lakehouse architecture, ETL pipelines, BI dashboards, governance.	Daily refresh <2h, 99% data accuracy, 50% cost reduction.	Data migration complexity; access control policies.	2026-06-19 11:32:29.112	CLARIFY	L1	manual	\N	\N	\N	f	\N	\N	2026-01-20 11:02:59.472	2026-01-20 11:32:29.198	2026-01-20 11:26:17.515
cmkmhjkp4000eas8pi99mtn41	3	Seed Intent 3	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkj80002as8pcub1p8ou	Deploy AI chat support to reduce response time and deflect tickets.	AI Support Assistant	CloudDesk	EN	{llm,chatbot,support,integration}	{saas,customer-support}	{US}	EUR_50K_150K	Backlog exceeds 48h; onboarding questions dominate ticket volume.	LLM chatbot, KB sync, agent handoff flows, analytics dashboard.	30% deflection, avg response <2h, CSAT +10.	Hallucinations; data privacy and PII handling.	2026-04-05 11:32:29.112	MATCH	L1	manual	\N	\N	\N	f	\N	\N	2026-01-20 11:02:59.464	2026-01-20 11:35:27.536	2026-01-20 11:35:27.525
cmkmhjkou000aas8p3vlddk03	1	Seed Intent 1	cmkmhjkg70000as8pwosymxt8	cmkmhjkj80002as8pcub1p8ou	cmkmhjkj80002as8pcub1p8ou	Increase qualified inbound leads for logistics SaaS.	B2B Demand Gen for Logistics SaaS	Acme Logistics	EN	{hubspot,marketing-automation,seo,paid-search}	{logistics,saas,b2b}	{EU}	EUR_50K_150K	Pipeline relies on referrals; attribution is missing for paid channels.	SEO, paid search, HubSpot automation, landing pages, funnel analytics.	3x MQL volume, CAC -20%, trial-to-paid 2%+.	Limited internal marketing resources; EU compliance constraints.	2026-04-20 11:32:29.112	COMMIT	L1	manual	\N	\N	\N	f	\N	\N	2026-01-20 11:02:59.454	2026-01-20 11:52:59.975	2026-01-20 11:52:59.961
cmkmk7mdp0011sp767z45gw2m	6	SAP01	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkmt0006as8pffhi7qej	cmkmhjkmt0006as8pffhi7qej	Implement SAP in tech dep.	Implement SAP in tech dep.	\N	EN	{}	{}	{}	UNKNOWN	we don't have sap	Onlu tech dep.	in 3 months	low budget	2026-03-31 00:00:00	NEW	L1	manual	\N	\N	\N	f	\N	\N	2026-01-20 12:17:40.621	2026-01-20 12:17:41.142	2026-01-20 12:17:41.135
\.


--
-- Data for Name: IntentCoachRun; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."IntentCoachRun" (id, "orgId", "intentId", "createdByUserId", "summaryItems", instructions, "focusFields", "createdAt") FROM stdin;
01KFDHXZQH0X2ZTQKWPYQPEB1B	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	cmkmhjkl60004as8parglk6ln	["Summary**: Focus on enhancing lead generation strategies to attract qualified prospects for a logistics SaaS solution.", "Opinions**: Emphasizing targeted content marketing and SEO can significantly improve visibility and attract the right audience.", "Gaps**: Current lead generation efforts may lack personalization and fail to address specific pain points of potential clients.", "Observations**: Competitors are leveraging case studies and testimonials effectively; incorporating similar strategies could enhance credibility.", "Risks**: Over-reliance on a single channel (e.g., paid ads) may lead to volatility in lead quality and quantity.", "Opportunities**: Exploring partnerships with industry influencers could expand reach and credibility among target audiences.", "Metrics**: Establishing clear KPIs for lead quality and conversion rates will be essential to measure success.", "Resources**: Adequate investment in marketing automation tools may streamline lead nurturing processes and improve efficiency.", "Feedback Loop**: Implementing regular reviews of lead sources and conversion rates can help refine strategies and optimize performance."]	\N	\N	2026-01-20 11:16:47.705
01KFDJZH067YX6PZPTXA03KD0M	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	cmkmhjkl60004as8parglk6ln	["Summary**: The goal is to enhance qualified inbound leads for a logistics SaaS by leveraging SEO, paid search, HubSpot automation, and optimized landing pages, while improving funnel analytics.", "Opinions**: A multi-channel approach is essential for diversifying lead sources and reducing reliance on referrals.", "Gaps**: Current attribution for paid channels is unclear, which may hinder effective budget allocation and strategy adjustments.", "Observations**: The existing pipeline heavily depends on referrals, indicating a potential lack of brand awareness in broader markets.", "Risks**: Limited internal marketing resources may restrict the execution of comprehensive strategies, impacting lead generation efforts.", "Risks**: Compliance with EU regulations could complicate marketing strategies, particularly in data handling and privacy.", "KPIs**: The ambitious targets of tripling MQL volume and reducing CAC by 20% may require significant resource investment and strategic alignment.", "Considerations**: Continuous monitoring of funnel analytics will be crucial to assess the effectiveness of implemented strategies and make necessary adjustments."]	\N	\N	2026-01-20 11:35:05.991
\.


--
-- Data for Name: IntentRecipient; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."IntentRecipient" (id, "intentId", "recipientOrgId", "senderOrgId", "recipientRole", status, "ndaRequestedAt", "ndaRequestedByOrgId", "ndaRequestedByUserId", "createdAt") FROM stdin;
\.


--
-- Data for Name: IntentShareLink; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."IntentShareLink" (id, "orgId", "intentId", "createdByUserId", "tokenHashSha256", "createdAt", "expiresAt", "revokedAt", "revokedByUserId", "lastAccessAt", "accessCount") FROM stdin;
cmkmjbd8o000usp76vmdql5p4	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	cmkmhjkl60004as8parglk6ln	5b6c1a04ee9c4ca9186abf69be87cfb748e113ed4fcfea1c1dd15bef3871ceaf	2026-01-20 11:52:35.784	2026-02-03 11:52:35.779	\N	\N	\N	0
\.


--
-- Data for Name: MatchFeedback; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."MatchFeedback" (id, "orgId", "intentId", "matchListId", "candidateOrgId", "actorUserId", action, rating, notes, "createdAt") FROM stdin;
cmkmisrvq003713o8qss1hes9	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	cmkmio2ua002n13o8ogon1gf2	cmkmhq01b0001l0zlo8mzhe7v	cmkmhjkl60004as8parglk6ln	SHORTLIST	UP	\N	2026-01-20 11:38:08.294
\.


--
-- Data for Name: MatchList; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."MatchList" (id, "orgId", "intentId", "algorithmVersion", "createdByUserId", "resultsJson", "createdAt") FROM stdin;
cmkmi23vo001d13o82jkazh58	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	rule-v1	cmkmhjkl60004as8parglk6ln	{"intentId": "cmkmhjkou000aas8p3vlddk03", "candidates": [], "generatedAt": "2026-01-20T11:17:24.131Z", "algorithmVersion": "rule-v1"}	2026-01-20 11:17:24.131
cmkmid6up001y13o80axzmb9q	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	rule-v1	cmkmhjkl60004as8parglk6ln	{"intentId": "cmkmhjkou000aas8p3vlddk03", "candidates": [], "generatedAt": "2026-01-20T11:26:01.200Z", "algorithmVersion": "rule-v1"}	2026-01-20 11:26:01.2
cmkmidcjp002513o8h3c4tbf3	cmkmhjkg70000as8pwosymxt8	cmkmhjkp4000eas8pi99mtn41	rule-v1	cmkmhjkl60004as8parglk6ln	{"intentId": "cmkmhjkp4000eas8pi99mtn41", "candidates": [], "generatedAt": "2026-01-20T11:26:08.580Z", "algorithmVersion": "rule-v1"}	2026-01-20 11:26:08.58
cmkmidjfw002c13o8vtiwoh08	cmkmhjkg70000as8pwosymxt8	cmkmhjkpc000ias8p8gv2ihcx	rule-v1	cmkmhjkl60004as8parglk6ln	{"intentId": "cmkmhjkpc000ias8p8gv2ihcx", "candidates": [], "generatedAt": "2026-01-20T11:26:17.515Z", "algorithmVersion": "rule-v1"}	2026-01-20 11:26:17.515
cmkmio2ua002n13o8ogon1gf2	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	rule-v1	cmkmhjkl60004as8parglk6ln	{"intentId": "cmkmhjkou000aas8p3vlddk03", "candidates": [{"orgId": "cmkmhq01b0001l0zlo8mzhe7v", "orgName": "Enabion Dev User2", "orgSlug": "enabion-dev-user2", "breakdown": {"tech": {"notes": "Matched 4/4 tech tags.", "weight": 25, "matched": ["hubspot", "marketing-automation", "paid-search", "seo"], "compared": {"org": ["logistics", "saas", "b2b", "lead-gen", "marketing-automation", "hubspot", "seo", "paid-search", "llm", "chatbot", "support", "integration"], "intent": ["hubspot", "marketing-automation", "seo", "paid-search"]}, "contribution": 25, "normalizedScore": 1}, "budget": {"notes": "Budget bucket matched.", "weight": 10, "matched": ["EUR_50K_150K"], "compared": {"org": ["EUR_50K_150K"], "intent": ["EUR_50K_150K"]}, "contribution": 10, "normalizedScore": 1}, "region": {"notes": "Region overlap detected.", "weight": 15, "matched": ["EU"], "compared": {"org": ["EU", "US"], "intent": ["EU"]}, "contribution": 15, "normalizedScore": 1}, "industry": {"notes": "Matched 3/3 industries.", "weight": 20, "matched": ["b2b", "logistics", "saas"], "compared": {"org": ["logistics", "saas", "b2b", "lead-gen", "marketing-automation", "hubspot", "seo", "paid-search", "llm", "chatbot", "support", "integration"], "intent": ["logistics", "saas", "b2b"]}, "contribution": 20, "normalizedScore": 1}, "language": {"notes": "Intent language matched provider languages.", "weight": 30, "matched": ["EN"], "compared": {"org": ["EN"], "intent": ["EN"]}, "contribution": 30, "normalizedScore": 1}}, "totalScore": 100}, {"orgId": "cmkmhq01f0002l0zlsbq87413", "orgName": "Enabion Dev User3", "orgSlug": "enabion-dev-user3", "breakdown": {"tech": {"notes": "No tech overlap.", "weight": 25, "matched": [], "compared": {"org": ["mobile", "react-native", "healthcare", "ux", "analytics"], "intent": ["hubspot", "marketing-automation", "seo", "paid-search"]}, "contribution": 0, "normalizedScore": 0}, "budget": {"notes": "Budget bucket did not match.", "weight": 10, "matched": [], "compared": {"org": ["EUR_150K_500K"], "intent": ["EUR_50K_150K"]}, "contribution": 0, "normalizedScore": 0}, "region": {"notes": "Region overlap detected.", "weight": 15, "matched": ["EU"], "compared": {"org": ["EU"], "intent": ["EU"]}, "contribution": 15, "normalizedScore": 1}, "industry": {"notes": "No industry overlap.", "weight": 20, "matched": [], "compared": {"org": ["mobile", "react-native", "healthcare", "ux", "analytics"], "intent": ["logistics", "saas", "b2b"]}, "contribution": 0, "normalizedScore": 0}, "language": {"notes": "Intent language matched provider languages.", "weight": 30, "matched": ["EN"], "compared": {"org": ["EN", "PL"], "intent": ["EN"]}, "contribution": 30, "normalizedScore": 1}}, "totalScore": 45}], "generatedAt": "2026-01-20T11:34:29.215Z", "algorithmVersion": "rule-v1"}	2026-01-20 11:34:29.215
cmkmipbty003013o8fb5cc6dz	cmkmhjkg70000as8pwosymxt8	cmkmhjkp4000eas8pi99mtn41	rule-v1	cmkmhjkl60004as8parglk6ln	{"intentId": "cmkmhjkp4000eas8pi99mtn41", "candidates": [{"orgId": "cmkmhq01b0001l0zlo8mzhe7v", "orgName": "Enabion Dev User2", "orgSlug": "enabion-dev-user2", "breakdown": {"tech": {"notes": "Matched 4/4 tech tags.", "weight": 25, "matched": ["chatbot", "integration", "llm", "support"], "compared": {"org": ["logistics", "saas", "b2b", "lead-gen", "marketing-automation", "hubspot", "seo", "paid-search", "llm", "chatbot", "support", "integration"], "intent": ["llm", "chatbot", "support", "integration"]}, "contribution": 25, "normalizedScore": 1}, "budget": {"notes": "Budget bucket matched.", "weight": 10, "matched": ["EUR_50K_150K"], "compared": {"org": ["EUR_50K_150K"], "intent": ["EUR_50K_150K"]}, "contribution": 10, "normalizedScore": 1}, "region": {"notes": "Region overlap detected.", "weight": 15, "matched": ["US"], "compared": {"org": ["EU", "US"], "intent": ["US"]}, "contribution": 15, "normalizedScore": 1}, "industry": {"notes": "Matched 1/2 industries.", "weight": 20, "matched": ["saas"], "compared": {"org": ["logistics", "saas", "b2b", "lead-gen", "marketing-automation", "hubspot", "seo", "paid-search", "llm", "chatbot", "support", "integration"], "intent": ["saas", "customer-support"]}, "contribution": 10, "normalizedScore": 0.5}, "language": {"notes": "Intent language matched provider languages.", "weight": 30, "matched": ["EN"], "compared": {"org": ["EN"], "intent": ["EN"]}, "contribution": 30, "normalizedScore": 1}}, "totalScore": 90}, {"orgId": "cmkmhq01f0002l0zlsbq87413", "orgName": "Enabion Dev User3", "orgSlug": "enabion-dev-user3", "breakdown": {"tech": {"notes": "No tech overlap.", "weight": 25, "matched": [], "compared": {"org": ["mobile", "react-native", "healthcare", "ux", "analytics"], "intent": ["llm", "chatbot", "support", "integration"]}, "contribution": 0, "normalizedScore": 0}, "budget": {"notes": "Budget bucket did not match.", "weight": 10, "matched": [], "compared": {"org": ["EUR_150K_500K"], "intent": ["EUR_50K_150K"]}, "contribution": 0, "normalizedScore": 0}, "region": {"notes": "No region overlap.", "weight": 15, "matched": [], "compared": {"org": ["EU"], "intent": ["US"]}, "contribution": 0, "normalizedScore": 0}, "industry": {"notes": "No industry overlap.", "weight": 20, "matched": [], "compared": {"org": ["mobile", "react-native", "healthcare", "ux", "analytics"], "intent": ["saas", "customer-support"]}, "contribution": 0, "normalizedScore": 0}, "language": {"notes": "Intent language matched provider languages.", "weight": 30, "matched": ["EN"], "compared": {"org": ["EN", "PL"], "intent": ["EN"]}, "contribution": 30, "normalizedScore": 1}}, "totalScore": 30}], "generatedAt": "2026-01-20T11:35:27.525Z", "algorithmVersion": "rule-v1"}	2026-01-20 11:35:27.525
cmkmiszjg003913o84e9jxrld	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	rule-v1	cmkmhjkl60004as8parglk6ln	{"intentId": "cmkmhjkou000aas8p3vlddk03", "candidates": [{"orgId": "cmkmhq01b0001l0zlo8mzhe7v", "orgName": "Enabion Dev User2", "orgSlug": "enabion-dev-user2", "breakdown": {"tech": {"notes": "Matched 4/4 tech tags.", "weight": 25, "matched": ["hubspot", "marketing-automation", "paid-search", "seo"], "compared": {"org": ["logistics", "saas", "b2b", "lead-gen", "marketing-automation", "hubspot", "seo", "paid-search", "llm", "chatbot", "support", "integration"], "intent": ["hubspot", "marketing-automation", "seo", "paid-search"]}, "contribution": 25, "normalizedScore": 1}, "budget": {"notes": "Budget bucket matched.", "weight": 10, "matched": ["EUR_50K_150K"], "compared": {"org": ["EUR_50K_150K"], "intent": ["EUR_50K_150K"]}, "contribution": 10, "normalizedScore": 1}, "region": {"notes": "Region overlap detected.", "weight": 15, "matched": ["EU"], "compared": {"org": ["EU", "US"], "intent": ["EU"]}, "contribution": 15, "normalizedScore": 1}, "industry": {"notes": "Matched 3/3 industries.", "weight": 20, "matched": ["b2b", "logistics", "saas"], "compared": {"org": ["logistics", "saas", "b2b", "lead-gen", "marketing-automation", "hubspot", "seo", "paid-search", "llm", "chatbot", "support", "integration"], "intent": ["logistics", "saas", "b2b"]}, "contribution": 20, "normalizedScore": 1}, "language": {"notes": "Intent language matched provider languages.", "weight": 30, "matched": ["EN"], "compared": {"org": ["EN"], "intent": ["EN"]}, "contribution": 30, "normalizedScore": 1}}, "totalScore": 100}, {"orgId": "cmkmhq01f0002l0zlsbq87413", "orgName": "Enabion Dev User3", "orgSlug": "enabion-dev-user3", "breakdown": {"tech": {"notes": "No tech overlap.", "weight": 25, "matched": [], "compared": {"org": ["mobile", "react-native", "healthcare", "ux", "analytics"], "intent": ["hubspot", "marketing-automation", "seo", "paid-search"]}, "contribution": 0, "normalizedScore": 0}, "budget": {"notes": "Budget bucket did not match.", "weight": 10, "matched": [], "compared": {"org": ["EUR_150K_500K"], "intent": ["EUR_50K_150K"]}, "contribution": 0, "normalizedScore": 0}, "region": {"notes": "Region overlap detected.", "weight": 15, "matched": ["EU"], "compared": {"org": ["EU"], "intent": ["EU"]}, "contribution": 15, "normalizedScore": 1}, "industry": {"notes": "No industry overlap.", "weight": 20, "matched": [], "compared": {"org": ["mobile", "react-native", "healthcare", "ux", "analytics"], "intent": ["logistics", "saas", "b2b"]}, "contribution": 0, "normalizedScore": 0}, "language": {"notes": "Intent language matched provider languages.", "weight": 30, "matched": ["EN"], "compared": {"org": ["EN", "PL"], "intent": ["EN"]}, "contribution": 30, "normalizedScore": 1}}, "totalScore": 45}], "generatedAt": "2026-01-20T11:38:18.218Z", "algorithmVersion": "rule-v1"}	2026-01-20 11:38:18.218
\.


--
-- Data for Name: NdaAcceptance; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."NdaAcceptance" (id, "orgId", "counterpartyOrgId", "ndaType", "ndaVersion", "enHashSha256", "acceptedByUserId", "acceptedAt", language, channel, "typedName", "typedRole", "createdAt") FROM stdin;
\.


--
-- Data for Name: NdaDocument; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."NdaDocument" (id, "ndaType", "ndaVersion", "enMarkdown", "summaryPl", "summaryDe", "summaryNl", "enHashSha256", "isActive", "createdAt", "updatedAt") FROM stdin;
cmkmi7erj001o13o8d7y8v3bo	MUTUAL	Enabion_mutual_nda_v0.1_en	# Enabion Mutual Non-Disclosure Agreement (Mutual NDA)\n**Version:** Enabion_mutual_nda_v0.1_en  \n**Status:** Final (authorized)  \n**Effective Date:** {{EFFECTIVE_DATE}}  \n**Parties:**  \n1) **Enabion**: {{ENABION_LEGAL_NAME}}, {{ENABION_ADDRESS}}, {{ENABION_REGISTRY_ID}} ("**Enabion**")  \n2) **Counterparty**: {{COUNTERPARTY_LEGAL_NAME}}, {{COUNTERPARTY_ADDRESS}}, {{COUNTERPARTY_REGISTRY_ID}} ("**Counterparty**")  \n\nEnabion and Counterparty are each a "**Party**" and together the "**Parties**".\n\n> **Important notice (non-legal):** This Agreement is the Enabion standard Mutual NDA for the MVP pilot.\n\n---\n\n## 1. Purpose\nThe Parties wish to exchange certain information for the purpose of evaluating and/or pursuing potential business cooperation, including pre-sales discussions and possible project engagement(s) facilitated by the Enabion platform (the "**Purpose**").\n\n## 2. Definitions\n### 2.1 "Confidential Information"\n"**Confidential Information**" means any non-public information disclosed by or on behalf of a Party ("**Disclosing Party**") to the other Party ("**Receiving Party**"), whether in written, oral, visual, electronic or any other form, that is:\n- marked or identified as confidential, or\n- reasonably should be understood to be confidential given the nature of the information and the circumstances of disclosure.\n\nConfidential Information includes, without limitation: business plans, pricing, client information, proposals, software, source code, product roadmaps, technical data, security information, and any analyses, notes, summaries or derivatives made by the Receiving Party that contain or reflect such information.\n\n### 2.2 "Representatives"\n"**Representatives**" means a Party's employees, officers, directors, contractors, affiliates, professional advisors, and agents who have a need to know Confidential Information for the Purpose and are bound by confidentiality obligations at least as protective as those in this Agreement.\n\n### 2.3 Platform data levels (L1/L2)\nFor the MVP, the Parties may label information as:\n- **L1 (No-NDA Zone)**: information intended to be shareable without an NDA (e.g., high-level summaries).\n- **L2 (NDA-Required)**: information that must not be disclosed to the other Party unless the Mutual NDA is accepted.\n\nThis Agreement governs L2 disclosures. L1 information may still be treated as Confidential Information if it meets the definition in Section 2.1.\n\n## 3. Confidentiality Obligations\nThe Receiving Party shall:\n1) use the Disclosing Party's Confidential Information solely for the Purpose;\n2) keep the Confidential Information strictly confidential and protect it using at least the same degree of care it uses to protect its own confidential information, and no less than reasonable care;\n3) not disclose the Confidential Information to any third party except to its Representatives who have a need to know for the Purpose;\n4) ensure that its Representatives comply with this Agreement; and\n5) not copy, reverse engineer or decompile Confidential Information (including software) except as strictly necessary for the Purpose and as permitted by law.\n\n## 4. Exclusions\nConfidential Information does not include information that the Receiving Party can demonstrate with written records:\na) is or becomes publicly available through no breach of this Agreement;\nb) was lawfully known by the Receiving Party prior to disclosure;\nc) is independently developed by the Receiving Party without use of the Disclosing Party's Confidential Information; or\nd) is lawfully obtained from a third party without restriction.\n\n## 5. Compelled Disclosure\nIf the Receiving Party is required by law, regulation, court order or governmental authority to disclose Confidential Information, it shall (to the extent legally permitted) provide prompt written notice to the Disclosing Party and reasonably cooperate to seek protective treatment. The Receiving Party may disclose only the minimum amount required.\n\n## 6. Return / Destruction\nUpon written request by the Disclosing Party, the Receiving Party shall promptly return or destroy (and certify destruction of) the Disclosing Party's Confidential Information, except that the Receiving Party may retain:\n- one archival copy solely for legal/compliance purposes, and/or\n- copies stored automatically as part of routine system backups, provided such copies remain protected and are not accessed except for backup/restore operations.\n\n## 7. No License / No Obligation\nNo license or other rights are granted under this Agreement by disclosure of Confidential Information, whether by implication or otherwise. Nothing in this Agreement obligates either Party to proceed with any transaction or relationship.\n\n## 8. No Warranty\nAll Confidential Information is provided "as is" without warranties of any kind. The Disclosing Party does not guarantee completeness or accuracy.\n\n## 9. Term and Survival\n### 9.1 Term\nThis Agreement begins on the Effective Date and continues for **two (2) years**, unless terminated earlier by either Party upon thirty (30) days' written notice.\n\n### 9.2 Survival\nThe confidentiality obligations in this Agreement survive termination for **three (3) years** from the date of termination; however, with respect to trade secrets, such obligations survive as long as the information remains a trade secret under applicable law.\n\n## 10. Remedies\nThe Parties acknowledge that unauthorized disclosure or use of Confidential Information may cause irreparable harm. The Disclosing Party is entitled to seek injunctive or equitable relief in addition to any other remedies available at law.\n\n## 11. Governing Law and Jurisdiction\nThis Agreement shall be governed by the laws of **{{GOVERNING_LAW}}**, excluding its conflict-of-laws rules.  \nThe courts of **{{JURISDICTION}}** shall have exclusive jurisdiction, except that a Party may seek injunctive relief in any competent court.\n\n## 12. Miscellaneous\n- **Entire Agreement.** This Agreement constitutes the entire agreement between the Parties regarding the Purpose and supersedes prior discussions on confidentiality for the Purpose.\n- **Amendments.** Any amendment must be in writing and agreed by both Parties.\n- **Assignment.** Neither Party may assign this Agreement without the other Party's written consent, except to an affiliate in connection with a merger, acquisition or sale of substantially all assets.\n- **Severability.** If any provision is held invalid, the remainder remains in effect.\n- **Notices.** Notices shall be sent to the addresses stated above (or updated by written notice).\n- **Electronic Acceptance.** The Parties agree that electronic acceptance (including click-through acceptance in the Enabion application) may constitute valid acceptance of this Agreement, to the extent permitted by applicable law.\n- **Governing language.** In case of conflict, the English version prevails.\n\n---\n\n## Signatures\n**ENABION**  \nName: __________________________  \nTitle: __________________________  \nDate: __________________________  \n\n**COUNTERPARTY**  \nName: __________________________  \nTitle: __________________________  \nDate: __________________________  \n	# Enabion Mutual NDA - Summary (PL) - v0.1 (UI copy)\n\n> **Uwaga:** To jest skrót informacyjny (UI copy). Tekst prawnie wiążący jest w wersji EN: `Enabion_mutual_nda_v0.1_en`.\n\n## Co to jest?\nWzajemna umowa o poufności pomiędzy Enabion a drugą stroną (partnerem X<->Y), która pozwala wymieniać informacje **L2 (NDA-Required)** w procesie pre-sales.\n\n## Co chroni?\n- informacje handlowe i techniczne,\n- dane o klientach i projektach,\n- oferty, wyceny, warunki,\n- dokumenty i załączniki oznaczone jako L2,\n- notatki/analizy powstałe na bazie tych informacji.\n\n## Najważniejsze zobowiązania\n- używamy informacji tylko w celu oceny współpracy (Purpose),\n- nie ujawniamy osobom trzecim (poza upoważnionymi osobami w organizacji),\n- dbamy o bezpieczeństwo informacji co najmniej "rozsądnie",\n- po zakończeniu możemy zostać poproszeni o usunięcie/zwrot.\n\n## Czas trwania (wzorzec)\n- Umowa obowiązuje 2 lata,\n- obowiązek poufności: 3 lata po zakończeniu (dłużej dla tajemnic przedsiębiorstwa).\n\n## L1 vs L2 w aplikacji\n- L1: informacje do udostępniania bez NDA,\n- L2: dostępne dopiero po akceptacji Mutual NDA.\n	# Enabion Mutual NDA - Summary (DE) - v0.1 (UI copy)\n\n> **Hinweis:** Dies ist eine Zusammenfassung (UI-Text). Der rechtlich maßgebliche Text ist die EN-Version: `Enabion_mutual_nda_v0.1_en`.\n\n## Worum geht es?\nEine gegenseitige Vertraulichkeitsvereinbarung zwischen Enabion und der Gegenpartei (Partner X<->Y), um **L2 (NDA-Required)** Informationen im Pre-Sales-Prozess auszutauschen.\n\n## Was wird geschützt?\n- Geschäfts- und technische Informationen,\n- Kunden- und Projektdaten,\n- Angebote, Preise, Konditionen,\n- als L2 markierte Dokumente und Anhänge,\n- abgeleitete Notizen/Analysen.\n\n## Kernpflichten\n- Nutzung nur für den "Purpose" (Evaluierung/Kooperation),\n- keine Weitergabe an Dritte (außer autorisierte Personen),\n- angemessene Schutzmaßnahmen,\n- auf Anfrage Rückgabe/Löschung.\n\n## Dauer (Template)\n- Laufzeit 2 Jahre,\n- Vertraulichkeit: 3 Jahre nach Beendigung (länger bei Geschäftsgeheimnissen).\n\n## L1 vs L2 in der App\n- L1: ohne NDA teilbar,\n- L2: nur nach Annahme der Mutual NDA.\n	# Enabion Mutual NDA - Summary (NL) - v0.1 (UI copy)\n\n> **Let op:** Dit is een samenvatting (UI-tekst). De juridisch leidende tekst is de EN-versie: `Enabion_mutual_nda_v0.1_en`.\n\n## Wat is dit?\nEen wederzijdse geheimhoudingsovereenkomst tussen Enabion en de wederpartij (partner X<->Y) om **L2 (NDA-Required)** informatie uit te wisselen in pre-sales.\n\n## Wat wordt beschermd?\n- zakelijke en technische informatie,\n- klant- en projectinformatie,\n- offertes, prijzen, voorwaarden,\n- als L2 gemarkeerde documenten en bijlagen,\n- afgeleide notities/analyses.\n\n## Kernverplichtingen\n- gebruik alleen voor het doel ("Purpose"),\n- geen delen met derden (behalve geautoriseerde personen),\n- redelijke beveiliging,\n- op verzoek teruggeven/verwijderen.\n\n## Looptijd (template)\n- looptijd 2 jaar,\n- geheimhouding: 3 jaar na beëindiging (langer voor bedrijfsgeheimen).\n\n## L1 vs L2 in de app\n- L1: deelbaar zonder NDA,\n- L2: pas na acceptatie van Mutual NDA.\n	9ed55f618aab2662e3137c3aa2eaa86fcccd655d6d060e26664864b6509cbffd	t	2026-01-20 11:21:31.52	2026-01-20 11:21:31.52
\.


--
-- Data for Name: OrgAvatarProfile; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."OrgAvatarProfile" (id, "orgId", "profileVersion", markets, industries, "clientTypes", "servicePortfolio", "techStack", "excludedSectors", constraints, "createdByUserId", "updatedByUserId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: OrgLeadQualification; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."OrgLeadQualification" (id, "orgId", "intentId", "fitBand", priority, reasons, "createdByUserId", "updatedByUserId", "createdAt", "updatedAt") FROM stdin;
cmkmi0jds000i13o8yi15qlwy	cmkmhjkg70000as8pwosymxt8	cmkmhjkp0000cas8ph3q8rm5n	LOW	P3	["insufficient_signals"]	cmkmhjkl60004as8parglk6ln	cmkmhjkl60004as8parglk6ln	2026-01-20 11:16:10.912	2026-01-20 11:16:34.147
cmkmi0jdv000k13o8w1ybwlw8	cmkmhjkg70000as8pwosymxt8	cmkmhjkp8000gas8pnoxfandy	LOW	P3	["insufficient_signals"]	cmkmhjkl60004as8parglk6ln	cmkmhjkl60004as8parglk6ln	2026-01-20 11:16:10.915	2026-01-20 11:16:34.16
cmkmi0jbx000c13o8usttcspf	cmkmhjkg70000as8pwosymxt8	cmkmhjkpc000ias8p8gv2ihcx	LOW	P3	["insufficient_signals"]	cmkmhjkl60004as8parglk6ln	cmkmhjkl60004as8parglk6ln	2026-01-20 11:16:10.846	2026-01-20 11:26:12.497
cmkmi0jc2000e13o8ztyegioa	cmkmhjkg70000as8pwosymxt8	cmkmhjkp4000eas8pi99mtn41	LOW	P3	["insufficient_signals"]	cmkmhjkl60004as8parglk6ln	cmkmhjkl60004as8parglk6ln	2026-01-20 11:16:10.85	2026-01-20 11:35:24.175
cmkmi0jd1000g13o8q1scv6nw	cmkmhjkg70000as8pwosymxt8	cmkmhjkou000aas8p3vlddk03	LOW	P3	["insufficient_signals"]	cmkmhjkl60004as8parglk6ln	cmkmhjkl60004as8parglk6ln	2026-01-20 11:16:10.885	2026-01-20 11:52:40.963
cmkmk7mrh0016sp769szlh7mu	cmkmhq01b0001l0zlo8mzhe7v	cmkmk7mdp0011sp767z45gw2m	LOW	P3	["insufficient_signals"]	cmkmhjkmt0006as8pffhi7qej	cmkmhjkmt0006as8pffhi7qej	2026-01-20 12:17:41.118	2026-01-20 12:17:41.118
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Organization" (id, name, slug, status, "defaultLanguage", "policyAiEnabled", "policyShareLinksEnabled", "policyEmailIngestEnabled", "providerLanguages", "providerRegions", "providerTags", "providerBudgetBucket", "providerTeamSizeBucket", "trustScoreLatestId", "createdAt") FROM stdin;
cmkmhq01f0002l0zlsbq87413	Enabion Dev User3	enabion-dev-user3	ACTIVE	EN	t	f	f	{EN,PL}	{EU}	{mobile,react-native,healthcare,ux,analytics}	EUR_150K_500K	TEAM_11_50	\N	2026-01-20 11:07:59.283
cmkmhjkg70000as8pwosymxt8	Enabion Dev	enabion-dev	ACTIVE	EN	t	f	f	{EN}	{EU,US}	{logistics,saas,b2b,marketing-automation,hubspot,react-native,healthcare,llm,chatbot,marketplace,data-platform}	EUR_150K_500K	TEAM_11_50	cmkmiszjy003c13o89kh0uq5v	2026-01-20 11:02:59.143
cmkmhq01b0001l0zlo8mzhe7v	Enabion Dev User2	enabion-dev-user2	ACTIVE	EN	t	f	f	{EN}	{EU,US}	{logistics,saas,b2b,lead-gen,marketing-automation,hubspot,seo,paid-search,llm,chatbot,support,integration}	EUR_50K_150K	TEAM_2_10	cmkmk7mf90014sp76m2xu0kyb	2026-01-20 11:07:59.279
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."PasswordResetToken" (id, "userId", "tokenHash", "createdAt", "expiresAt", "usedAt") FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Session" (id, "userId", "tokenHash", "createdAt", "expiresAt", "revokedAt") FROM stdin;
cmkmhtclq0002zrnrsvz8szht	cmkmhjkj80002as8pcub1p8ou	2b180d33edfa8fb0a8dc547187300d744c40074676b00290a2872841450b1935	2026-01-20 11:10:35.534	2026-01-20 23:10:35.524	\N
cmkmhyjqz000213o8ik41nxke	cmkmhjkj80002as8pcub1p8ou	21918d4bab99864da6e0e12647ed5a7cb2240320e8985eca64b5b4053a818b75	2026-01-20 11:14:38.076	2026-01-20 23:14:38.068	\N
cmkmhzaux000513o8ijwhl11u	cmkmhjkj80002as8pcub1p8ou	9f9d9cca2190c0757c11c7abc0fdc81e08c6633a0ce83991232d4242c3ecf39c	2026-01-20 11:15:13.21	2026-01-20 23:15:13.203	2026-01-20 11:15:50.704
cmkmi5fnk001j13o8ux0dw9y4	cmkmhjkj80002as8pcub1p8ou	25a2986a7788ec78b9d67fe1a5d8c8cfff157d5bad0f851ad7c34d77e1e1e97a	2026-01-20 11:19:59.361	2026-01-20 23:19:59.356	\N
cmkmi09z7000813o8gi06z3y3	cmkmhjkl60004as8parglk6ln	22123eeb181961b355fd110800e50dee9b4a14af317b7eb75091457064cbfa45	2026-01-20 11:15:58.723	2026-01-20 23:15:58.716	2026-01-20 11:21:16.446
cmkmi76c8001m13o8ifnim1ab	cmkmhjkj80002as8pcub1p8ou	f799fa29bc44ca3795192d8a78e625074e895bbb2e54b674297dc792e18411ce	2026-01-20 11:21:20.601	2026-01-20 23:21:20.594	2026-01-20 11:21:55.191
cmkmi9bz7001u13o8yub7n8yg	cmkmhjkl60004as8parglk6ln	4379d3748494e6be4f924545ad9cdf62a5baa441fa138011d2b61f98a3f6f56c	2026-01-20 11:23:01.219	2026-01-20 23:23:01.213	2026-01-20 11:44:35.963
cmkmj14pa0002sp76gx2zl70n	cmkmhjkl60004as8parglk6ln	2a63c54cfbf64fd605b0ebb3f373a111eafc2d9927388e3b5251cf6d4fb04d02	2026-01-20 11:44:38.159	2026-01-20 23:44:38.153	2026-01-20 11:44:56.56
cmkmj1ktj0005sp76nopvknci	cmkmhjkl60004as8parglk6ln	b783742de9bca26d91767980347a03a295fddcac1b08f7996e7261f227a819cb	2026-01-20 11:44:59.048	2026-01-20 23:44:59.043	2026-01-20 11:45:47.019
cmkmj2o1m0008sp761hgxp30w	cmkmhjkl60004as8parglk6ln	374af4cd3041338b7198cfde45cd89395a1e7e970a23680c421e5d3f39bdcbef	2026-01-20 11:45:49.882	2026-01-20 23:45:49.877	2026-01-20 11:46:01.373
cmkmj31rj000dsp76imit3d2l	cmkmhjkmt0006as8pffhi7qej	f03be5e93cba10088258ad1739824dd61b913098de392efa3655e8608a7efcf1	2026-01-20 11:46:07.664	2026-01-20 23:46:07.658	2026-01-20 11:46:26.759
cmkmj3jzw000jsp76yi6z4xam	cmkmhjkl60004as8parglk6ln	69856061d6b82bed65a0325ed2f4f0782bc90a95910a532829831eb06b748bb7	2026-01-20 11:46:31.293	2026-01-20 23:46:31.287	\N
cmkmj3y21000msp76k7z2gfmw	cmkmhjkl60004as8parglk6ln	1fd16b050044c74dda1c97ed141e15eeda62c81b08a1d1edc101d57f6892d766	2026-01-20 11:46:49.513	2026-01-20 23:46:49.509	\N
cmkmjavfe000psp766wtzdjes	cmkmhjkl60004as8parglk6ln	33a12103bf32054b822765b4c5bfb836113ef60c1accfab67df66a01580335e9	2026-01-20 11:52:12.698	2026-01-20 23:52:12.693	2026-01-20 12:15:44.422
cmkmk58vq000zsp76oznq9mvf	cmkmhjkmt0006as8pffhi7qej	b1a721eb524c8b1013fb83f253d207a4b229aa1a2160e473d05bae3903ecf4db	2026-01-20 12:15:49.814	2026-01-21 00:15:49.807	\N
\.


--
-- Data for Name: ThemePalette; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."ThemePalette" (id, slug, name, "tokensJson", "isGlobalDefault", "createdByUserId", "updatedByUserId", "createdAt", "updatedAt") FROM stdin;
cmkmi7fej001p13o85to6qcu9	enabion-default	Enabion Default	{"info": "#228BE6", "danger": "#F87171", "success": "#2F9E44", "warning": "#F59F00", "accent-1": "#126E82", "accent-2": "#38A169", "accent-3": "#FDBA45", "brand-gold": "#FDBA45", "brand-navy": "#0B2239", "brand-green": "#38A169", "brand-ocean": "#126E82"}	t	\N	\N	2026-01-20 11:21:32.348	2026-01-20 11:21:32.348
\.


--
-- Data for Name: ThemePaletteRevision; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."ThemePaletteRevision" (id, "paletteId", revision, "tokensJson", "createdByUserId", "createdAt") FROM stdin;
cmkmi7feo001r13o8i677zb8w	cmkmi7fej001p13o85to6qcu9	1	{"info": "#228BE6", "danger": "#F87171", "success": "#2F9E44", "warning": "#F59F00", "accent-1": "#126E82", "accent-2": "#38A169", "accent-3": "#FDBA45", "brand-gold": "#FDBA45", "brand-navy": "#0B2239", "brand-green": "#38A169", "brand-ocean": "#126E82"}	\N	2026-01-20 11:21:32.353
\.


--
-- Data for Name: TrustScoreSnapshot; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."TrustScoreSnapshot" (id, "orgId", "subjectOrgId", scope, "scoreOverall", "scoreProfile", "scoreResponsiveness", "scoreBehaviour", "statusLabel", "explanationPublic", "explanationInternal", "triggerReason", "actorUserId", "algorithmVersion", "computedAt", "createdAt") FROM stdin;
cmkmi0mab000n13o8g4bo817t	cmkmhjkg70000as8pwosymxt8	cmkmhjkg70000as8pwosymxt8	GLOBAL	30	14	20	0	Low trust / problematic history	["Profile 14% complete", "Median response time: 168+h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 5, "deltaProfile": -5, "deltaResponse": -10, "deltaBehaviour": -5, "responseMedianHours": 1000, "responseSampleCount": 5, "missingResponseCount": 4, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 14}	INTENT_STAGE_CHANGED	cmkmhjkl60004as8parglk6ln	trustscore_mvp_v1	2026-01-20 11:16:14.672	2026-01-20 11:16:14.676
cmkmi0ndn000q13o8n416uskc	cmkmhjkg70000as8pwosymxt8	cmkmhjkg70000as8pwosymxt8	GLOBAL	30	14	20	0	Low trust / problematic history	["Profile 14% complete", "Median response time: 168+h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 5, "deltaProfile": -5, "deltaResponse": -10, "deltaBehaviour": -5, "responseMedianHours": 1000, "responseSampleCount": 5, "missingResponseCount": 3, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 14}	INTENT_STAGE_CHANGED	cmkmhjkl60004as8parglk6ln	trustscore_mvp_v1	2026-01-20 11:16:16.088	2026-01-20 11:16:16.091
cmkmi0on2000t13o8sqbjziso	cmkmhjkg70000as8pwosymxt8	cmkmhjkg70000as8pwosymxt8	GLOBAL	50	14	100	0	Neutral / standard	["Profile 14% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 5, "deltaProfile": -5, "deltaResponse": 10, "deltaBehaviour": -5, "responseMedianHours": 0.2217347222222222, "responseSampleCount": 5, "missingResponseCount": 2, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 14}	INTENT_STAGE_CHANGED	cmkmhjkl60004as8parglk6ln	trustscore_mvp_v1	2026-01-20 11:16:17.724	2026-01-20 11:16:17.727
cmkmi23wf001g13o8k7keull8	cmkmhjkg70000as8pwosymxt8	cmkmhjkg70000as8pwosymxt8	GLOBAL	50	14	100	0	Neutral / standard	["Profile 14% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 5, "deltaProfile": -5, "deltaResponse": 10, "deltaBehaviour": -5, "responseMedianHours": 0.2217347222222222, "responseSampleCount": 5, "missingResponseCount": 2, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 14}	MATCH_LIST_CREATED	cmkmhjkl60004as8parglk6ln	trustscore_mvp_v1	2026-01-20 11:17:24.157	2026-01-20 11:17:24.159
cmkmid6wl002113o8bbm00scz	cmkmhjkg70000as8pwosymxt8	cmkmhjkg70000as8pwosymxt8	GLOBAL	50	14	100	0	Neutral / standard	["Profile 14% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 5, "deltaProfile": -5, "deltaResponse": 10, "deltaBehaviour": -5, "responseMedianHours": 0.2217347222222222, "responseSampleCount": 5, "missingResponseCount": 2, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 14}	MATCH_LIST_CREATED	cmkmhjkl60004as8parglk6ln	trustscore_mvp_v1	2026-01-20 11:26:01.265	2026-01-20 11:26:01.27
cmkmidckd002813o8kk6v2oqj	cmkmhjkg70000as8pwosymxt8	cmkmhjkg70000as8pwosymxt8	GLOBAL	50	14	100	0	Neutral / standard	["Profile 14% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 5, "deltaProfile": -5, "deltaResponse": 10, "deltaBehaviour": -5, "responseMedianHours": 0.2217347222222222, "responseSampleCount": 5, "missingResponseCount": 2, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 14}	MATCH_LIST_CREATED	cmkmhjkl60004as8parglk6ln	trustscore_mvp_v1	2026-01-20 11:26:08.603	2026-01-20 11:26:08.605
cmkmidjhb002f13o8ls0qexcg	cmkmhjkg70000as8pwosymxt8	cmkmhjkg70000as8pwosymxt8	GLOBAL	50	14	100	0	Neutral / standard	["Profile 14% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 5, "deltaProfile": -5, "deltaResponse": 10, "deltaBehaviour": -5, "responseMedianHours": 0.2217347222222222, "responseSampleCount": 5, "missingResponseCount": 2, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 14}	MATCH_LIST_CREATED	cmkmhjkl60004as8parglk6ln	trustscore_mvp_v1	2026-01-20 11:26:17.565	2026-01-20 11:26:17.567
cmkmio2vr002q13o86nsst6o9	cmkmhjkg70000as8pwosymxt8	cmkmhjkg70000as8pwosymxt8	GLOBAL	55	50	100	0	Neutral / standard	["Profile 50% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 5, "deltaProfile": 0, "deltaResponse": 10, "deltaBehaviour": -5, "responseMedianHours": 0.2217347222222222, "responseSampleCount": 5, "missingResponseCount": 2, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 50}	MATCH_LIST_CREATED	cmkmhjkl60004as8parglk6ln	trustscore_mvp_v1	2026-01-20 11:34:29.269	2026-01-20 11:34:29.271
cmkmipbuk003313o8dizxqbn0	cmkmhjkg70000as8pwosymxt8	cmkmhjkg70000as8pwosymxt8	GLOBAL	55	50	100	0	Neutral / standard	["Profile 50% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 5, "deltaProfile": 0, "deltaResponse": 10, "deltaBehaviour": -5, "responseMedianHours": 0.2217347222222222, "responseSampleCount": 5, "missingResponseCount": 2, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 50}	MATCH_LIST_CREATED	cmkmhjkl60004as8parglk6ln	trustscore_mvp_v1	2026-01-20 11:35:27.547	2026-01-20 11:35:27.549
cmkmiszjy003c13o89kh0uq5v	cmkmhjkg70000as8pwosymxt8	cmkmhjkg70000as8pwosymxt8	GLOBAL	55	50	100	0	Neutral / standard	["Profile 50% complete", "Median response time: 0.2h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 5, "deltaProfile": 0, "deltaResponse": 10, "deltaBehaviour": -5, "responseMedianHours": 0.2217347222222222, "responseSampleCount": 5, "missingResponseCount": 2, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 50}	MATCH_LIST_CREATED	cmkmhjkl60004as8parglk6ln	trustscore_mvp_v1	2026-01-20 11:38:18.237	2026-01-20 11:38:18.238
cmkmj37pe000gsp76sw36rsjm	cmkmhq01b0001l0zlo8mzhe7v	cmkmhq01b0001l0zlo8mzhe7v	GLOBAL	50	50	\N	\N	New / No history yet	["Profile 50% complete", "No response data yet", "No pipeline history yet"]	{"intentCount": 0, "deltaProfile": 0, "deltaResponse": 0, "deltaBehaviour": 0, "responseMedianHours": null, "responseSampleCount": 0, "missingResponseCount": 0, "behaviourCompletionRatio": null, "profileCompletenessPercent": 50}	INITIAL	cmkmhjkmt0006as8pffhi7qej	trustscore_mvp_v1	2026-01-20 11:46:15.359	2026-01-20 11:46:15.363
cmkmk7mf90014sp76m2xu0kyb	cmkmhq01b0001l0zlo8mzhe7v	cmkmhq01b0001l0zlo8mzhe7v	GLOBAL	35	50	20	0	Low trust / problematic history	["Profile 50% complete", "Median response time: 168+h", "Pipeline hygiene: 0% intents with owner + final status"]	{"intentCount": 1, "deltaProfile": 0, "deltaResponse": -10, "deltaBehaviour": -5, "responseMedianHours": 1000, "responseSampleCount": 1, "missingResponseCount": 1, "behaviourCompletionRatio": 0, "profileCompletenessPercent": 50}	INTENT_CREATED	cmkmhjkmt0006as8pffhi7qej	trustscore_mvp_v1	2026-01-20 12:17:40.674	2026-01-20 12:17:40.677
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."User" (id, "orgId", email, role, "deactivatedAt", "passwordHash", "passwordUpdatedAt", "lastLoginAt", "createdAt") FROM stdin;
cmkmhjkl60004as8parglk6ln	cmkmhjkg70000as8pwosymxt8	user1@enabion.com	Owner	\N	scrypt$16384$8$1$d322f2eeab33965dea07930a4c03602f$39273132e4ad640e29732c89d6cd4b5726e143513e875547fae9e91f55feda6830ac81e1a107e27cd3af9fefa88707c20e8fdba93a394a4dadd461e8ee7dceea	2026-01-20 11:07:59.225	2026-01-20 11:52:12.693	2026-01-20 11:02:59.322
cmkmhjkmt0006as8pffhi7qej	cmkmhq01b0001l0zlo8mzhe7v	user2@enabion.com	Owner	\N	scrypt$16384$8$1$d396a293378fb3ffc1a929525874418f$a276c1af5eb6a9706158717425bee366a37e43127be231b714d3599fec96a6e6529165b7e1045650b5efd6f8b043f721256a8e0c8f205091569161632e39ccd3	2026-01-20 11:07:59.225	2026-01-20 12:15:49.807	2026-01-20 11:02:59.382
cmkmhjkog0008as8pzqd9qntz	cmkmhq01f0002l0zlsbq87413	user3@enabion.com	Owner	\N	scrypt$16384$8$1$278b1597ba35f975c01c1fed0f0d9d77$d81d2dc53c91102034dfd633a1a00239654a5a796d6f505c61c02d7552ee6ba6222e011bf818a4f8edafa9153a2f91a2eed68f1bea1d2b0af120e2d2feb9dfda	2026-01-20 11:07:59.225	2026-01-20 11:02:59.093	2026-01-20 11:02:59.44
cmkmhjkj80002as8pcub1p8ou	cmkmhjkg70000as8pwosymxt8	admin@enabion.com	Owner	\N	scrypt$16384$8$1$40a30dd077bf02bfdfd16a305ffaa446$a61136dc0475be24c48bc01ddeb6c3993ac3e4f862c60fba14fa7d5889a8207443a404db6cc12f20817aec81ae749fc507338db9928c04e9a46b4caa1fb39356	2026-01-20 11:07:59.225	2026-01-20 11:21:20.594	2026-01-20 11:02:59.252
\.


--
-- Data for Name: UserOnboardingState; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."UserOnboardingState" (id, "orgId", "userId", version, "currentStep", "completedSteps", "startedAt", "completedAt", "updatedAt") FROM stdin;
cmkmi0a7j000a13o8ex3gromb	cmkmhjkg70000as8pwosymxt8	cmkmhjkl60004as8parglk6ln	R1.0	how_it_works	[]	2026-01-20 11:15:59.023	\N	2026-01-20 11:15:59.023
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
69573301-66e5-4bf6-8ae9-633647d85c70	d36186bdb0a946d54792dc0da87f0a7cab92e81c35ea065ff7d9e22f8f0ee38b	2026-01-20 10:04:54.662635+00	20260108160000_add_intent_paste_fields		\N	2026-01-20 10:04:54.662635+00	0
e9bdca5e-5087-4dfb-9a25-8ec17383abe2	d1e0b4b7b90acbdfecede3406b646b256bdbf182c6bd893c3e44431a953c986b	\N	20251215203010_add_event_table	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20251215203010_add_event_table\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "Organization" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"Organization\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(434), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20251215203010_add_event_table"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20251215203010_add_event_table"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-01-20 09:56:39.359565+00	2026-01-20 09:53:58.605486+00	0
619d2987-0f2a-4d98-8ce3-7d0d87503763	52eb12cf5c062761ebc4d741d8452f7657c865d5b5af411af856ad2a0e64af29	2026-01-20 10:04:56.010993+00	20260109130000_add_intent_list_fields		\N	2026-01-20 10:04:56.010993+00	0
0997d23e-76f4-46dd-8b7d-5e6b36a226c1	d1e0b4b7b90acbdfecede3406b646b256bdbf182c6bd893c3e44431a953c986b	\N	20251215203010_add_event_table	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20251215203010_add_event_table\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "Organization" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"Organization\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(434), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20251215203010_add_event_table"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20251215203010_add_event_table"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-01-20 10:04:43.212411+00	2026-01-20 09:56:50.198093+00	0
ebe6a8ae-dfc1-4cfb-af8a-c1eaf74a55de	d1e0b4b7b90acbdfecede3406b646b256bdbf182c6bd893c3e44431a953c986b	2026-01-20 10:04:43.215305+00	20251215203010_add_event_table		\N	2026-01-20 10:04:43.215305+00	0
567a14d5-335a-4375-b59e-29861bee42bf	80d9b493a19eb4733e00a774dd152b8292ae5d2ad99562b1fada7bf62a53cb95	2026-01-20 10:04:44.587317+00	20251217_make_lifecycle_required		\N	2026-01-20 10:04:44.587317+00	0
7b67555b-751f-47fb-a5ee-f9b83dfd41fc	9467b83f8b636cbd9f9c7cf5770d0dfbbb3fcd03edc2bbd042a8d28e8d960457	2026-01-20 10:04:46.051357+00	20251218_add_blobstore		\N	2026-01-20 10:04:46.051357+00	0
997b668d-e842-4688-a160-562db5dc2bae	3c05e88f6329d8e73a7adfeafdadc75420af59cfbeed3c453fb0ecba41e88948	2026-01-20 10:04:47.458376+00	20251219141000_add_password_reset_tokens		\N	2026-01-20 10:04:47.458376+00	0
77d43475-2f5f-45c4-aad8-51f4760f8dcf	77ca0523c7b8f8e59181f1aa73fc344aa258e78fdd8414d61b291a2a97be59a7	2026-01-20 10:04:48.924744+00	20251219141500_add_auth_sessions		\N	2026-01-20 10:04:48.924744+00	0
973e3747-4c0a-4248-947f-064ed81f7244	c20cec22f046d2cd9bc0f67e7effc54c95a1107e5fd1512c6f33e7cbb4ba2f67	2026-01-20 10:04:50.202818+00	20260107173000_add_org_status		\N	2026-01-20 10:04:50.202818+00	0
eb702b8b-6600-4c53-87ae-55621a39515f	c20093dbc7ba0bd1cd6986a2cfa267effb2fe308d0ab29600dfeffc9545eddb1	2026-01-20 10:04:51.571871+00	20260107190000_adminpanel_org_settings		\N	2026-01-20 10:04:51.571871+00	0
4b42b182-05db-48ee-a386-43cb5a62f57a	f5aa2489c3afe48e98ce8445146d3fc7d77bf8e59c25bc7d6ea2b436f15fa252	2026-01-20 10:04:53.270043+00	20260108150000_add_intents		\N	2026-01-20 10:04:53.270043+00	0
24e27e31-4512-4dca-ba00-2720e5a86c1a	ec53bb71746aa015f0b7c44c805f0e4b6e8fad33070a22159c3fb6a9f3bbec52	2026-01-20 10:04:57.398811+00	20260110120000_add_attachment_indexes		\N	2026-01-20 10:04:57.398811+00	0
637002ed-c191-4fb5-b5c6-739956e8b837	21a737563c2fccb7556263e3e11637cd008cf1181d96fea15693a01b772acecb	2026-01-20 10:04:58.634912+00	20260110153000_add_nda_records		\N	2026-01-20 10:04:58.634912+00	0
75d5fb5c-859e-4125-8fb1-fc7e8ea21198	9caee31888214570b3def0c8cdb6f89b78d3f8ce0f66307ea0156d48d3b5eb86	2026-01-20 10:04:59.821454+00	20260111120000_add_intent_share_links		\N	2026-01-20 10:04:59.821454+00	0
a2e531a2-644f-4e86-bc74-6442f9b9acec	577f7bf696ad25d668834167927c38a3426d35b9a58d4253b8db8b62c124cf75	2026-01-20 10:05:01.075473+00	20260115130000_add_theme_palettes		\N	2026-01-20 10:05:01.075473+00	0
48540e6d-dacf-48a1-8c7d-b4090ade3cfd	0d3aea243ec99f13a2ee967a5b3d8fea3282e6a3dc0eacedbc8eb43e5f77cf8c	2026-01-20 10:05:02.835346+00	20260116100000_add_avatar_suggestion_feedback		\N	2026-01-20 10:05:02.835346+00	0
c1b01c82-c04b-436c-9d7f-e5f3b2b4e09e	6e1ca8d3a7416c0580d6a65eabe74ff878379fa3c14a6b8f7e282a39321bb48b	2026-01-20 10:05:04.670839+00	20260116130000_add_intent_ai_access		\N	2026-01-20 10:05:04.670839+00	0
ff20c6b9-bd15-4219-9fae-a81593846c2d	311aa047de6771279d1cf6e150babb8424f04be7cebe6ab74e6c3b64704348f9	2026-01-20 10:05:06.219523+00	20260117150000_remove_org_theme_palette		\N	2026-01-20 10:05:06.219523+00	0
91c37116-eb06-4ff6-87c7-94e0d5d4482e	2f81a153929da48e70836fb4ed27a1a4a26110f493a9396ed0493d1b5995d68a	2026-01-20 10:05:07.729904+00	20260120120000_add_intent_name_number		\N	2026-01-20 10:05:07.729904+00	0
bab0a91a-5856-486f-968d-7c41dc726f2b	efcf51d032bb6159cd1605532b49a678206421e8a86ef7b45684c670ac8d23b2	2026-01-20 10:05:09.131531+00	20260122120000_add_ai_rate_limit_window		\N	2026-01-20 10:05:09.131531+00	0
cf2a8a22-5568-408f-b5d4-fc83c2c1215a	54ada84d753fefa73b7f08fbc30028691cdccced61577a7ac7d27857a17b3a1e	2026-01-20 10:05:10.599405+00	20260122220000_add_avatar_suggestions		\N	2026-01-20 10:05:10.599405+00	0
b7eff2f3-607f-43b0-8e84-59d7ebc6d0ec	659222957b446bc3c1e1869f611563fdf5594ba46e9f1f74ab303ce2da716966	2026-01-20 10:05:11.994943+00	20260123090000_add_intent_coach_history		\N	2026-01-20 10:05:11.994943+00	0
ba9ee484-9f73-42db-bb0e-6daaebe71ff7	903fb1c95c1b1ac7100700a63d36dc84e9fccfb6fe3be6fde3a18835a198040d	2026-01-20 10:05:13.703418+00	20260123120000_add_system_org_avatars		\N	2026-01-20 10:05:13.703418+00	0
ce121f00-264c-4c21-91b0-8811a810e9e2	36331068bfcdc204ff0afe777fc1fc36c87c0ed048861b85b660c629f432751c	2026-01-20 10:05:15.098572+00	20260124120000_add_org_provider_profile		\N	2026-01-20 10:05:15.098572+00	0
197e843c-eb34-453a-934b-a4e548e332bf	31afb0dc327e93d31c915620dfecaaae16cb62bcdecc2d0f94c579e62550acda	2026-01-20 10:05:16.614273+00	20260125120000_add_matching_engine		\N	2026-01-20 10:05:16.614273+00	0
f8761ea3-1b17-4152-b9f8-ea789016b38e	ef1ad9a6babda6a5779a2638127658d05420c17fce09ea0dcf2aa2746210b9a0	2026-01-20 10:05:18.135738+00	20260125170000_add_match_feedback_action		\N	2026-01-20 10:05:18.135738+00	0
e072ba00-9811-4303-a4b8-0b571d4d5885	a128fec6825f3e70817504a003b591c77af52ee6bce0dac8e688ddf71715004d	2026-01-20 10:05:19.544814+00	20260126120000_add_trustscore_snapshot		\N	2026-01-20 10:05:19.544814+00	0
9bfdd5e6-b098-4e00-9cac-f59a0d723b46	6c08e47d22d639231eb475d57c9a379aae320bf52512e6b74b8ad2747673efef	2026-01-20 10:05:20.934282+00	20260127120000_add_intent_recipients		\N	2026-01-20 10:05:20.934282+00	0
\.


--
-- Name: Intent_intentNumber_seq; Type: SEQUENCE SET; Schema: public; Owner: enabion
--

SELECT pg_catalog.setval('public."Intent_intentNumber_seq"', 6, true);


--
-- Name: AiRateLimitWindow AiRateLimitWindow_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."AiRateLimitWindow"
    ADD CONSTRAINT "AiRateLimitWindow_pkey" PRIMARY KEY (id);


--
-- Name: Attachment Attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_pkey" PRIMARY KEY (id);


--
-- Name: AvatarSuggestionFeedback AvatarSuggestionFeedback_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."AvatarSuggestionFeedback"
    ADD CONSTRAINT "AvatarSuggestionFeedback_pkey" PRIMARY KEY (id);


--
-- Name: AvatarSuggestion AvatarSuggestion_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."AvatarSuggestion"
    ADD CONSTRAINT "AvatarSuggestion_pkey" PRIMARY KEY (id);


--
-- Name: Blob Blob_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Blob"
    ADD CONSTRAINT "Blob_pkey" PRIMARY KEY (id);


--
-- Name: Event Event_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_pkey" PRIMARY KEY (id);


--
-- Name: IntentCoachRun IntentCoachRun_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentCoachRun"
    ADD CONSTRAINT "IntentCoachRun_pkey" PRIMARY KEY (id);


--
-- Name: IntentRecipient IntentRecipient_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentRecipient"
    ADD CONSTRAINT "IntentRecipient_pkey" PRIMARY KEY (id);


--
-- Name: IntentShareLink IntentShareLink_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentShareLink"
    ADD CONSTRAINT "IntentShareLink_pkey" PRIMARY KEY (id);


--
-- Name: Intent Intent_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_pkey" PRIMARY KEY (id);


--
-- Name: MatchFeedback MatchFeedback_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."MatchFeedback"
    ADD CONSTRAINT "MatchFeedback_pkey" PRIMARY KEY (id);


--
-- Name: MatchList MatchList_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."MatchList"
    ADD CONSTRAINT "MatchList_pkey" PRIMARY KEY (id);


--
-- Name: NdaAcceptance NdaAcceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."NdaAcceptance"
    ADD CONSTRAINT "NdaAcceptance_pkey" PRIMARY KEY (id);


--
-- Name: NdaDocument NdaDocument_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."NdaDocument"
    ADD CONSTRAINT "NdaDocument_pkey" PRIMARY KEY (id);


--
-- Name: OrgAvatarProfile OrgAvatarProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."OrgAvatarProfile"
    ADD CONSTRAINT "OrgAvatarProfile_pkey" PRIMARY KEY (id);


--
-- Name: OrgLeadQualification OrgLeadQualification_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."OrgLeadQualification"
    ADD CONSTRAINT "OrgLeadQualification_pkey" PRIMARY KEY (id);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: ThemePaletteRevision ThemePaletteRevision_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."ThemePaletteRevision"
    ADD CONSTRAINT "ThemePaletteRevision_pkey" PRIMARY KEY (id);


--
-- Name: ThemePalette ThemePalette_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."ThemePalette"
    ADD CONSTRAINT "ThemePalette_pkey" PRIMARY KEY (id);


--
-- Name: TrustScoreSnapshot TrustScoreSnapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."TrustScoreSnapshot"
    ADD CONSTRAINT "TrustScoreSnapshot_pkey" PRIMARY KEY (id);


--
-- Name: UserOnboardingState UserOnboardingState_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."UserOnboardingState"
    ADD CONSTRAINT "UserOnboardingState_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AiRateLimitWindow_key_windowStart_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "AiRateLimitWindow_key_windowStart_key" ON public."AiRateLimitWindow" USING btree (key, "windowStart");


--
-- Name: AiRateLimitWindow_windowStart_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "AiRateLimitWindow_windowStart_idx" ON public."AiRateLimitWindow" USING btree ("windowStart");


--
-- Name: Attachment_intentId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Attachment_intentId_idx" ON public."Attachment" USING btree ("intentId");


--
-- Name: Attachment_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Attachment_orgId_idx" ON public."Attachment" USING btree ("orgId");


--
-- Name: Attachment_orgId_intentId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Attachment_orgId_intentId_createdAt_idx" ON public."Attachment" USING btree ("orgId", "intentId", "createdAt");


--
-- Name: AvatarSuggestionFeedback_orgId_intentId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "AvatarSuggestionFeedback_orgId_intentId_createdAt_idx" ON public."AvatarSuggestionFeedback" USING btree ("orgId", "intentId", "createdAt");


--
-- Name: AvatarSuggestionFeedback_suggestionId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "AvatarSuggestionFeedback_suggestionId_createdAt_idx" ON public."AvatarSuggestionFeedback" USING btree ("suggestionId", "createdAt");


--
-- Name: AvatarSuggestion_intentId_status_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "AvatarSuggestion_intentId_status_idx" ON public."AvatarSuggestion" USING btree ("intentId", status);


--
-- Name: AvatarSuggestion_orgId_intentId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "AvatarSuggestion_orgId_intentId_createdAt_idx" ON public."AvatarSuggestion" USING btree ("orgId", "intentId", "createdAt");


--
-- Name: AvatarSuggestion_orgId_status_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "AvatarSuggestion_orgId_status_idx" ON public."AvatarSuggestion" USING btree ("orgId", status);


--
-- Name: AvatarSuggestion_orgId_subjectType_subjectId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "AvatarSuggestion_orgId_subjectType_subjectId_createdAt_idx" ON public."AvatarSuggestion" USING btree ("orgId", "subjectType", "subjectId", "createdAt");


--
-- Name: Blob_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Blob_orgId_idx" ON public."Blob" USING btree ("orgId");


--
-- Name: Blob_orgId_objectKey_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Blob_orgId_objectKey_idx" ON public."Blob" USING btree ("orgId", "objectKey");


--
-- Name: Event_correlationId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_correlationId_idx" ON public."Event" USING btree ("correlationId");


--
-- Name: Event_occurredAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_occurredAt_idx" ON public."Event" USING btree ("occurredAt");


--
-- Name: Event_orgId_subjectId_type_occurredAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_orgId_subjectId_type_occurredAt_idx" ON public."Event" USING btree ("orgId", "subjectId", type, "occurredAt");


--
-- Name: IntentCoachRun_intentId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentCoachRun_intentId_createdAt_idx" ON public."IntentCoachRun" USING btree ("intentId", "createdAt");


--
-- Name: IntentCoachRun_orgId_intentId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentCoachRun_orgId_intentId_createdAt_idx" ON public."IntentCoachRun" USING btree ("orgId", "intentId", "createdAt");


--
-- Name: IntentRecipient_intentId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentRecipient_intentId_createdAt_idx" ON public."IntentRecipient" USING btree ("intentId", "createdAt");


--
-- Name: IntentRecipient_intentId_recipientOrgId_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "IntentRecipient_intentId_recipientOrgId_key" ON public."IntentRecipient" USING btree ("intentId", "recipientOrgId");


--
-- Name: IntentRecipient_recipientOrgId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentRecipient_recipientOrgId_createdAt_idx" ON public."IntentRecipient" USING btree ("recipientOrgId", "createdAt");


--
-- Name: IntentRecipient_senderOrgId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentRecipient_senderOrgId_createdAt_idx" ON public."IntentRecipient" USING btree ("senderOrgId", "createdAt");


--
-- Name: IntentShareLink_expiresAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentShareLink_expiresAt_idx" ON public."IntentShareLink" USING btree ("expiresAt");


--
-- Name: IntentShareLink_orgId_intentId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentShareLink_orgId_intentId_idx" ON public."IntentShareLink" USING btree ("orgId", "intentId");


--
-- Name: IntentShareLink_revokedAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentShareLink_revokedAt_idx" ON public."IntentShareLink" USING btree ("revokedAt");


--
-- Name: IntentShareLink_tokenHashSha256_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "IntentShareLink_tokenHashSha256_key" ON public."IntentShareLink" USING btree ("tokenHashSha256");


--
-- Name: Intent_createdByUserId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_createdByUserId_idx" ON public."Intent" USING btree ("createdByUserId");


--
-- Name: Intent_intentNumber_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "Intent_intentNumber_key" ON public."Intent" USING btree ("intentNumber");


--
-- Name: Intent_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_idx" ON public."Intent" USING btree ("orgId");


--
-- Name: Intent_orgId_intentName_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "Intent_orgId_intentName_key" ON public."Intent" USING btree ("orgId", "intentName");


--
-- Name: Intent_orgId_language_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_language_idx" ON public."Intent" USING btree ("orgId", language);


--
-- Name: Intent_orgId_lastActivityAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_lastActivityAt_idx" ON public."Intent" USING btree ("orgId", "lastActivityAt");


--
-- Name: Intent_orgId_ownerUserId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_ownerUserId_idx" ON public."Intent" USING btree ("orgId", "ownerUserId");


--
-- Name: Intent_orgId_stage_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_stage_idx" ON public."Intent" USING btree ("orgId", stage);


--
-- Name: Intent_orgId_stage_lastActivityAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_stage_lastActivityAt_idx" ON public."Intent" USING btree ("orgId", stage, "lastActivityAt");


--
-- Name: MatchFeedback_candidateOrgId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "MatchFeedback_candidateOrgId_createdAt_idx" ON public."MatchFeedback" USING btree ("candidateOrgId", "createdAt");


--
-- Name: MatchFeedback_orgId_intentId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "MatchFeedback_orgId_intentId_createdAt_idx" ON public."MatchFeedback" USING btree ("orgId", "intentId", "createdAt");


--
-- Name: MatchFeedback_orgId_matchListId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "MatchFeedback_orgId_matchListId_idx" ON public."MatchFeedback" USING btree ("orgId", "matchListId");


--
-- Name: MatchList_orgId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "MatchList_orgId_createdAt_idx" ON public."MatchList" USING btree ("orgId", "createdAt");


--
-- Name: MatchList_orgId_intentId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "MatchList_orgId_intentId_createdAt_idx" ON public."MatchList" USING btree ("orgId", "intentId", "createdAt");


--
-- Name: NdaAcceptance_acceptedByUserId_acceptedAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "NdaAcceptance_acceptedByUserId_acceptedAt_idx" ON public."NdaAcceptance" USING btree ("acceptedByUserId", "acceptedAt");


--
-- Name: NdaAcceptance_orgId_counterpartyOrgId_ndaType_ndaVersion_en_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "NdaAcceptance_orgId_counterpartyOrgId_ndaType_ndaVersion_en_key" ON public."NdaAcceptance" USING btree ("orgId", "counterpartyOrgId", "ndaType", "ndaVersion", "enHashSha256");


--
-- Name: NdaAcceptance_orgId_ndaType_ndaVersion_enHashSha256_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "NdaAcceptance_orgId_ndaType_ndaVersion_enHashSha256_idx" ON public."NdaAcceptance" USING btree ("orgId", "ndaType", "ndaVersion", "enHashSha256");


--
-- Name: NdaDocument_ndaType_isActive_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "NdaDocument_ndaType_isActive_idx" ON public."NdaDocument" USING btree ("ndaType", "isActive");


--
-- Name: NdaDocument_ndaVersion_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "NdaDocument_ndaVersion_key" ON public."NdaDocument" USING btree ("ndaVersion");


--
-- Name: OrgAvatarProfile_orgId_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "OrgAvatarProfile_orgId_key" ON public."OrgAvatarProfile" USING btree ("orgId");


--
-- Name: OrgLeadQualification_orgId_fitBand_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "OrgLeadQualification_orgId_fitBand_idx" ON public."OrgLeadQualification" USING btree ("orgId", "fitBand");


--
-- Name: OrgLeadQualification_orgId_intentId_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "OrgLeadQualification_orgId_intentId_key" ON public."OrgLeadQualification" USING btree ("orgId", "intentId");


--
-- Name: OrgLeadQualification_orgId_priority_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "OrgLeadQualification_orgId_priority_idx" ON public."OrgLeadQualification" USING btree ("orgId", priority);


--
-- Name: Organization_slug_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "Organization_slug_key" ON public."Organization" USING btree (slug);


--
-- Name: Organization_trustScoreLatestId_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "Organization_trustScoreLatestId_key" ON public."Organization" USING btree ("trustScoreLatestId");


--
-- Name: PasswordResetToken_expiresAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "PasswordResetToken_expiresAt_idx" ON public."PasswordResetToken" USING btree ("expiresAt");


--
-- Name: PasswordResetToken_tokenHash_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "PasswordResetToken_tokenHash_key" ON public."PasswordResetToken" USING btree ("tokenHash");


--
-- Name: PasswordResetToken_userId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "PasswordResetToken_userId_idx" ON public."PasswordResetToken" USING btree ("userId");


--
-- Name: Session_expiresAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Session_expiresAt_idx" ON public."Session" USING btree ("expiresAt");


--
-- Name: Session_tokenHash_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "Session_tokenHash_key" ON public."Session" USING btree ("tokenHash");


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: ThemePaletteRevision_paletteId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "ThemePaletteRevision_paletteId_createdAt_idx" ON public."ThemePaletteRevision" USING btree ("paletteId", "createdAt");


--
-- Name: ThemePaletteRevision_paletteId_revision_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "ThemePaletteRevision_paletteId_revision_key" ON public."ThemePaletteRevision" USING btree ("paletteId", revision);


--
-- Name: ThemePalette_slug_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "ThemePalette_slug_key" ON public."ThemePalette" USING btree (slug);


--
-- Name: TrustScoreSnapshot_orgId_computedAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "TrustScoreSnapshot_orgId_computedAt_idx" ON public."TrustScoreSnapshot" USING btree ("orgId", "computedAt");


--
-- Name: TrustScoreSnapshot_orgId_subjectOrgId_computedAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "TrustScoreSnapshot_orgId_subjectOrgId_computedAt_idx" ON public."TrustScoreSnapshot" USING btree ("orgId", "subjectOrgId", "computedAt");


--
-- Name: TrustScoreSnapshot_subjectOrgId_computedAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "TrustScoreSnapshot_subjectOrgId_computedAt_idx" ON public."TrustScoreSnapshot" USING btree ("subjectOrgId", "computedAt");


--
-- Name: UserOnboardingState_orgId_userId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "UserOnboardingState_orgId_userId_idx" ON public."UserOnboardingState" USING btree ("orgId", "userId");


--
-- Name: UserOnboardingState_orgId_userId_version_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "UserOnboardingState_orgId_userId_version_key" ON public."UserOnboardingState" USING btree ("orgId", "userId", version);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Attachment Attachment_blobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_blobId_fkey" FOREIGN KEY ("blobId") REFERENCES public."Blob"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Attachment Attachment_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AvatarSuggestionFeedback AvatarSuggestionFeedback_intentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."AvatarSuggestionFeedback"
    ADD CONSTRAINT "AvatarSuggestionFeedback_intentId_fkey" FOREIGN KEY ("intentId") REFERENCES public."Intent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AvatarSuggestionFeedback AvatarSuggestionFeedback_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."AvatarSuggestionFeedback"
    ADD CONSTRAINT "AvatarSuggestionFeedback_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AvatarSuggestionFeedback AvatarSuggestionFeedback_suggestionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."AvatarSuggestionFeedback"
    ADD CONSTRAINT "AvatarSuggestionFeedback_suggestionId_fkey" FOREIGN KEY ("suggestionId") REFERENCES public."AvatarSuggestion"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AvatarSuggestionFeedback AvatarSuggestionFeedback_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."AvatarSuggestionFeedback"
    ADD CONSTRAINT "AvatarSuggestionFeedback_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AvatarSuggestion AvatarSuggestion_coachRunId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."AvatarSuggestion"
    ADD CONSTRAINT "AvatarSuggestion_coachRunId_fkey" FOREIGN KEY ("coachRunId") REFERENCES public."IntentCoachRun"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AvatarSuggestion AvatarSuggestion_intentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."AvatarSuggestion"
    ADD CONSTRAINT "AvatarSuggestion_intentId_fkey" FOREIGN KEY ("intentId") REFERENCES public."Intent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AvatarSuggestion AvatarSuggestion_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."AvatarSuggestion"
    ADD CONSTRAINT "AvatarSuggestion_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Blob Blob_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Blob"
    ADD CONSTRAINT "Blob_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Event Event_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentCoachRun IntentCoachRun_intentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentCoachRun"
    ADD CONSTRAINT "IntentCoachRun_intentId_fkey" FOREIGN KEY ("intentId") REFERENCES public."Intent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentCoachRun IntentCoachRun_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentCoachRun"
    ADD CONSTRAINT "IntentCoachRun_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentRecipient IntentRecipient_intentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentRecipient"
    ADD CONSTRAINT "IntentRecipient_intentId_fkey" FOREIGN KEY ("intentId") REFERENCES public."Intent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentRecipient IntentRecipient_ndaRequestedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentRecipient"
    ADD CONSTRAINT "IntentRecipient_ndaRequestedByUserId_fkey" FOREIGN KEY ("ndaRequestedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: IntentRecipient IntentRecipient_recipientOrgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentRecipient"
    ADD CONSTRAINT "IntentRecipient_recipientOrgId_fkey" FOREIGN KEY ("recipientOrgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentRecipient IntentRecipient_senderOrgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentRecipient"
    ADD CONSTRAINT "IntentRecipient_senderOrgId_fkey" FOREIGN KEY ("senderOrgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentShareLink IntentShareLink_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentShareLink"
    ADD CONSTRAINT "IntentShareLink_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentShareLink IntentShareLink_intentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentShareLink"
    ADD CONSTRAINT "IntentShareLink_intentId_fkey" FOREIGN KEY ("intentId") REFERENCES public."Intent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentShareLink IntentShareLink_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentShareLink"
    ADD CONSTRAINT "IntentShareLink_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentShareLink IntentShareLink_revokedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentShareLink"
    ADD CONSTRAINT "IntentShareLink_revokedByUserId_fkey" FOREIGN KEY ("revokedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Intent Intent_aiAllowL2SetByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_aiAllowL2SetByUserId_fkey" FOREIGN KEY ("aiAllowL2SetByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Intent Intent_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Intent Intent_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Intent Intent_ownerUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_ownerUserId_fkey" FOREIGN KEY ("ownerUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MatchFeedback MatchFeedback_actorUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."MatchFeedback"
    ADD CONSTRAINT "MatchFeedback_actorUserId_fkey" FOREIGN KEY ("actorUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MatchFeedback MatchFeedback_candidateOrgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."MatchFeedback"
    ADD CONSTRAINT "MatchFeedback_candidateOrgId_fkey" FOREIGN KEY ("candidateOrgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MatchFeedback MatchFeedback_intentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."MatchFeedback"
    ADD CONSTRAINT "MatchFeedback_intentId_fkey" FOREIGN KEY ("intentId") REFERENCES public."Intent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MatchFeedback MatchFeedback_matchListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."MatchFeedback"
    ADD CONSTRAINT "MatchFeedback_matchListId_fkey" FOREIGN KEY ("matchListId") REFERENCES public."MatchList"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MatchFeedback MatchFeedback_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."MatchFeedback"
    ADD CONSTRAINT "MatchFeedback_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MatchList MatchList_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."MatchList"
    ADD CONSTRAINT "MatchList_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MatchList MatchList_intentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."MatchList"
    ADD CONSTRAINT "MatchList_intentId_fkey" FOREIGN KEY ("intentId") REFERENCES public."Intent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MatchList MatchList_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."MatchList"
    ADD CONSTRAINT "MatchList_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NdaAcceptance NdaAcceptance_acceptedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."NdaAcceptance"
    ADD CONSTRAINT "NdaAcceptance_acceptedByUserId_fkey" FOREIGN KEY ("acceptedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NdaAcceptance NdaAcceptance_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."NdaAcceptance"
    ADD CONSTRAINT "NdaAcceptance_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrgAvatarProfile OrgAvatarProfile_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."OrgAvatarProfile"
    ADD CONSTRAINT "OrgAvatarProfile_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrgAvatarProfile OrgAvatarProfile_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."OrgAvatarProfile"
    ADD CONSTRAINT "OrgAvatarProfile_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrgAvatarProfile OrgAvatarProfile_updatedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."OrgAvatarProfile"
    ADD CONSTRAINT "OrgAvatarProfile_updatedByUserId_fkey" FOREIGN KEY ("updatedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrgLeadQualification OrgLeadQualification_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."OrgLeadQualification"
    ADD CONSTRAINT "OrgLeadQualification_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrgLeadQualification OrgLeadQualification_intentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."OrgLeadQualification"
    ADD CONSTRAINT "OrgLeadQualification_intentId_fkey" FOREIGN KEY ("intentId") REFERENCES public."Intent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrgLeadQualification OrgLeadQualification_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."OrgLeadQualification"
    ADD CONSTRAINT "OrgLeadQualification_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrgLeadQualification OrgLeadQualification_updatedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."OrgLeadQualification"
    ADD CONSTRAINT "OrgLeadQualification_updatedByUserId_fkey" FOREIGN KEY ("updatedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Organization Organization_trustScoreLatestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_trustScoreLatestId_fkey" FOREIGN KEY ("trustScoreLatestId") REFERENCES public."TrustScoreSnapshot"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ThemePaletteRevision ThemePaletteRevision_paletteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."ThemePaletteRevision"
    ADD CONSTRAINT "ThemePaletteRevision_paletteId_fkey" FOREIGN KEY ("paletteId") REFERENCES public."ThemePalette"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TrustScoreSnapshot TrustScoreSnapshot_actorUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."TrustScoreSnapshot"
    ADD CONSTRAINT "TrustScoreSnapshot_actorUserId_fkey" FOREIGN KEY ("actorUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TrustScoreSnapshot TrustScoreSnapshot_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."TrustScoreSnapshot"
    ADD CONSTRAINT "TrustScoreSnapshot_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TrustScoreSnapshot TrustScoreSnapshot_subjectOrgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."TrustScoreSnapshot"
    ADD CONSTRAINT "TrustScoreSnapshot_subjectOrgId_fkey" FOREIGN KEY ("subjectOrgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserOnboardingState UserOnboardingState_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."UserOnboardingState"
    ADD CONSTRAINT "UserOnboardingState_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserOnboardingState UserOnboardingState_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."UserOnboardingState"
    ADD CONSTRAINT "UserOnboardingState_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict XxJWdyNnoedAfIP6MEmdaW0zAUdpZagCiGWd4PJVnKx9MNcb3X6qh7CrdFyUjMr

