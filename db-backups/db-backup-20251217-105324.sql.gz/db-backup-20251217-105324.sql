--
-- PostgreSQL database dump
--

\restrict hlQUOiKH2FW0HyojdLYhs3cQNp490YhdUIMSWZOaEuob9Bvr2ITzR9WHrdONLKD

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Event; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Event" (
    id text NOT NULL,
    "schemaVersion" integer NOT NULL,
    type text NOT NULL,
    "occurredAt" timestamp(3) without time zone NOT NULL,
    "recordedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "orgId" text NOT NULL,
    "actorUserId" text,
    "actorOrgId" text,
    "subjectType" text NOT NULL,
    "subjectId" text NOT NULL,
    "lifecycleStep" text,
    "pipelineStage" text,
    channel text NOT NULL,
    "correlationId" text NOT NULL,
    payload jsonb NOT NULL
);


ALTER TABLE public."Event" OWNER TO enabion;

--
-- Name: Organization; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."Organization" OWNER TO enabion;

--
-- Name: User; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."User" OWNER TO enabion;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO enabion;

--
-- Data for Name: Event; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Event" (id, "schemaVersion", type, "occurredAt", "recordedAt", "orgId", "actorUserId", "actorOrgId", "subjectType", "subjectId", "lifecycleStep", "pipelineStage", channel, "correlationId", payload) FROM stdin;
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Organization" (id, name, "createdAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."User" (id, "orgId", email, role, "createdAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4b94872d-a3e2-46cb-b7a6-7f5f6bd9b084	2b1715731cd35fd42cffbb99a75344acbacc5a25469ff59fc6fd4bb355c8b042	2025-12-15 20:05:00.958438+00	20251215203010_add_event_table	\N	\N	2025-12-15 20:05:00.93144+00	1
\.


--
-- Name: Event Event_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_pkey" PRIMARY KEY (id);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: User User_email_key; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_email_key" UNIQUE (email);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Event_orgId_subjectId_type_occurredAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_orgId_subjectId_type_occurredAt_idx" ON public."Event" USING btree ("orgId", "subjectId", type, "occurredAt");


--
-- Name: Event Event_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict hlQUOiKH2FW0HyojdLYhs3cQNp490YhdUIMSWZOaEuob9Bvr2ITzR9WHrdONLKD

