--
-- PostgreSQL database dump
--

\restrict NbVYUBkD3OF0vJkmekYf10zxxjnyq6asdf0clLPYQFdsgSMLkBvP5llik2vmlkv

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AttachmentSource; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AttachmentSource" AS ENUM (
    'email_ingest',
    'manual_upload',
    'export'
);


ALTER TYPE public."AttachmentSource" OWNER TO enabion;

--
-- Name: BlobStorageDriver; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."BlobStorageDriver" AS ENUM (
    'local',
    's3'
);


ALTER TYPE public."BlobStorageDriver" OWNER TO enabion;

--
-- Name: ConfidentialityLevel; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."ConfidentialityLevel" AS ENUM (
    'L1',
    'L2',
    'L3'
);


ALTER TYPE public."ConfidentialityLevel" OWNER TO enabion;

--
-- Name: IntentSource; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."IntentSource" AS ENUM (
    'manual',
    'paste',
    'email'
);


ALTER TYPE public."IntentSource" OWNER TO enabion;

--
-- Name: IntentStage; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."IntentStage" AS ENUM (
    'NEW',
    'CLARIFY',
    'MATCH',
    'COMMIT',
    'WON',
    'LOST'
);


ALTER TYPE public."IntentStage" OWNER TO enabion;

--
-- Name: OrganizationStatus; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."OrganizationStatus" AS ENUM (
    'ACTIVE',
    'SUSPENDED'
);


ALTER TYPE public."OrganizationStatus" OWNER TO enabion;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Attachment; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Attachment" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text,
    source public."AttachmentSource" DEFAULT 'manual_upload'::public."AttachmentSource" NOT NULL,
    filename text NOT NULL,
    "blobId" text NOT NULL,
    "createdByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Attachment" OWNER TO enabion;

--
-- Name: Blob; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Blob" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "storageDriver" public."BlobStorageDriver" DEFAULT 'local'::public."BlobStorageDriver" NOT NULL,
    "objectKey" text NOT NULL,
    "sizeBytes" integer NOT NULL,
    sha256 character(64) NOT NULL,
    "contentType" text NOT NULL,
    confidentiality public."ConfidentialityLevel" DEFAULT 'L1'::public."ConfidentialityLevel" NOT NULL,
    encrypted boolean DEFAULT false NOT NULL,
    "encryptionAlg" text,
    "encryptionKeyId" text,
    "encryptionIvB64" text,
    "encryptionTagB64" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Blob" OWNER TO enabion;

--
-- Name: Event; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Event" (
    id text NOT NULL,
    "schemaVersion" integer NOT NULL,
    type text NOT NULL,
    "occurredAt" timestamp(3) without time zone NOT NULL,
    "recordedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "orgId" text NOT NULL,
    "actorUserId" text,
    "actorOrgId" text,
    "subjectType" text NOT NULL,
    "subjectId" text NOT NULL,
    "lifecycleStep" text DEFAULT 'CLARIFY'::text NOT NULL,
    "pipelineStage" text DEFAULT 'NEW'::text NOT NULL,
    channel text NOT NULL,
    "correlationId" text NOT NULL,
    payload jsonb NOT NULL
);


ALTER TABLE public."Event" OWNER TO enabion;

--
-- Name: Intent; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Intent" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "createdByUserId" text NOT NULL,
    goal text NOT NULL,
    context text,
    scope text,
    kpi text,
    risks text,
    "deadlineAt" timestamp(3) without time zone,
    stage public."IntentStage" DEFAULT 'NEW'::public."IntentStage" NOT NULL,
    "confidentialityLevel" public."ConfidentialityLevel" DEFAULT 'L1'::public."ConfidentialityLevel" NOT NULL,
    source public."IntentSource" DEFAULT 'manual'::public."IntentSource" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    title text,
    "sourceTextRaw" text,
    "sourceTextSha256" character(64),
    "sourceTextLength" integer
);


ALTER TABLE public."Intent" OWNER TO enabion;

--
-- Name: Organization; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    slug text NOT NULL,
    "defaultLanguage" text DEFAULT 'EN'::text NOT NULL,
    "policyAiEnabled" boolean DEFAULT true NOT NULL,
    "policyShareLinksEnabled" boolean DEFAULT false NOT NULL,
    "policyEmailIngestEnabled" boolean DEFAULT false NOT NULL,
    status public."OrganizationStatus" DEFAULT 'ACTIVE'::public."OrganizationStatus" NOT NULL
);


ALTER TABLE public."Organization" OWNER TO enabion;

--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone
);


ALTER TABLE public."PasswordResetToken" OWNER TO enabion;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


ALTER TABLE public."Session" OWNER TO enabion;

--
-- Name: User; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "passwordHash" text,
    "passwordUpdatedAt" timestamp(3) without time zone,
    "lastLoginAt" timestamp(3) without time zone,
    "deactivatedAt" timestamp(3) without time zone
);


ALTER TABLE public."User" OWNER TO enabion;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO enabion;

--
-- Data for Name: Attachment; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Attachment" (id, "orgId", "intentId", source, filename, "blobId", "createdByUserId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Blob; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Blob" (id, "orgId", "storageDriver", "objectKey", "sizeBytes", sha256, "contentType", confidentiality, encrypted, "encryptionAlg", "encryptionKeyId", "encryptionIvB64", "encryptionTagB64", "createdAt") FROM stdin;
\.


--
-- Data for Name: Event; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Event" (id, "schemaVersion", type, "occurredAt", "recordedAt", "orgId", "actorUserId", "actorOrgId", "subjectType", "subjectId", "lifecycleStep", "pipelineStage", channel, "correlationId", payload) FROM stdin;
01KCW322DF84P22Q3CGW3GA29T	1	USER_SIGNED_UP	2025-12-19 19:58:16.494	2025-12-19 19:58:16.495	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW322DE2NR8R14VJRQ4RFC5	{"role": "Owner", "email": "info1@staadit.com", "orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdakp0p0005ut2uz4saqcrf", "payloadVersion": 1}
01KCW32H23AE8XH2MK87W8ZK82	1	USER_LOGGED_OUT	2025-12-19 19:58:31.49	2025-12-19 19:58:31.491	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW32H22S91HDZZTJQ84G8EZ	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdakp0p0005ut2uz4saqcrf", "payloadVersion": 1}
01KCW333YN1N9EH7CGWS6KC445	1	USER_LOGGED_IN	2025-12-19 19:58:50.837	2025-12-19 19:58:50.838	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW333YNYE7A0XFYRVSF64H9	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdalfiq0008ut2u50saciqk", "payloadVersion": 1}
01KCW33BG9KMDR0MKJ4X2VRGCW	1	USER_LOGGED_OUT	2025-12-19 19:58:58.569	2025-12-19 19:58:58.569	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW33BG9RTNRN6AV7159DBY0	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdalfiq0008ut2u50saciqk", "payloadVersion": 1}
01KCXCWPE6THSKE0BT0YVMXRGG	1	USER_LOGGED_IN	2025-12-20 08:09:20.582	2025-12-20 08:09:20.583	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCXCWPE6GMS4DXR4FR14894V	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmje0ourm000but2usyvwb2tw", "payloadVersion": 1}
01KCXCX7HAJMH1RMK2G8TS6JV0	1	USER_LOGGED_OUT	2025-12-20 08:09:38.089	2025-12-20 08:09:38.09	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCXCX7H93JEADJYDXS4QBEV8	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmje0ourm000but2usyvwb2tw", "payloadVersion": 1}
01KCXCXQ99DK0X205PVDWVGFW2	1	USER_SIGNED_UP	2025-12-20 08:09:54.217	2025-12-20 08:09:54.217	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXCXQ99EGVTD8PWW83GX75M	{"role": "Owner", "email": "info2@staadit.com", "orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0pkpz000hut2u9qbj5swy", "payloadVersion": 1}
01KCXD07PWVXAEBTQJ9ABPGN36	1	USER_LOGGED_OUT	2025-12-20 08:11:16.572	2025-12-20 08:11:16.572	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXD07PWP59TZC3V1F4R6DPD	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0pkpz000hut2u9qbj5swy", "payloadVersion": 1}
01KCXD6A60GEA8S5KK4FDGD0CF	1	USER_LOGGED_IN	2025-12-20 08:14:35.711	2025-12-20 08:14:35.712	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXD6A5ZCVATDQNA1XV1Y6RK	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0vlx7000kut2umcar3fvt", "payloadVersion": 1}
01KCXD6JGTMQFNJKQT49SWJ5BB	1	USER_LOGGED_OUT	2025-12-20 08:14:44.25	2025-12-20 08:14:44.25	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXD6JGT8PE45ETWP2SPS834	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0vlx7000kut2umcar3fvt", "payloadVersion": 1}
01KCXD79H8QB3TV99AQ5PJVSHG	1	USER_LOGGED_IN	2025-12-20 08:15:07.816	2025-12-20 08:15:07.816	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXD79H84C6FJ2QMX9QDC6TC	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0wap1000rut2ut8mdyltc", "payloadVersion": 1}
01KCXE2TVRSA6HYT702W2GEQCN	1	USER_LOGGED_OUT	2025-12-20 08:30:10.295	2025-12-20 08:30:10.296	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXE2TVQ6J5MBDH7WSE29744	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0wap1000rut2ut8mdyltc", "payloadVersion": 1}
01KCXE2XPKEF566813T3BMWTZB	1	USER_LOGGED_IN	2025-12-20 08:30:13.202	2025-12-20 08:30:13.203	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXE2XPJW8NSNVX6ZGSRGKFE	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje1fpal0002tvgv5d0v0jq4", "payloadVersion": 1}
01KCXE35M7EXN7RCAQQR586ACG	1	USER_LOGGED_OUT	2025-12-20 08:30:21.319	2025-12-20 08:30:21.319	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXE35M7WGCSDMDH2XQ8C8DC	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje1fpal0002tvgv5d0v0jq4", "payloadVersion": 1}
01KCXEPCN4VTQVJG0TVM4T26X3	1	USER_LOGGED_IN	2025-12-20 08:40:51.108	2025-12-20 08:40:51.108	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXEPCN43ZCZ21BC34CKSPMJ	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje1tdi80005tvgvyduak82j", "payloadVersion": 1}
01KCY9DDMBKCZXN0F4SC3FBC79	1	USER_LOGGED_OUT	2025-12-20 16:27:48.746	2025-12-20 16:27:48.748	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCY9DDMBV0Y4MTNJBDPYH1RN	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje1tdi80005tvgvyduak82j", "payloadVersion": 1}
01KCY9DJ1VGA1HZ58DW0TY13SE	1	USER_LOGGED_IN	2025-12-20 16:27:53.275	2025-12-20 16:27:53.276	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCY9DJ1VRWD7EX2VS2SVYY4H	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjeihzjs0002g1h76qvc4v6y", "payloadVersion": 1}
01KCY9DKWARW1Z280E86SJXNF5	1	USER_LOGGED_OUT	2025-12-20 16:27:55.146	2025-12-20 16:27:55.146	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCY9DKWAE9FPC71E8YAGPV3E	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjeihzjs0002g1h76qvc4v6y", "payloadVersion": 1}
01KCY9T8JJ35WWG6RKF4DWMS82	1	USER_LOGGED_IN	2025-12-20 16:34:49.553	2025-12-20 16:34:49.554	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCY9T8JH3Y97ESB2T01WD734	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjeiqwr10002o1hxa6cnazc3", "payloadVersion": 1}
01KCY9TAF29WHFD2XGZM0JTKJX	1	USER_LOGGED_OUT	2025-12-20 16:34:51.489	2025-12-20 16:34:51.49	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCY9TAF2V23YQ18FYWJRHGJW	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjeiqwr10002o1hxa6cnazc3", "payloadVersion": 1}
01KCYAQ2X8GHEGQT1VYWCVJ9FP	1	USER_LOGGED_IN	2025-12-20 16:50:34.024	2025-12-20 16:50:34.024	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCYAQ2X8MRHER2B9ED3DJY9D	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjejb5ic0005o1hxkowop4vc", "payloadVersion": 1}
01KCYAQ4DFPRJA58EPVJFJGCE6	1	USER_LOGGED_OUT	2025-12-20 16:50:35.567	2025-12-20 16:50:35.568	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCYAQ4DFSBKRXYZ2785FX3FT	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjejb5ic0005o1hxkowop4vc", "payloadVersion": 1}
01KCYAQEMZT4ZB38G954R22NPA	1	USER_SIGNED_UP	2025-12-20 16:50:46.046	2025-12-20 16:50:46.047	cmjejbes70007o1hxngxzzzw7	cmjejbesa0009o1hxza9o6wpx	\N	USER	cmjejbesa0009o1hxza9o6wpx	CLARIFY	NEW	api	01KCYAQEMYRJEDQ11DAWJ2WR1G	{"role": "Owner", "email": "info3@staadit.com", "orgId": "cmjejbes70007o1hxngxzzzw7", "userId": "cmjejbesa0009o1hxza9o6wpx", "sessionId": "cmjejbesc000bo1hx5jfbo3ea", "payloadVersion": 1}
01KCYAQHA312TAHSQM88YAMH0D	1	USER_LOGGED_OUT	2025-12-20 16:50:48.771	2025-12-20 16:50:48.771	cmjejbes70007o1hxngxzzzw7	cmjejbesa0009o1hxza9o6wpx	\N	USER	cmjejbesa0009o1hxza9o6wpx	CLARIFY	NEW	api	01KCYAQHA3H50CA88SMPREQ76T	{"orgId": "cmjejbes70007o1hxngxzzzw7", "userId": "cmjejbesa0009o1hxza9o6wpx", "sessionId": "cmjejbesc000bo1hx5jfbo3ea", "payloadVersion": 1}
01KE6Y6V38MHS03WF25107ACY4	1	USER_SIGNED_UP	2026-01-05 11:20:50.536	2026-01-05 11:20:50.537	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE6Y6V38P4W2R2DMYXNTSFB7	{"role": "Owner", "email": "test01@enabion.com", "orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk12kr50000ho1hxukaj9r7i", "payloadVersion": 1}
01KE6YMXWAG2TH47G1HHDCCYJK	1	USER_LOGGED_OUT	2026-01-05 11:28:32.138	2026-01-05 11:28:32.138	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE6YMXWA41Q84PDQRA9RPRF0	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk12kr50000ho1hxukaj9r7i", "payloadVersion": 1}
01KE6YN0X38351YC5Q7R0V9EWW	1	USER_LOGGED_IN	2026-01-05 11:28:35.234	2026-01-05 11:28:35.235	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE6YN0X206ENMBYN3QV0MXAK	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk12upp9000ko1hxepfys1ze", "payloadVersion": 1}
01KE6YN31PPABSE921QCA2HXGB	1	USER_LOGGED_OUT	2026-01-05 11:28:37.43	2026-01-05 11:28:37.43	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE6YN31P8FV3YV9YRHE15GK4	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk12upp9000ko1hxepfys1ze", "payloadVersion": 1}
01KE709CK9G9XJ89G5QXMM204W	1	USER_PASSWORD_RESET_REQUESTED	2026-01-05 11:57:11.145	2026-01-05 11:57:11.145	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE709CJWH7RK63ZMC4NG09BR	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk13vhpg000213n32bejppkt", "payloadVersion": 1}
01KE709CQFQSTPV470QKB4S7YE	1	EMAIL_FAILED	2026-01-05 11:57:11.279	2026-01-05 11:57:11.279	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE709CJWH7RK63ZMC4NG09BR	{"errorCode": "esocket", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk13vhpg000213n32bejppkt", "payloadVersion": 1}
01KE70MSSBEJBK9D2X072V299Y	1	USER_PASSWORD_RESET_REQUESTED	2026-01-05 12:03:25.099	2026-01-05 12:03:25.1	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE70MSS30P8MS0W2970QJAWA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk143i94000513n3w2do6ecr", "payloadVersion": 1}
01KE70MSVB1C07KEEADGPXTN11	1	EMAIL_FAILED	2026-01-05 12:03:25.163	2026-01-05 12:03:25.163	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE70MSS30P8MS0W2970QJAWA	{"errorCode": "esocket", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk143i94000513n3w2do6ecr", "payloadVersion": 1}
01KE72Q0VGB63ZQKWQDEZBZ5EB	1	USER_PASSWORD_RESET_REQUESTED	2026-01-05 12:39:35.024	2026-01-05 12:39:35.024	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE72Q0V3HEQF1G21H3MN096Y	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk15e0kq0002ya7ahsshryg5", "payloadVersion": 1}
01KE72Q13H454QYX5K91536WNY	1	EMAIL_SENT	2026-01-05 12:39:35.281	2026-01-05 12:39:35.282	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE72Q0V3HEQF1G21H3MN096Y	{"messageId": "<28ffe788-086b-0096-d7c8-f2c0e0037d61@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk15e0kq0002ya7ahsshryg5", "payloadVersion": 1}
01KE7384H00EY5K3VAF3MZ4WAG	1	USER_PASSWORD_RESET_REQUESTED	2026-01-05 12:48:55.84	2026-01-05 12:48:55.84	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE7384GPAYQ6DB3D984SH1D3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk15q1b00005ya7af25k5v22", "payloadVersion": 1}
01KE7384PBPD4Y1R2ZDSWR4DTP	1	EMAIL_SENT	2026-01-05 12:48:56.011	2026-01-05 12:48:56.012	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE7384GPAYQ6DB3D984SH1D3	{"messageId": "<c92bc974-b238-eb73-eca1-74f7fea6f22c@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk15q1b00005ya7af25k5v22", "payloadVersion": 1}
01KE788MMBS4NGA5CWR4QAW48C	1	USER_PASSWORD_RESET_REQUESTED	2026-01-05 14:16:35.211	2026-01-05 14:16:35.211	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE788MM23TZDT8MMWF8Y80ZN	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk18urgn0008ya7aephyu2jp", "payloadVersion": 1}
01KE788MSCXYJ174THJG2R1NQ7	1	EMAIL_SENT	2026-01-05 14:16:35.372	2026-01-05 14:16:35.372	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE788MM23TZDT8MMWF8Y80ZN	{"messageId": "<dd87af4b-3979-06d4-930f-33b1fcc7ad9e@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk18urgn0008ya7aephyu2jp", "payloadVersion": 1}
01KEBS11GSTBJFRCR0PSTGMAEN	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 08:26:29.785	2026-01-07 08:26:29.785	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBS11GD4CKHNYVDA0K56PN6	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3r88wk000bya7av3fodj38", "payloadVersion": 1}
01KEBS11QHNMP1927GNRKK1DG2	1	EMAIL_SENT	2026-01-07 08:26:30.001	2026-01-07 08:26:30.001	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBS11GD4CKHNYVDA0K56PN6	{"messageId": "<6f33c0d5-3c8e-3294-0726-97e471e734c0@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk3r88wk000bya7av3fodj38", "payloadVersion": 1}
01KEBS3PXA5SNP55SXYYTVBXE6	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 08:27:57.226	2026-01-07 08:27:57.226	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBS3PX4K070TNSFXQC5J42W	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3ra4dj000eya7aou676wpg", "payloadVersion": 1}
01KEBS3Q0RDGCY4PNXKKGK67B4	1	EMAIL_SENT	2026-01-07 08:27:57.336	2026-01-07 08:27:57.336	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBS3PX4K070TNSFXQC5J42W	{"messageId": "<773580db-69eb-16ec-0d9a-c1405ebef553@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk3ra4dj000eya7aou676wpg", "payloadVersion": 1}
01KEBSPQXSQ4TA6KH1PF32KK36	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 08:38:20.857	2026-01-07 08:38:20.857	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBSPQXFWMQXJWAT0VJ1K73F	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3rnhkl000hya7aaxdi1t10", "payloadVersion": 1}
01KEBSPR33PHYAJPP3PKPR4BTC	1	EMAIL_SENT	2026-01-07 08:38:21.027	2026-01-07 08:38:21.027	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBSPQXFWMQXJWAT0VJ1K73F	{"messageId": "<d74b8cb9-68af-40a5-9a82-f688fef2f86b@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk3rnhkl000hya7aaxdi1t10", "payloadVersion": 1}
01KEBSY5WZEGWQN3QMARXWX0N4	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 08:42:24.543	2026-01-07 08:42:24.544	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBSY5WSRVSV7VNVSFSH0SH8	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3rsplo000kya7a6zutneko", "payloadVersion": 1}
01KEBSY61FJC0829SGKER6EQ5R	1	EMAIL_SENT	2026-01-07 08:42:24.687	2026-01-07 08:42:24.687	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBSY5WSRVSV7VNVSFSH0SH8	{"messageId": "<ebf25292-05ea-1278-a391-99ff2b071410@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk3rsplo000kya7a6zutneko", "payloadVersion": 1}
01KEC6SKCEHT44RQ35C6961KGY	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 12:27:05.998	2026-01-07 12:27:05.999	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC6SKC386MDCCGTGMTCTSZE	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3ztnyi000215kosdnx7uui", "payloadVersion": 1}
01KEC6SKKF65WD2PPHR00FQJS4	1	EMAIL_SENT	2026-01-07 12:27:06.223	2026-01-07 12:27:06.223	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC6SKC386MDCCGTGMTCTSZE	{"messageId": "<23051ede-d946-b0b4-c5f0-89f1c5f890e0@staadit.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk3ztnyi000215kosdnx7uui", "payloadVersion": 1}
01KEC6YH07XY4W30VEJA1WXCN2	1	USER_PASSWORD_RESET_COMPLETED	2026-01-07 12:29:47.398	2026-01-07 12:29:47.399	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC6YH06W8QAARHV2VCH8NH5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3ztnyi000215kosdnx7uui", "payloadVersion": 1}
01KEC6YZQ3XMV4ASKNF6289K1Z	1	USER_LOGGED_IN	2026-01-07 12:30:02.467	2026-01-07 12:30:02.467	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC6YZQ336D199QSNPGC7EY5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk3zxg3z000615kox8o064g4", "payloadVersion": 1}
01KEC733E83J1DKPRG3NXAAB65	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 12:32:17.352	2026-01-07 12:32:17.352	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC733DVF8G24YXW95GTJWP6	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk400c770002kr4xvoalh8i3", "payloadVersion": 1}
01KEC733NZ4A1W53N31CK19BS7	1	EMAIL_SENT	2026-01-07 12:32:17.599	2026-01-07 12:32:17.6	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC733DVF8G24YXW95GTJWP6	{"messageId": "<b719c7ff-298c-4f87-0402-debacfaf7fb8@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk400c770002kr4xvoalh8i3", "payloadVersion": 1}
01KEC9QPE28SDP7JG7PH9D9T2P	1	USER_LOGGED_OUT	2026-01-07 13:18:29.313	2026-01-07 13:18:29.314	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC9QPE1WMFXKH1R9ZCGVTEC	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk3zxg3z000615kox8o064g4", "payloadVersion": 1}
01KEC9R2C344H7R93217X1MXWW	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 13:18:41.539	2026-01-07 13:18:41.539	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC9R2BQZZ0SV38EG3EPVKBH	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk41o0hr0002i0v0dn8en4kf", "payloadVersion": 1}
01KEC9R2KR5GMAJKWH0E9TSQVH	1	EMAIL_SENT	2026-01-07 13:18:41.784	2026-01-07 13:18:41.784	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC9R2BQZZ0SV38EG3EPVKBH	{"messageId": "<4b2e3e31-ddb1-7bc1-b05a-47de94a9eda0@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk41o0hr0002i0v0dn8en4kf", "payloadVersion": 1}
01KEC9S70YKXR7J81XPMDWDJ49	1	USER_PASSWORD_RESET_COMPLETED	2026-01-07 13:19:19.07	2026-01-07 13:19:19.07	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC9S70YNQZ14030CYRQW0W9	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk41o0hr0002i0v0dn8en4kf", "payloadVersion": 1}
01KEC9SG5V4W2DK9WSWSPH97QY	1	USER_LOGGED_IN	2026-01-07 13:19:28.442	2026-01-07 13:19:28.443	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC9SG5TYY8GAX7CTR4MT9TT	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk41p0on0006i0v0f9yumxui", "payloadVersion": 1}
01KECB8KPGB7G79HDHGWZX25Y3	1	USER_LOGGED_OUT	2026-01-07 13:45:12.143	2026-01-07 13:45:12.144	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECB8KPFBNTQFG693T1T0C5S	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk41p0on0006i0v0f9yumxui", "payloadVersion": 1}
01KECH3WD9F7CKTVN4DCP19Z5X	1	USER_LOGGED_IN	2026-01-07 15:27:28.681	2026-01-07 15:27:28.681	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECH3WD994X6B2T3ZZVTGF11	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk469msl0002t8cit8rq2pux", "payloadVersion": 1}
01KECHA5CHE7Q2M51X4WZJB6G9	1	USER_LOGGED_OUT	2026-01-07 15:30:54.481	2026-01-07 15:30:54.481	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECHA5CHH1YQQWJBQ4RQ121Q	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk469msl0002t8cit8rq2pux", "payloadVersion": 1}
01KECHAE2DCW902X3RJ0RZBH7Y	1	USER_LOGGED_IN	2026-01-07 15:31:03.373	2026-01-07 15:31:03.373	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECHAE2DG1NEGJA8YDFQF89S	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk46e8g90005t8ci4a1tj9xw", "payloadVersion": 1}
01KECHB922AFC2Y14R7JV19QAH	1	USER_LOGGED_IN	2026-01-07 15:31:31.01	2026-01-07 15:31:31.01	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECHB922D31M4PVTNYJP07HF	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk46etry0008t8cia912fv9m", "payloadVersion": 1}
01KECK9TC45P3RDK02414ZEV9Y	1	ORG_PROFILE_UPDATED	2026-01-07 16:05:40.355	2026-01-07 16:05:40.356	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ORG	cmk12kr4u000do1hxva29zgyd	CLARIFY	NEW	ui	01KECK9TC3G4E5PG91S03WMQV2	{"orgId": "cmk12kr4u000do1hxva29zgyd", "changedFields": ["name", "slug"], "payloadVersion": 1}
01KECKZZ785JB9FRQKTBWXXF90	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 16:17:46.216	2026-01-07 16:17:46.216	cmk12kr4u000do1hxva29zgyd	cmk482b4p0001bmbck6q90zvv	\N	USER	cmk482b4p0001bmbck6q90zvv	CLARIFY	NEW	api	01KECKZZ6Y7HCT8YV1XBFGN5GA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk482b4p0001bmbck6q90zvv", "resetTokenId": "cmk482b510004bmbc6a4l42az", "payloadVersion": 1}
01KECKZZF4TMSHC1PFJ1A393B2	1	EMAIL_SENT	2026-01-07 16:17:46.468	2026-01-07 16:17:46.469	cmk12kr4u000do1hxva29zgyd	cmk482b4p0001bmbck6q90zvv	\N	USER	cmk482b4p0001bmbck6q90zvv	CLARIFY	NEW	api	01KECKZZ6Y7HCT8YV1XBFGN5GA	{"messageId": "<4fafc15d-ad8a-a318-aeb7-4d060ce84ce0@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk482b510004bmbc6a4l42az", "payloadVersion": 1}
01KECM06J9JDXJEP7EF7NYVP0D	1	ORG_MEMBER_ROLE_CHANGED	2026-01-07 16:17:53.736	2026-01-07 16:17:53.737	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	USER	cmk482b4p0001bmbck6q90zvv	CLARIFY	NEW	ui	01KECM06J8512RDV2K768MZVR9	{"toRole": "BD_AM", "fromRole": "Viewer", "targetUserId": "cmk482b4p0001bmbck6q90zvv", "payloadVersion": 1}
01KECM08KJQ3WHJVD05WV9FDSN	1	ORG_MEMBER_ROLE_CHANGED	2026-01-07 16:17:55.826	2026-01-07 16:17:55.826	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	USER	cmk482b4p0001bmbck6q90zvv	CLARIFY	NEW	ui	01KECM08KJGR3Y6C03D69PGNX2	{"toRole": "Viewer", "fromRole": "BD_AM", "targetUserId": "cmk482b4p0001bmbck6q90zvv", "payloadVersion": 1}
01KECMKJ4651AACR38JKGY1JXP	1	USER_LOGGED_OUT	2026-01-07 16:28:28.165	2026-01-07 16:28:28.166	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECMKJ457QRPK7X8Z0C385JC	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk46e8g90005t8ci4a1tj9xw", "payloadVersion": 1}
01KECMMHRVJY6PSTCEGC7PNA3X	1	USER_SIGNED_UP	2026-01-07 16:29:00.571	2026-01-07 16:29:00.572	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KECMMHRVDM6H8ZD704VA16ND	{"role": "Owner", "email": "admin@enabion.com", "orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk48grh3000abmbc9dwdqdp1", "payloadVersion": 1}
01KECMN6FVNPMAJX6XNWGQSD6T	1	USER_LOGGED_OUT	2026-01-07 16:29:21.787	2026-01-07 16:29:21.787	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KECMN6FVA2Y68SE08Y5XP0BV	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk48grh3000abmbc9dwdqdp1", "payloadVersion": 1}
01KECPY3Z7QYDXX54Z1VMBPEF5	1	USER_LOGGED_IN	2026-01-07 17:09:11.27	2026-01-07 17:09:11.271	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KECPY3Z7XA6XNNJD57Q3CSD3	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk49wfky000210ufpmjytmgm", "payloadVersion": 1}
01KECPYAGMFP4WKVZCBA3Y7ZF1	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:09:17.971	2026-01-07 17:09:17.972	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECPYAGK91CYAB2PF10MJ86Y	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECPYY59RKJQ7V4RTK49FK3R	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:09:38.089	2026-01-07 17:09:38.089	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECPYY59HCFYH439HR40QNC0	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECPZXQSKD91JZRD0EP0YEM4	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:10:10.425	2026-01-07 17:10:10.425	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECPZXQSQB47JPZA143YYPR5	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ05CTG91Q4F2Q9WH96KCH	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:10:18.265	2026-01-07 17:10:18.266	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ05CSN68B8J4EQEY8B90D	{"query": {"limit": 50, "orgId": "admin"}, "action": "EVENTS_QUERY", "targetType": "EVENTS", "resultCount": 0, "payloadVersion": 1}
01KECQ0JD2MFDWR3Y2YQHY33G2	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:10:31.586	2026-01-07 17:10:31.586	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ0JD2WFR4Z1M2BE0SMXD0	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ17XXMQGM5V98FQKPSK7J	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:10:53.628	2026-01-07 17:10:53.629	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ17XW140YZYG5CTZCNBDW	{"query": {"email": "test01"}, "action": "USER_SEARCH", "targetType": "USER", "resultCount": 0, "payloadVersion": 1}
01KECQ19NF3QVVDPAV4KRG9AZ3	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:10:55.407	2026-01-07 17:10:55.407	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ19NF8MPF9YPX2ZARNM08	{"query": {"email": "test01"}, "action": "USER_SEARCH", "targetType": "USER", "resultCount": 0, "payloadVersion": 1}
01KECQ3RVD4GKS68D5JPHTMEGG	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:16.493	2026-01-07 17:12:16.493	cmjejbes70007o1hxngxzzzw7	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3RVD4SQJ0MYZMKC1XSRN	{"action": "TENANT_VIEW", "targetId": "cmjejbes70007o1hxngxzzzw7", "targetType": "TENANT", "targetOrgId": "cmjejbes70007o1hxngxzzzw7", "payloadVersion": 1}
01KECQ1FZAWTSV1ARXS4JGMKDQ	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:01.866	2026-01-07 17:11:01.867	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ1FZA96JGEZZD6BJYT1HN	{"query": {"email": "test01@enabion.com"}, "action": "USER_SEARCH", "targetId": "cmk12kr4x000fo1hxdcjik7rt", "targetType": "USER", "resultCount": 1, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "targetUserId": "cmk12kr4x000fo1hxdcjik7rt", "payloadVersion": 1}
01KECQ1QNXN6ZTN70ACY8C6B6B	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:09.757	2026-01-07 17:11:09.757	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ1QNXQ78DA83HVYVVZRT9	{"query": {"email": "test02@enabion.com"}, "action": "USER_SEARCH", "targetId": "cmk482b4p0001bmbck6q90zvv", "targetType": "USER", "resultCount": 1, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "targetUserId": "cmk482b4p0001bmbck6q90zvv", "payloadVersion": 1}
01KECQ204CDKR0BME175CD8ZY8	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:18.412	2026-01-07 17:11:18.412	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ204CV2PHSEVRSZ8WX5DE	{"action": "USER_VIEW", "targetId": "cmk482b4p0001bmbck6q90zvv", "targetType": "USER", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "targetUserId": "cmk482b4p0001bmbck6q90zvv", "payloadVersion": 1}
01KECQ2DKEX9HZRYKAXN65D41T	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:32.205	2026-01-07 17:11:32.206	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2DKDTXQEACH6XASKBCGG	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ2F93EHHH80WJK3PT6245	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:33.923	2026-01-07 17:11:33.923	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2F93MD73P17SH5CFNRQQ	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ2F9QYN3Y9XHP5MXVXC5M	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:33.943	2026-01-07 17:11:33.943	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2F9QA7AH2J1J11X1MDVG	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ2KG9F3YF4PGPXPNTAEM7	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:38.249	2026-01-07 17:11:38.249	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2KG9YZZSDQXT5702976Q	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ2MJZD30W8YBB6YVZ54TD	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:39.358	2026-01-07 17:11:39.359	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2MJYZMYMM236ZAX95M44	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KECQ2MK0TH8SVYQDZJ2DEV7M	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:39.36	2026-01-07 17:11:39.36	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2MK031G4CMEEE4XS3XDJ	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KECQ2PD1MXC45XN16BCJA44N	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:41.217	2026-01-07 17:11:41.217	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2PD16KNXH4YK4P7DRBP5	{"action": "USER_VIEW", "targetId": "cmk48grgz0008bmbcp8s2vrap", "targetType": "USER", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "targetUserId": "cmk48grgz0008bmbcp8s2vrap", "payloadVersion": 1}
01KECQ2S2T9VQCDHW4PXW045ZH	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:43.962	2026-01-07 17:11:43.962	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2S2TSTZ79GCC3BSZA7NE	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ2TC6TZYKV2V8GW3CK53Q	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:45.286	2026-01-07 17:11:45.287	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2TC6TBR4BSJWP7KK3ME6	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KECQ2TCARBTH0KR9QERGG7QK	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:45.289	2026-01-07 17:11:45.29	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2TC9NXJYS8Y29E2CXPZ7	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KECQ3DESBBV5T36SYCEK4QZZ	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:04.825	2026-01-07 17:12:04.826	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3DESVY6A166H34CKNK6F	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ3EG4H1RMBXH447PMECHP	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:05.892	2026-01-07 17:12:05.892	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3EG4K5XN8SAPPBF0JTR2	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ3EG5JQ5YNCSEB9NM0X04	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:05.893	2026-01-07 17:12:05.893	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3EG50TZ22R1DKVMZS9QC	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ3QKZATHTPS22ESAZAXV5	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:15.231	2026-01-07 17:12:15.232	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3QKZM555JDX0F6NVY6Z6	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEER7JJADXH67EH5M6W6MP2R	1	USER_LOGGED_OUT	2026-01-08 12:10:18.57	2026-01-08 12:10:18.57	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEER7JJAQBTTXXX3GD80EKGN	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5em84v0002h66lyo9xac54", "payloadVersion": 1}
01KECQ3RVHB0ABTRM36SKBER2G	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:16.497	2026-01-07 17:12:16.497	cmjejbes70007o1hxngxzzzw7	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3RVHWMAMQTVETR6B96EE	{"action": "TENANT_USERS_LIST", "targetId": "cmjejbes70007o1hxngxzzzw7", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmjejbes70007o1hxngxzzzw7", "payloadVersion": 1}
01KECQ40XF68JXW8ZEW4MZZ1M1	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:24.751	2026-01-07 17:12:24.751	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ40XFB7N536A0DE9Q93SP	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ43TW1N6QD1BY1S4YD974	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:27.74	2026-01-07 17:12:27.74	cmje0pkpu000dut2u1z41ciku	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ43TWDXC44TE6KY0YV607	{"action": "TENANT_USERS_LIST", "targetId": "cmje0pkpu000dut2u1z41ciku", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmje0pkpu000dut2u1z41ciku", "payloadVersion": 1}
01KECQ4DPJ5GJA89A17TEWJNC5	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:37.842	2026-01-07 17:12:37.842	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ4DPJF90ZAE756D6YTM5A	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ43TX70M6HAM2XRQ2BMDK	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:27.741	2026-01-07 17:12:27.741	cmje0pkpu000dut2u1z41ciku	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ43TXE46676595Z2C92MK	{"action": "TENANT_VIEW", "targetId": "cmje0pkpu000dut2u1z41ciku", "targetType": "TENANT", "targetOrgId": "cmje0pkpu000dut2u1z41ciku", "payloadVersion": 1}
01KECQ47XZBXNRQTZFXM0MS6Y3	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:31.935	2026-01-07 17:12:31.935	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ47XZYVBDBZBRN0MM6G55	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ4933BESPM9FM14284GKB	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:33.122	2026-01-07 17:12:33.123	cmjdakp0f0001ut2uv0n881s3	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ4932R69YV796E9D27QJN	{"action": "TENANT_VIEW", "targetId": "cmjdakp0f0001ut2uv0n881s3", "targetType": "TENANT", "targetOrgId": "cmjdakp0f0001ut2uv0n881s3", "payloadVersion": 1}
01KECQ493K7B4J9QQYKVM83SFR	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:33.138	2026-01-07 17:12:33.139	cmjdakp0f0001ut2uv0n881s3	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ493JW1Y5T816V6GYFHFY	{"action": "TENANT_USERS_LIST", "targetId": "cmjdakp0f0001ut2uv0n881s3", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmjdakp0f0001ut2uv0n881s3", "payloadVersion": 1}
01KECQ4CN6YN4ZKXCAEVCQXATT	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:36.773	2026-01-07 17:12:36.774	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ4CN5D3NWWBXK8V4G3HX0	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ4DPHQXJ2G1WNB6VDM19G	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:37.841	2026-01-07 17:12:37.841	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ4DPH7XA5C68EERQ09FSE	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ9D28VDH1GNKAXWZN2CN2	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:15:21.032	2026-01-07 17:15:21.032	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ9D28RXWXAE4NJF0MB6A4	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ9E2CS7F5XPA7JRN8DCJT	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:15:22.059	2026-01-07 17:15:22.06	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ9E2BQE9801F15R6NJ8TN	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ9E31232REE8N7V83NRDT	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:15:22.08	2026-01-07 17:15:22.081	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ9E30Z9FY2B7SAX9NMTN5	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQBXADQGWEJE8QPF46S7BJ	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:16:43.212	2026-01-07 17:16:43.213	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQBXAC3YX48YY0KFAWXCK6	{"action": "USER_VIEW", "targetId": "cmk482b4p0001bmbck6q90zvv", "targetType": "USER", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "targetUserId": "cmk482b4p0001bmbck6q90zvv", "payloadVersion": 1}
01KEEMPZ2Q5W6Z79E60CF76K19	1	USER_LOGGED_IN	2026-01-08 11:08:48.599	2026-01-08 11:08:48.599	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEMPZ2QGV6FTV7VJYPAX722	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5cgu36000510ufair0t79h", "payloadVersion": 1}
01KEEMQ5REQYRWB6HRDA255456	1	PLATFORM_ADMIN_AUDIT	2026-01-08 11:08:55.438	2026-01-08 11:08:55.438	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEEMQ5RE68GN2283K2B0CT3C	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEEMQR9K2RX333QMSFD95YPV	1	PLATFORM_ADMIN_AUDIT	2026-01-08 11:09:14.419	2026-01-08 11:09:14.419	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEEMQR9KS59B9QTFGJQQ1X42	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEEQ9J4WNWAV865HAET3YQHH	1	USER_LOGGED_OUT	2026-01-08 11:53:55.1	2026-01-08 11:53:55.1	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEQ9J4WEYBRX0WW61M9N8AQ	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5cgu36000510ufair0t79h", "payloadVersion": 1}
01KEEQ9MCT8M0DZWWE6FS8ZKFB	1	USER_LOGGED_IN	2026-01-08 11:53:57.402	2026-01-08 11:53:57.402	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEQ9MCTZBHRYA4A2Y9TYKNR	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5e2w7q000810ufvs1whblh", "payloadVersion": 1}
01KEEQ9X3766SJR69ZTE98KVYK	1	PLATFORM_ADMIN_AUDIT	2026-01-08 11:54:06.311	2026-01-08 11:54:06.311	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEEQ9X376WER61CSG6WWQN65	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEER3ST0E6Q6067K4YTVC8PR	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:08:14.911	2026-01-08 12:08:14.913	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEER3ST07RQA9T7CKCV1J2B0	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEER4ZJP8S9DBJZVZ3FB2RGY	1	USER_LOGGED_OUT	2026-01-08 12:08:53.589	2026-01-08 12:08:53.59	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEER4ZJNJZA24YHDP9PQGDWT	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5e2w7q000810ufvs1whblh", "payloadVersion": 1}
01KEER555KSN4KMYYBPKCGDWA4	1	USER_LOGGED_IN	2026-01-08 12:08:59.315	2026-01-08 12:08:59.315	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEER555KGQP9H0N4KNBXTG07	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5em84v0002h66lyo9xac54", "payloadVersion": 1}
01KEER7N2ZZMDPZFHM86A00MFK	1	USER_LOGGED_IN	2026-01-08 12:10:21.151	2026-01-08 12:10:21.151	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEER7N2ZV35QW75W8GS95PV3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5enza40005h66lh94scp4y", "payloadVersion": 1}
01KEER96PS2NC3ZV9P9NE92XS3	1	USER_LOGGED_OUT	2026-01-08 12:11:11.961	2026-01-08 12:11:11.961	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEER96PST5CBC8K0XGBGY9VE	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5enza40005h66lh94scp4y", "payloadVersion": 1}
01KEERA3M6MSTQEGKQF4EFZ10X	1	USER_LOGGED_IN	2026-01-08 12:11:41.574	2026-01-08 12:11:41.575	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEERA3M6E4ESCQDH3BG2VC7P	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5eppc20008h66lovk0zw5j", "payloadVersion": 1}
01KEERQX2RW8HMVWNVQHGNWX1M	1	USER_LOGGED_OUT	2026-01-08 12:19:13.624	2026-01-08 12:19:13.624	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEERQX2R0SVW7DSEHM9JNVPA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5eppc20008h66lovk0zw5j", "payloadVersion": 1}
01KEERQZ1DB3W4HXV4B4HJ2SVG	1	USER_LOGGED_IN	2026-01-08 12:19:15.629	2026-01-08 12:19:15.629	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEERQZ1DBTYTDX3D4TMGWGYK	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5ezfop000bh66lppwyol68", "payloadVersion": 1}
01KEESNHKGWG6VN3K5K30ET34C	1	USER_LOGGED_OUT	2026-01-08 12:35:24.911	2026-01-08 12:35:24.912	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEESNHKFBB8X4GWGTXGBZBVW	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5ezfop000bh66lppwyol68", "payloadVersion": 1}
01KEESNKRZDJ6ETDSANENJ6VZD	1	USER_LOGGED_IN	2026-01-08 12:35:27.135	2026-01-08 12:35:27.135	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEESNKRZMTSAVEY4102ZGGY3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5fk9aw00029x9sqe9w53g9", "payloadVersion": 1}
01KEESP7FN65NN3KNXQZHJFEPM	1	USER_LOGGED_OUT	2026-01-08 12:35:47.317	2026-01-08 12:35:47.317	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEESP7FN6W86W1F593KTVKNY	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5fk9aw00029x9sqe9w53g9", "payloadVersion": 1}
01KEESPB6DA7BZN95M9K4MQHK3	1	USER_LOGGED_IN	2026-01-08 12:35:51.117	2026-01-08 12:35:51.117	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEESPB6D4AA60C163ZYPDT9Y	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5fkrt300059x9s3dod0n47", "payloadVersion": 1}
01KEETFXDVD4B30EZT8TG4ZYKG	1	USER_LOGGED_OUT	2026-01-08 12:49:48.986	2026-01-08 12:49:48.987	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEETFXDTF80P7S6N6NVCVKNV	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5fkrt300059x9s3dod0n47", "payloadVersion": 1}
01KEETFZSWQT7F0NJFRWKP314M	1	USER_LOGGED_IN	2026-01-08 12:49:51.42	2026-01-08 12:49:51.421	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEETFZSWC39PYDV5G24QNX8M	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5g2s6u000210ytbbztu53x", "payloadVersion": 1}
01KEETG2TX9M523K8MBFAZM0AW	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:49:54.525	2026-01-08 12:49:54.526	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEETG2TXQDWAWW5PX7WZ7XNM	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEETGCBAPC24R2Y91F9NA1GN	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:50:04.266	2026-01-08 12:50:04.266	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEETGCBAJYRGF72HFHSRJ3FK	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEETGQT8CGTTZXR0GQBGC45J	1	USER_LOGGED_OUT	2026-01-08 12:50:16.008	2026-01-08 12:50:16.009	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEETGQT8MF70QQDPF2WGK0JS	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5g2s6u000210ytbbztu53x", "payloadVersion": 1}
01KEETGWGJQDN62J9J03G2F5CP	1	USER_LOGGED_IN	2026-01-08 12:50:20.818	2026-01-08 12:50:20.818	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEETGWGJHGJVYAWS9WAV949T	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5g3evh000510ytxdm5ju30", "payloadVersion": 1}
01KEETH12RZ289MYJZ3GHXQ2FV	1	USER_LOGGED_OUT	2026-01-08 12:50:25.496	2026-01-08 12:50:25.497	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEETH12R9PDPCGFVV1FP9CXQ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5g3evh000510ytxdm5ju30", "payloadVersion": 1}
01KEETH4NP1TJESVAEW2794JY4	1	USER_LOGGED_IN	2026-01-08 12:50:29.173	2026-01-08 12:50:29.174	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEETH4NN49E774VF7B3K6ZKE	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5g3lbl000810yt15ql6i2o", "payloadVersion": 1}
01KEETH7P8WDG1HAQ2Y6BY1G4R	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:50:32.264	2026-01-08 12:50:32.264	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEETH7P8X2DMFSZF00A9QGQN	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEETHGE0XKTN6AE243CG0Q4K	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:50:41.216	2026-01-08 12:50:41.216	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEETHGE0FMABQEN7PM8CYY4C	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEETHGEZ4Z3HJ0RH3FD06M15	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:50:41.247	2026-01-08 12:50:41.247	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEETHGEZ2X1VY6CJ3M4SJ3YJ	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEETHVXZY0YTJABGVK5MEMZ0	1	USER_LOGGED_OUT	2026-01-08 12:50:52.991	2026-01-08 12:50:52.991	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEETHVXZAC1XMSR1J7421W2H	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5g3lbl000810yt15ql6i2o", "payloadVersion": 1}
01KEEXBMQ5MCQMC9Y9NAKN4SJB	1	USER_LOGGED_IN	2026-01-08 13:39:54.724	2026-01-08 13:39:54.725	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEXBMQ43RGW8P8SKNQGWWD6	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5hv5jv000b10ytbdyu1ki8", "payloadVersion": 1}
01KEEXCXSBN783KVY5E2YVMPBD	1	USER_LOGGED_OUT	2026-01-08 13:40:36.778	2026-01-08 13:40:36.779	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEXCXSA0W9924XJN2WE1WMP	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5hv5jv000b10ytbdyu1ki8", "payloadVersion": 1}
01KEEXCZQX459ES9WW1GRATGHJ	1	USER_LOGGED_IN	2026-01-08 13:40:38.781	2026-01-08 13:40:38.781	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEXCZQXPM6EA4E2Q1VZQ8DK	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5hw3jt000e10yt4vt51e33", "payloadVersion": 1}
01KEEXE94B37K1M5G0NG34VXXB	1	USER_LOGGED_OUT	2026-01-08 13:41:21.162	2026-01-08 13:41:21.163	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEXE94AXHN6G12J7DB0C32R	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5hw3jt000e10yt4vt51e33", "payloadVersion": 1}
01KEEXEEYT2HKSDHB4G0AWQNE4	1	USER_LOGGED_IN	2026-01-08 13:41:27.13	2026-01-08 13:41:27.131	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEEXEEYT59VQFNBGMGM77MJM	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5hx4ut000h10ytxlbssx14", "payloadVersion": 1}
01KEEZPNKSHCT9NSTGE2Y10465	1	USER_LOGGED_OUT	2026-01-08 14:20:53.24	2026-01-08 14:20:53.241	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEEZPNKREQW16G6DF0AXTSMD	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5hx4ut000h10ytxlbssx14", "payloadVersion": 1}
01KEEZPQV908HYHK8KETZYZCHT	1	USER_LOGGED_IN	2026-01-08 14:20:55.528	2026-01-08 14:20:55.529	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEEZPQV8QZ0VS49PFSGV3V7Z	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5jbwbl0002bdrs3rx68h66", "payloadVersion": 1}
01KEEZTTH5Q7K7YZNFX57D06VB	1	INTENT_CREATED	2026-01-08 14:23:09.349	2026-01-08 14:23:09.349	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5jerkv0004bdrsfs3tf5hs	CLARIFY	NEW	ui	01KEEZTTH5P1Z30STY3KDQ774J	{"kpi": "1 car pwer week.", "goal": "Sell new car.", "risks": "no", "scope": "Only new cars", "title": "Sell new car.", "source": "manual", "context": "We have plenty of new cars and we need to sell it.", "intentId": "cmk5jerkv0004bdrsfs3tf5hs", "language": "EN", "deadlineAt": "2026-06-30T00:00:00.000Z", "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEEZZ98FM6E5VFYYBT8T6QZJ	1	INTENT_CREATED	2026-01-08 14:25:35.502	2026-01-08 14:25:35.503	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5jhwcq0006bdrsvh8hnxme	CLARIFY	NEW	ui	01KEEZZ98EQ4FTQMQ77H3CD8PD	{"kpi": "1000 eur / month", "goal": "Sell IT training", "risks": "in huge demant may strugle with trainers", "scope": "IT development trainings.", "title": "Sell IT training", "source": "manual", "context": "We have a portfolio of IT traininhg and can offer it to other companies.", "intentId": "cmk5jhwcq0006bdrsvh8hnxme", "language": "EN", "deadlineAt": "2026-12-30T00:00:00.000Z", "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEF2CJK7EYB143BHFN1TTRNZ	1	USER_LOGGED_OUT	2026-01-08 15:07:48.199	2026-01-08 15:07:48.199	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2CJK7QQ77B31JWAERH2MV	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5jbwbl0002bdrs3rx68h66", "payloadVersion": 1}
01KEF2CMTYFEFVZZRCBSXDK3B8	1	USER_LOGGED_IN	2026-01-08 15:07:50.494	2026-01-08 15:07:50.494	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2CMTY7Y9CXWDYT4NN2GAQ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l08d30009bdrscqqo00b9", "payloadVersion": 1}
01KEF2E1H99Q3KZ5CZ0A0KCR3P	1	USER_LOGGED_OUT	2026-01-08 15:08:36.264	2026-01-08 15:08:36.265	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2E1H8DQKW7RMHGVRRQAN5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l08d30009bdrscqqo00b9", "payloadVersion": 1}
01KEF2E6CD18KZQ611K2RYPNYA	1	USER_LOGGED_IN	2026-01-08 15:08:41.229	2026-01-08 15:08:41.229	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2E6CDNW2AKFYQKY80HG0C	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l1big000cbdrs69eubfa2", "payloadVersion": 1}
01KEF2SKWSD23K8EY1S50V9ACA	1	USER_LOGGED_OUT	2026-01-08 15:14:55.512	2026-01-08 15:14:55.513	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2SKWRVJ9Y5Z2RD5MEJ1YX	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l1big000cbdrs69eubfa2", "payloadVersion": 1}
01KEF2SPC96TSY4FVH3T4033J8	1	USER_LOGGED_IN	2026-01-08 15:14:58.057	2026-01-08 15:14:58.057	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2SPC916D7G0CHYBB6SXNW	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l9e9x000fbdrsh05vepg4", "payloadVersion": 1}
01KEF4GRW60QWTCHW8AZSFW2TS	1	USER_LOGGED_OUT	2026-01-08 15:45:02.854	2026-01-08 15:45:02.854	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF4GRW6WHF43C29KKWG1TSC	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l9e9x000fbdrsh05vepg4", "payloadVersion": 1}
01KEF4GV3M7BQ5S14NT8VJMYWV	1	USER_LOGGED_IN	2026-01-08 15:45:05.14	2026-01-08 15:45:05.14	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF4GV3M8C8BH9HYDH102FT2	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mc4mj000ibdrs149u8m0e", "payloadVersion": 1}
01KEF4W8ZBNF2DHN0W0ZYP4X99	1	USER_LOGGED_IN	2026-01-08 15:51:19.787	2026-01-08 15:51:19.787	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF4W8ZB05HM5F2RZTYCWNZG	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mk5pi000lbdrsoh4u8722", "payloadVersion": 1}
01KEF5BSDSF9NB2YF2ES730WAQ	1	USER_LOGGED_IN	2026-01-08 15:59:48.152	2026-01-08 15:59:48.153	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5BSDR4CZ5Z7G9RD20NHCS	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mv1yq000obdrs9tcnuzz3", "payloadVersion": 1}
01KEF5CQRYVTXEJ883PZMR63V2	1	USER_LOGGED_IN	2026-01-08 16:00:19.23	2026-01-08 16:00:19.231	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5CQRYXKPRTW34T71S07XJ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mvpxz000rbdrs6i5po5wz", "payloadVersion": 1}
01KEF5EDQWJ867X5ZXK8D9J94S	1	USER_LOGGED_IN	2026-01-08 16:01:14.492	2026-01-08 16:01:14.492	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5EDQW7AFZNN25HNR1XCP3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mwwl3000ubdrs0kuwp3tt", "payloadVersion": 1}
01KEF5F4D5VXHQMHQAWNV0ZHF4	1	USER_LOGGED_IN	2026-01-08 16:01:37.7	2026-01-08 16:01:37.701	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5F4D41G8RBYHK2NCMCN78	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mxehr000xbdrsib5u6lqf", "payloadVersion": 1}
01KEF5GJEJ96HJJP1K07V6N808	1	USER_LOGGED_IN	2026-01-08 16:02:24.849	2026-01-08 16:02:24.85	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5GJEHDT6B2JRK2BMYVDA1	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5myevh0010bdrsg1ewy7de", "payloadVersion": 1}
01KEF5RXJ9RSNCFNFMM29TE7M5	1	USER_LOGGED_IN	2026-01-08 16:06:58.377	2026-01-08 16:06:58.377	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5RXJ96ZR9H7NTHVGWZZH9	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5n49xf0013bdrsldnagcld", "payloadVersion": 1}
01KEF5SJHX2ZBNWGJRCWNPM394	1	USER_LOGGED_IN	2026-01-08 16:07:19.869	2026-01-08 16:07:19.869	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5SJHXT9N54H6529S6348H	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5n4qid0016bdrs07j3nfcu", "payloadVersion": 1}
01KEFFBH30XXRJ1Q6YBV6QRBZ0	1	USER_LOGGED_IN	2026-01-08 18:54:25.376	2026-01-08 18:54:25.376	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFBH30VCEEBFSW5J1V7DHJ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5t3m8p0019bdrsvmml8dyl", "payloadVersion": 1}
01KEFFFDNSQ7NFN96N7JSFDDJT	1	USER_LOGGED_IN	2026-01-08 18:56:32.953	2026-01-08 18:56:32.953	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFFDNSMSA3W99HZS6TZ73W	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5t6col001cbdrsj7swhztf", "payloadVersion": 1}
01KEFFQCB9YGR0Y188JYE84GZB	1	USER_LOGGED_IN	2026-01-08 19:00:53.736	2026-01-08 19:00:53.737	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFQCB8Q6Q497VGYDW9S8FS	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5tbxwd00021341akvvbg40", "payloadVersion": 1}
01KEFFSJDDE6WV13T9NPY1AJNK	1	USER_LOGGED_IN	2026-01-08 19:02:05.485	2026-01-08 19:02:05.486	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFSJDD48HWYFDX9SENER5Q	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5tdh9k00071341iavxyeut", "payloadVersion": 1}
01KEFFSJMV0A5NNAWGZYVSPSRD	1	INTENT_CREATED	2026-01-08 19:02:05.723	2026-01-08 19:02:05.723	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tdhg6000913412o3bqd4x	CLARIFY	NEW	ui	01KEFFSJMVPVC0ADSEET787YAE	{"title": "Test title", "source": "paste", "intentId": "cmk5tdhg6000913412o3bqd4x", "language": "EN", "sourceText": {"length": 10, "sha256": "95ba55c6ea6f04420f293d4a0fb0d28562e6aae18c1c8b05cd31ab7ed0c3c45a"}, "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEFFT87XRMZF63TSYKFXD3C1	1	USER_LOGGED_OUT	2026-01-08 19:02:27.837	2026-01-08 19:02:27.838	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFT87XHPMDHHC9JWY5FYH1	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mc4mj000ibdrs149u8m0e", "payloadVersion": 1}
01KEFFTAHS3CJRN8N2GP74C6ZF	1	USER_LOGGED_IN	2026-01-08 19:02:30.201	2026-01-08 19:02:30.201	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFTAHSF4FBGA7E6ZGBN0QE	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5te0c4000c1341951gp5ni", "payloadVersion": 1}
01KEFFTMGT0V64P8T7TW57N0KV	1	INTENT_CREATED	2026-01-08 19:02:40.41	2026-01-08 19:02:40.41	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5te87r000e1341tr7y1dat	CLARIFY	NEW	ui	01KEFFTMGTX9KJJ5R4PR1CY333	{"title": "Creating…", "source": "paste", "intentId": "cmk5te87r000e1341tr7y1dat", "language": "EN", "sourceText": {"length": 9, "sha256": "c79ed9492e3c17199ab50694e07f5525cc6d598a02531528b0eb5ed933cd5466"}, "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEFG1C5FYYCH2YVBPZGDBP1J	1	USER_LOGGED_IN	2026-01-08 19:06:21.231	2026-01-08 19:06:21.231	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFG1C5FB56HBQJSV3A1TFDZ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5tiylh000h1341k759b9ak", "payloadVersion": 1}
01KEFG1CH7T2WVZ5QT1BFD3FD7	1	INTENT_CREATED	2026-01-08 19:06:21.606	2026-01-08 19:06:21.607	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tiyvu000j1341uqwwes3f	CLARIFY	NEW	ui	01KEFG1CH6FH5P2WF6AFDDQNC3	{"title": "Smoke paste", "source": "paste", "intentId": "cmk5tiyvu000j1341uqwwes3f", "language": "EN", "sourceText": {"length": 18, "sha256": "1778bd5652ffd8cce22d6273040675e2a093e695ca5662c8d63498ecc488f515"}, "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEFGSHGSNVEH650VABF8DNRD	1	USER_LOGGED_IN	2026-01-08 19:19:33.144	2026-01-08 19:19:33.145	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFGSHGR0NCZ9RH6P9JWNJTH	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5tzxn5000m1341cg25lge8", "payloadVersion": 1}
01KEFGSHJRJYJ9RP7E538HR1M8	1	INTENT_CREATED	2026-01-08 19:19:33.207	2026-01-08 19:19:33.208	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	CLARIFY	NEW	ui	01KEFGSHJQKDCZHQJ5MKSYQNVB	{"title": "[SMOKE] Paste intent", "source": "paste", "intentId": "cmk5tzxoz000o1341jzo45i8m", "language": "EN", "sourceText": {"length": 29, "sha256": "d40b3acd936da11d958e23ef3994c743874f1238ddcfebd62be37a46570556f0"}, "payloadVersion": 1, "confidentialityLevel": "L1"}
\.


--
-- Data for Name: Intent; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Intent" (id, "orgId", "createdByUserId", goal, context, scope, kpi, risks, "deadlineAt", stage, "confidentialityLevel", source, "createdAt", "updatedAt", title, "sourceTextRaw", "sourceTextSha256", "sourceTextLength") FROM stdin;
cmk5jerkv0004bdrsfs3tf5hs	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	Sell new car.	We have plenty of new cars and we need to sell it.	Only new cars	1 car pwer week.	no	2026-06-30 00:00:00	NEW	L1	manual	2026-01-08 14:23:09.343	2026-01-08 14:23:09.343	\N	\N	\N	\N
cmk5jhwcq0006bdrsvh8hnxme	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	Sell IT training	We have a portfolio of IT traininhg and can offer it to other companies.	IT development trainings.	1000 eur / month	in huge demant may strugle with trainers	2026-12-30 00:00:00	NEW	L1	manual	2026-01-08 14:25:35.498	2026-01-08 14:25:35.498	\N	\N	\N	\N
cmk5tdhg6000913412o3bqd4x	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	Test title	\N	\N	\N	\N	\N	NEW	L1	paste	2026-01-08 19:02:05.718	2026-01-08 19:02:05.718	Test title	test paste	95ba55c6ea6f04420f293d4a0fb0d28562e6aae18c1c8b05cd31ab7ed0c3c45a	10
cmk5te87r000e1341tr7y1dat	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	Creating…	\N	\N	\N	\N	\N	NEW	L1	paste	2026-01-08 19:02:40.407	2026-01-08 19:02:40.407	Creating…	Creating…	c79ed9492e3c17199ab50694e07f5525cc6d598a02531528b0eb5ed933cd5466	9
cmk5tiyvu000j1341uqwwes3f	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	Smoke paste	\N	\N	\N	\N	\N	NEW	L1	paste	2026-01-08 19:06:21.595	2026-01-08 19:06:21.595	Smoke paste	Smoke paste intent	1778bd5652ffd8cce22d6273040675e2a093e695ca5662c8d63498ecc488f515	18
cmk5tzxoz000o1341jzo45i8m	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	[SMOKE] Paste intent	\N	\N	\N	\N	\N	NEW	L1	paste	2026-01-08 19:19:33.203	2026-01-08 19:19:33.203	[SMOKE] Paste intent	[SMOKE] Paste intent from VPS	d40b3acd936da11d958e23ef3994c743874f1238ddcfebd62be37a46570556f0	29
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Organization" (id, name, "createdAt", slug, "defaultLanguage", "policyAiEnabled", "policyShareLinksEnabled", "policyEmailIngestEnabled", status) FROM stdin;
cmjdakp0f0001ut2uv0n881s3	TEST01	2025-12-19 19:58:16.479	test01	EN	t	f	f	ACTIVE
cmje0pkpu000dut2u1z41ciku	TEST02	2025-12-20 08:09:54.21	test02	EN	t	f	f	ACTIVE
cmjejbes70007o1hxngxzzzw7	TEST03	2025-12-20 16:50:46.04	test03	EN	t	f	f	ACTIVE
cmk12kr4u000do1hxva29zgyd	TEST01 Nazwa Testowa	2026-01-05 11:20:50.527	test01-tname	EN	t	f	f	ACTIVE
cmk48grgv0006bmbcmahvvpfc	Admin	2026-01-07 16:29:00.559	admin	EN	t	f	f	ACTIVE
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."PasswordResetToken" (id, "userId", "tokenHash", "createdAt", "expiresAt", "usedAt") FROM stdin;
cmk13vhpg000213n32bejppkt	cmk12kr4x000fo1hxdcjik7rt	c3562318e2156a8ff438ebf8e79e2ac11f11a48b28f2dd1e57db10bf96a7d6c6	2026-01-05 11:57:11.14	2026-01-05 12:27:11.132	2026-01-05 12:03:25.09
cmk143i94000513n3w2do6ecr	cmk12kr4x000fo1hxdcjik7rt	543b5f1d7ddc3f065a68c072623aab4dac2fec4a3cd580213f446ce029446401	2026-01-05 12:03:25.096	2026-01-05 12:33:25.09	\N
cmk15e0kq0002ya7ahsshryg5	cmk12kr4x000fo1hxdcjik7rt	1271e4f51647d48b75ea1681d394c5140d630623f7d4e72379106790553c2b14	2026-01-05 12:39:35.019	2026-01-05 13:09:35.011	2026-01-05 12:48:55.83
cmk15q1b00005ya7af25k5v22	cmk12kr4x000fo1hxdcjik7rt	d412f11f7e6fc4efda36613bb833e8cc9c7c9861c8c4c338e95942f5ae7dd9d1	2026-01-05 12:48:55.837	2026-01-05 13:18:55.83	\N
cmk18urgn0008ya7aephyu2jp	cmk12kr4x000fo1hxdcjik7rt	78dc8414fdb9f49b98fb2dd030de383cb6446228ad663c337d342cc8976a47f3	2026-01-05 14:16:35.208	2026-01-05 14:46:35.202	\N
cmk3r88wk000bya7av3fodj38	cmk12kr4x000fo1hxdcjik7rt	ed051623d7929ebeaa3fb18b5ee50ff9b28e4e5a202ea3ab81aef8c80e4fe370	2026-01-07 08:26:29.78	2026-01-07 08:56:29.773	2026-01-07 08:27:57.22
cmk3ra4dj000eya7aou676wpg	cmk12kr4x000fo1hxdcjik7rt	dcc6647e610d759e5bffe285c190ba8a8de9389d032d4015c8dd2ac74fece76f	2026-01-07 08:27:57.224	2026-01-07 08:57:57.22	2026-01-07 08:38:20.847
cmk3rnhkl000hya7aaxdi1t10	cmk12kr4x000fo1hxdcjik7rt	007bda03a336dc074d1d62761569ce7a436c1b36f8191c3680fe2fe843d759dc	2026-01-07 08:38:20.853	2026-01-07 09:08:20.847	2026-01-07 08:42:24.537
cmk3rsplo000kya7a6zutneko	cmk12kr4x000fo1hxdcjik7rt	8a7efca7a22fdc722dee43670485e4ba54ab105556b76cbbe79d9a1fa3b75bff	2026-01-07 08:42:24.541	2026-01-07 09:12:24.537	\N
cmk3ztnyi000215kosdnx7uui	cmk12kr4x000fo1hxdcjik7rt	1d387dc20d83be22f5f0d649da0e20c6976261cfc40fb241690fc28dca60a98d	2026-01-07 12:27:05.994	2026-01-07 12:57:05.987	2026-01-07 12:29:47.315
cmk400c770002kr4xvoalh8i3	cmk12kr4x000fo1hxdcjik7rt	2bb28a593c3d42535035c6ec44db10009de9c82b20b7586be77bb55940aea67e	2026-01-07 12:32:17.347	2026-01-07 13:02:17.338	\N
cmk41o0hr0002i0v0dn8en4kf	cmk12kr4x000fo1hxdcjik7rt	7c0dc7ff849d862d0a832e4625678f9c23ae1440d34a60fd108ddfb659894af6	2026-01-07 13:18:41.536	2026-01-07 13:48:41.527	2026-01-07 13:19:18.984
cmk482b510004bmbc6a4l42az	cmk482b4p0001bmbck6q90zvv	618631a59eb1fedf7084ebd689afa8c0bfd3ae4a7bad4cbb1374559df16ba27a	2026-01-07 16:17:46.213	2026-01-07 16:47:46.206	\N
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Session" (id, "userId", "tokenHash", "createdAt", "expiresAt", "revokedAt") FROM stdin;
cmjdakp0p0005ut2uz4saqcrf	cmjdakp0k0003ut2ufp00eqzv	6d56a5096834c4876cbe9309194e9b227be23cbc8fc7ff8f3cda1ff07cf1b11b	2025-12-19 19:58:16.489	2025-12-20 07:58:16.457	2025-12-19 19:58:31.487
cmjdalfiq0008ut2u50saciqk	cmjdakp0k0003ut2ufp00eqzv	2abe08b56945dc697dd0e0cfbd34d5887fc64187b396f551eead41b83f49a824	2025-12-19 19:58:50.834	2025-12-20 07:58:50.829	2025-12-19 19:58:58.566
cmje0ourm000but2usyvwb2tw	cmjdakp0k0003ut2ufp00eqzv	546703cdbc1069fedf25aa0417c1297f272cefcfe48159a5ecaf9b03d3ea9be4	2025-12-20 08:09:20.579	2025-12-20 20:09:20.572	2025-12-20 08:09:38.086
cmje0pkpz000hut2u9qbj5swy	cmje0pkpw000fut2uqq8am6xm	b10b4f89e9ff9518994de75f92e0fa7ad8c8f506e32209e5d9d2cfe5939ec3fc	2025-12-20 08:09:54.215	2025-12-20 20:09:54.208	2025-12-20 08:11:16.568
cmje0vlx7000kut2umcar3fvt	cmje0pkpw000fut2uqq8am6xm	464800ef4086290da2e55c5ff64d5edf85fccdc546e7adfe858cb5b7f27b5498	2025-12-20 08:14:35.708	2025-12-20 20:14:35.703	2025-12-20 08:14:44.247
cmje0wap1000rut2ut8mdyltc	cmje0pkpw000fut2uqq8am6xm	68a0c7179497b92211be8753501651f2a66130332f4aba20c0c6131b8d869039	2025-12-20 08:15:07.814	2025-12-20 20:15:07.809	2025-12-20 08:30:10.291
cmje1fpal0002tvgv5d0v0jq4	cmje0pkpw000fut2uqq8am6xm	ce7e6959c4a404f69ab1507e736cdc9965fcff5c8484c55079cb448ad054e9ba	2025-12-20 08:30:13.198	2025-12-20 20:30:13.188	2025-12-20 08:30:21.316
cmje1tdi80005tvgvyduak82j	cmje0pkpw000fut2uqq8am6xm	6ec231c9361b29c3f57fccf7c7bc90308834f728c7f93d258dfe8846d1f808a9	2025-12-20 08:40:51.105	2025-12-20 20:40:51.099	2025-12-20 16:27:48.742
cmjeihzjs0002g1h76qvc4v6y	cmjdakp0k0003ut2ufp00eqzv	a14a03bc80d39daf86a859c071d228b35eadc3556c5b13d2e82ec7c119333782	2025-12-20 16:27:53.272	2025-12-21 04:27:53.266	2025-12-20 16:27:55.144
cmjeiqwr10002o1hxa6cnazc3	cmjdakp0k0003ut2ufp00eqzv	7ba49e2058dfe35f3fa62781ffba9d771eda4d61ee40a16b0c0b138f7c0c76ef	2025-12-20 16:34:49.55	2025-12-21 04:34:49.544	2025-12-20 16:34:51.486
cmjejb5ic0005o1hxkowop4vc	cmjdakp0k0003ut2ufp00eqzv	865f6f18b726a476c39a781a9dd82ce9377ad416aef9234612ef6483928f5adc	2025-12-20 16:50:34.021	2025-12-21 04:50:34.014	2025-12-20 16:50:35.564
cmjejbesc000bo1hx5jfbo3ea	cmjejbesa0009o1hxza9o6wpx	95902237da6065a42f45c46ec4b42ee6939924e3f64413b6dc86b7f007a9de38	2025-12-20 16:50:46.044	2025-12-21 04:50:46.037	2025-12-20 16:50:48.767
cmk12kr50000ho1hxukaj9r7i	cmk12kr4x000fo1hxdcjik7rt	8f1d32c38b63acb1f26dfdb69972d61cae09ed2be5c7ceea0ba298e087c74e9f	2026-01-05 11:20:50.532	2026-01-05 23:20:50.508	2026-01-05 11:28:32.133
cmk12upp9000ko1hxepfys1ze	cmk12kr4x000fo1hxdcjik7rt	f9a38f2440b0804766bff43cd7ee32944c65fd71bc8484611d3e8782d6664a21	2026-01-05 11:28:35.229	2026-01-05 23:28:35.225	2026-01-05 11:28:37.426
cmk3zxg3z000615kox8o064g4	cmk12kr4x000fo1hxdcjik7rt	7e321e874017d1aceed5793cbaea04b7b9e9587c0e271553b7f4765ee046fdbc	2026-01-07 12:30:02.448	2026-01-08 00:30:02.437	2026-01-07 13:18:29.306
cmk41p0on0006i0v0f9yumxui	cmk12kr4x000fo1hxdcjik7rt	0a6fc8dec9abbafc05f7515edc5da85584c305abc3381698840b19ebc7014304	2026-01-07 13:19:28.439	2026-01-08 01:19:28.433	2026-01-07 13:45:12.137
cmk469msl0002t8cit8rq2pux	cmk12kr4x000fo1hxdcjik7rt	af229bf5c7460ce36903813d9a4a724b90f7a61f227c106949f3e656a4b119f0	2026-01-07 15:27:28.678	2026-01-08 03:27:28.67	2026-01-07 15:30:54.478
cmk46etry0008t8cia912fv9m	cmk12kr4x000fo1hxdcjik7rt	6b6712f99776212877f4a714d5d6d64daf87330f9004f9cf8d9ef5553ba0a4f9	2026-01-07 15:31:31.006	2026-01-08 03:31:31.001	\N
cmk46e8g90005t8ci4a1tj9xw	cmk12kr4x000fo1hxdcjik7rt	9b5d71870b57b2d6bc047563c37adf13a2267aba845048330f99d726f923aa18	2026-01-07 15:31:03.369	2026-01-08 03:31:03.364	2026-01-07 16:28:28.161
cmk48grh3000abmbc9dwdqdp1	cmk48grgz0008bmbcp8s2vrap	deffbf93d25a49fa2b4d5ec715c447fd5c0328d46f2c3a5918a014a08a7cfb52	2026-01-07 16:29:00.567	2026-01-08 04:29:00.552	2026-01-07 16:29:21.784
cmk49wfky000210ufpmjytmgm	cmk48grgz0008bmbcp8s2vrap	7e0cbd5db1e1385ac1688e56ba9df00ce795c4284966ae6e9f3a9457bacdab02	2026-01-07 17:09:11.266	2026-01-08 05:09:11.258	\N
cmk5cgu36000510ufair0t79h	cmk48grgz0008bmbcp8s2vrap	de9bb6d4295120b03692d3864591ac24b8b25e3d49a2b529e48b950554f21536	2026-01-08 11:08:48.594	2026-01-08 23:08:48.588	2026-01-08 11:53:55.095
cmk5e2w7q000810ufvs1whblh	cmk48grgz0008bmbcp8s2vrap	9399b61e599071383b5fb2544ac47428705ae093478f6ecd57f6bd23e7dcb257	2026-01-08 11:53:57.398	2026-01-08 23:53:57.392	2026-01-08 12:08:53.584
cmk5em84v0002h66lyo9xac54	cmk12kr4x000fo1hxdcjik7rt	f8514d7671ec0352d2dc44086390dfaab71a62c14e9298783327649d15384eb2	2026-01-08 12:08:59.311	2026-01-09 00:08:59.303	2026-01-08 12:10:18.565
cmk5enza40005h66lh94scp4y	cmk12kr4x000fo1hxdcjik7rt	8894efb39dbe5778c52dd36665c150d382d85ace814b8343b400cd638f6608fd	2026-01-08 12:10:21.148	2026-01-09 00:10:21.143	2026-01-08 12:11:11.956
cmk5eppc20008h66lovk0zw5j	cmk12kr4x000fo1hxdcjik7rt	077d03a5cb48c1fb365a725cf79907cb9e91c7b3fe36866f925e4ba5dd24d0a2	2026-01-08 12:11:41.571	2026-01-09 00:11:41.565	2026-01-08 12:19:13.619
cmk5ezfop000bh66lppwyol68	cmk12kr4x000fo1hxdcjik7rt	adc5dcc10777758b8e78acd37c7ff0470f46c052f099d043bed0f352e7bc250b	2026-01-08 12:19:15.625	2026-01-09 00:19:15.62	2026-01-08 12:35:24.901
cmk5fk9aw00029x9sqe9w53g9	cmk12kr4x000fo1hxdcjik7rt	7e7ddd9626bb9a586eaec5fd91486f8338b7ca4b34f352dead1f1ca7bdb02914	2026-01-08 12:35:27.128	2026-01-09 00:35:27.116	2026-01-08 12:35:47.314
cmk5fkrt300059x9s3dod0n47	cmk48grgz0008bmbcp8s2vrap	f2d31a13e05abaf23f6abfee858ab38fd947b7314bd9dcb9f1def4fc4c7e29f0	2026-01-08 12:35:51.112	2026-01-09 00:35:51.105	2026-01-08 12:49:48.981
cmk5g2s6u000210ytbbztu53x	cmk48grgz0008bmbcp8s2vrap	729738d921dee21d8e03d8354775a0ec6daec6d05d96fc51ec8c4957d38f3760	2026-01-08 12:49:51.414	2026-01-09 00:49:51.406	2026-01-08 12:50:16.005
cmk5g3evh000510ytxdm5ju30	cmk12kr4x000fo1hxdcjik7rt	703581d54e29bd8a8be584eedd89976204393e94e633ff98aced6eea3b34f687	2026-01-08 12:50:20.814	2026-01-09 00:50:20.807	2026-01-08 12:50:25.492
cmk5g3lbl000810yt15ql6i2o	cmk48grgz0008bmbcp8s2vrap	8c82d7c1d17dfbaffe1c0f9179e9aa024192a2302775ff0572295fe6283d2d70	2026-01-08 12:50:29.169	2026-01-09 00:50:29.164	2026-01-08 12:50:52.986
cmk5hv5jv000b10ytbdyu1ki8	cmk48grgz0008bmbcp8s2vrap	35f7fb00a14d837907dbbab4fafcd783bf8b4dc775669a7edfdbdd192c6ccb29	2026-01-08 13:39:54.715	2026-01-09 01:39:54.708	2026-01-08 13:40:36.775
cmk5hw3jt000e10yt4vt51e33	cmk48grgz0008bmbcp8s2vrap	de5fdec9851725ab255967872e05c65143bb4d819c31b51d375e9a38ff615af5	2026-01-08 13:40:38.777	2026-01-09 01:40:38.77	2026-01-08 13:41:21.159
cmk5hx4ut000h10ytxlbssx14	cmk12kr4x000fo1hxdcjik7rt	07de0bb826eb5b8e0220119c46f594dad06f81eb57cbf5ca4750d97fae8b875a	2026-01-08 13:41:27.126	2026-01-09 01:41:27.121	2026-01-08 14:20:53.236
cmk5jbwbl0002bdrs3rx68h66	cmk12kr4x000fo1hxdcjik7rt	2e7bcf654fa81ec16380481c32aa60d21477b5a833eec4d2e37507b0e7626b91	2026-01-08 14:20:55.521	2026-01-09 02:20:55.512	2026-01-08 15:07:48.194
cmk5l08d30009bdrscqqo00b9	cmk12kr4x000fo1hxdcjik7rt	8c4f268aa501a41390e1ca6faa677fbcfc39488f6bca8cf6d402daeb38ddbcf8	2026-01-08 15:07:50.487	2026-01-09 03:07:50.48	2026-01-08 15:08:36.261
cmk5l1big000cbdrs69eubfa2	cmk12kr4x000fo1hxdcjik7rt	33504d8c2fb9f1348be4e0ba8cbe8043699874e3f5b8235ed7944e26eb636d98	2026-01-08 15:08:41.224	2026-01-09 03:08:41.219	2026-01-08 15:14:55.509
cmk5l9e9x000fbdrsh05vepg4	cmk12kr4x000fo1hxdcjik7rt	c686f63eeeaa42c490096cdfc8b29dd789644f8b320070cd11f324d25e6860fc	2026-01-08 15:14:58.053	2026-01-09 03:14:58.049	2026-01-08 15:45:02.817
cmk5mk5pi000lbdrsoh4u8722	cmk12kr4x000fo1hxdcjik7rt	217dadda5e827fdbe68a4cb116223e35311c6299f845d8e2e215181fbf2b3667	2026-01-08 15:51:19.783	2026-01-09 03:51:19.777	\N
cmk5mv1yq000obdrs9tcnuzz3	cmk12kr4x000fo1hxdcjik7rt	05438f3fb81083bcfcb2486cc5d2873d20edab46c8c0491125f239bc8bf84367	2026-01-08 15:59:48.146	2026-01-09 03:59:48.141	\N
cmk5mvpxz000rbdrs6i5po5wz	cmk12kr4x000fo1hxdcjik7rt	ac484b8cda6572c49c9b24bf01f11ee1786c01dd85ee5432517a51f28cf3db8c	2026-01-08 16:00:19.224	2026-01-09 04:00:19.217	\N
cmk5mwwl3000ubdrs0kuwp3tt	cmk12kr4x000fo1hxdcjik7rt	9bfbca5010701b06eb77225008829f009397f01a08db92a5c8d2811e80e4dfdc	2026-01-08 16:01:14.487	2026-01-09 04:01:14.481	\N
cmk5mxehr000xbdrsib5u6lqf	cmk12kr4x000fo1hxdcjik7rt	4dcf618ef054382057b65641dbf0a365725fd473d93e65e204b8d6c78d866097	2026-01-08 16:01:37.696	2026-01-09 04:01:37.691	\N
cmk5myevh0010bdrsg1ewy7de	cmk12kr4x000fo1hxdcjik7rt	9d5c1c9d0a0ffcb1bd143ab28b7cfd13cdb7e7ec5a9ca33f6673af52834a0abd	2026-01-08 16:02:24.845	2026-01-09 04:02:24.841	\N
cmk5n49xf0013bdrsldnagcld	cmk12kr4x000fo1hxdcjik7rt	bb67b078621cfe57c32aae9ee2cfa1cef7423cfc810c8be7e5da609df1589711	2026-01-08 16:06:58.372	2026-01-09 04:06:58.366	\N
cmk5n4qid0016bdrs07j3nfcu	cmk12kr4x000fo1hxdcjik7rt	dfa182e2f05c16dbdbd7f7c35a04536455d50ccb900c0208d4bd1bf3f49d818b	2026-01-08 16:07:19.861	2026-01-09 04:07:19.856	\N
cmk5t3m8p0019bdrsvmml8dyl	cmk12kr4x000fo1hxdcjik7rt	425689e2c3c9cc66d581978efd25ccf7c1e4bdc37ba9eae63453b04aaa05ccb8	2026-01-08 18:54:25.369	2026-01-09 06:54:25.364	\N
cmk5t6col001cbdrsj7swhztf	cmk12kr4x000fo1hxdcjik7rt	4a1e9c3558dc5f28b65a83b191c28354ae745c895bcbfcc524217b6f81f84159	2026-01-08 18:56:32.949	2026-01-09 06:56:32.945	\N
cmk5tbxwd00021341akvvbg40	cmk12kr4x000fo1hxdcjik7rt	44402883d9c72cf4b0b46ce4fb42ce7a909d64215428ae8d5f75ad8fcca6ecf6	2026-01-08 19:00:53.726	2026-01-09 07:00:53.715	\N
cmk5tdh9k00071341iavxyeut	cmk12kr4x000fo1hxdcjik7rt	c90c8ecdf598428fb8d9de87f2bc1dd476b3da3e3249dcd4e7b30b2f69cad8df	2026-01-08 19:02:05.48	2026-01-09 07:02:05.475	\N
cmk5mc4mj000ibdrs149u8m0e	cmk12kr4x000fo1hxdcjik7rt	ef923628285fe12a9ca8b6b85484f8e920e4c09547d6997e024a4d4f3657fd51	2026-01-08 15:45:05.132	2026-01-09 03:45:05.112	2026-01-08 19:02:27.834
cmk5te0c4000c1341951gp5ni	cmk12kr4x000fo1hxdcjik7rt	862cebc5d85f2791d4b92dc14ce136cc7b268fa641d3041f3389339207681241	2026-01-08 19:02:30.196	2026-01-09 07:02:30.192	\N
cmk5tiylh000h1341k759b9ak	cmk12kr4x000fo1hxdcjik7rt	98eadcdd348ce67a685e6ffc760ce5f63c424be875cdbf4ee94754b98e7e4753	2026-01-08 19:06:21.222	2026-01-09 07:06:21.214	\N
cmk5tzxn5000m1341cg25lge8	cmk12kr4x000fo1hxdcjik7rt	abbf7eb3c1e6909f747fc1662f163b1573dd64d4b076a9f650662296dfc65b5b	2026-01-08 19:19:33.138	2026-01-09 07:19:33.132	\N
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."User" (id, "orgId", email, role, "createdAt", "passwordHash", "passwordUpdatedAt", "lastLoginAt", "deactivatedAt") FROM stdin;
cmje0pkpw000fut2uqq8am6xm	cmje0pkpu000dut2u1z41ciku	info2@staadit.com	Owner	2025-12-20 08:09:54.212	scrypt$16384$8$1$4a0f57a2d209f21c57f003a07081d066$b5b8d5223f55670d58c86d43fd519e0c930e971d0f906fdfaba3d8864164cb174aa6ec06ffd563c02cac5ae2590af8b6a6a2dff50f1bbb5229820c55a69f05e6	2025-12-20 08:09:54.208	2025-12-20 08:40:51.099	\N
cmjdakp0k0003ut2ufp00eqzv	cmjdakp0f0001ut2uv0n881s3	info1@staadit.com	Owner	2025-12-19 19:58:16.485	scrypt$16384$8$1$5c4a3b9311e7279a7aebef2514244914$28376ef7428969c473c6dafc5f9583c9977a33f2a337be87625f064716375363ea478817b2d3ce9b37b67df6751cd9a11b1ff71fe6ac334f7b437bcd57ee95b9	2025-12-19 19:58:16.457	2025-12-20 16:50:34.014	\N
cmjejbesa0009o1hxza9o6wpx	cmjejbes70007o1hxngxzzzw7	info3@staadit.com	Owner	2025-12-20 16:50:46.042	scrypt$16384$8$1$ede6761328706ccb2354fdb64c762301$13f8654a67088179e19602da5eba2fcb0af261567d24aa370351bad95c2a86fb3aeeb11290f5885f06faa1b3dddeefe346f848e5fa31f4e098884322806f3802	2025-12-20 16:50:46.037	2025-12-20 16:50:46.037	\N
cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	admin@enabion.com	Owner	2026-01-07 16:29:00.563	scrypt$16384$8$1$f90de0b3da295e2cdb923f204e4d083e$151110312f0a7b03341c7ddfb99c18171daa5da474065cd941086780486b097fec6f69552c5aee7912a82b73dd36e81a91cd96f5a2ecf0e7ae40f35fe1915757	2026-01-07 16:29:00.552	2026-01-08 13:40:38.77	\N
cmk482b4p0001bmbck6q90zvv	cmk12kr4u000do1hxva29zgyd	test02@enabion.com	Viewer	2026-01-07 16:17:46.198	\N	\N	\N	\N
cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	test01@enabion.com	Owner	2026-01-05 11:20:50.53	scrypt$16384$8$1$4f0b0dbea49ee8669483b1cf366b5df4$35a41cb7911c638c084bc3e49f9860de0b862da1bce37982adfb806fb71e38f772c4fc546446562ae7001ca73278185b2dfc36fcc0d9ebbce0834c17d3764b8d	2026-01-07 13:19:18.984	2026-01-08 19:19:33.132	\N
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4b94872d-a3e2-46cb-b7a6-7f5f6bd9b084	2b1715731cd35fd42cffbb99a75344acbacc5a25469ff59fc6fd4bb355c8b042	2025-12-15 20:05:00.958438+00	20251215203010_add_event_table	\N	\N	2025-12-15 20:05:00.93144+00	1
fd6aa896-2a4c-4204-aee7-0e8c1a6b5db4	c20093dbc7ba0bd1cd6986a2cfa267effb2fe308d0ab29600dfeffc9545eddb1	2026-01-07 15:58:30.672366+00	20260107190000_adminpanel_org_settings	\N	\N	2026-01-07 15:58:30.653345+00	1
4ae6d8e8-3db8-4ae0-9669-95713fc2ae35	9467b83f8b636cbd9f9c7cf5770d0dfbbb3fcd03edc2bbd042a8d28e8d960457	2025-12-17 15:40:42.913405+00	20251218_add_blobstore	\N	\N	2025-12-17 15:40:42.867957+00	1
f44b326c-c82c-4a2b-964a-c521c73b6054	80d9b493a19eb4733e00a774dd152b8292ae5d2ad99562b1fada7bf62a53cb95	2025-12-17 15:48:05.76771+00	20251217_make_lifecycle_required	\N	\N	2025-12-17 15:48:05.748703+00	1
e24fc9fd-7ba3-4e33-8c80-0d841a3335d6	77ca0523c7b8f8e59181f1aa73fc344aa258e78fdd8414d61b291a2a97be59a7	2025-12-19 18:50:33.120915+00	20251219141500_add_auth_sessions	\N	\N	2025-12-19 18:50:33.037265+00	1
5e46a49b-ef17-4607-ad25-560c1a739cfe	c20cec22f046d2cd9bc0f67e7effc54c95a1107e5fd1512c6f33e7cbb4ba2f67	2026-01-07 17:05:23.626077+00	20260107173000_add_org_status	\N	\N	2026-01-07 17:05:23.609546+00	1
0d9ccab5-60d8-499b-8d34-60e2bfb0e89f	3c05e88f6329d8e73a7adfeafdadc75420af59cfbeed3c453fb0ecba41e88948	2025-12-20 08:28:06.449514+00	20251219141000_add_password_reset_tokens	\N	\N	2025-12-20 08:28:06.419183+00	1
60510631-ad11-407d-9b94-572c486b809c	c20093dbc7ba0bd1cd6986a2cfa267effb2fe308d0ab29600dfeffc9545eddb1	\N	20260107190000_adminpanel_org_settings	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260107190000_adminpanel_org_settings\n\nDatabase error code: 23505\n\nDatabase error:\nERROR: could not create unique index "Organization_slug_key"\nDETAIL: Key (slug)=(test01) is duplicated.\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E23505), message: "could not create unique index \\"Organization_slug_key\\"", detail: Some("Key (slug)=(test01) is duplicated."), hint: None, position: None, where_: None, schema: Some("public"), table: Some("Organization"), column: None, datatype: None, constraint: Some("Organization_slug_key"), file: Some("tuplesortvariants.c"), line: Some(1361), routine: Some("comparetup_index_btree") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260107190000_adminpanel_org_settings"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20260107190000_adminpanel_org_settings"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-01-07 15:58:23.484369+00	2026-01-07 15:43:05.413996+00	0
b798861d-4dd6-4e90-be14-05b0427aae06	f5aa2489c3afe48e98ce8445146d3fc7d77bf8e59c25bc7d6ea2b436f15fa252	2026-01-08 14:20:21.248674+00	20260108150000_add_intents	\N	\N	2026-01-08 14:20:21.205326+00	1
89a8eac7-5a94-41d0-871e-a7939850ed5e	d36186bdb0a946d54792dc0da87f0a7cab92e81c35ea065ff7d9e22f8f0ee38b	2026-01-08 19:01:49.958728+00	20260108160000_add_intent_paste_fields	\N	\N	2026-01-08 19:01:49.945477+00	1
\.


--
-- Name: Attachment Attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_pkey" PRIMARY KEY (id);


--
-- Name: Blob Blob_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Blob"
    ADD CONSTRAINT "Blob_pkey" PRIMARY KEY (id);


--
-- Name: Event Event_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_pkey" PRIMARY KEY (id);


--
-- Name: Intent Intent_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_pkey" PRIMARY KEY (id);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: User User_email_key; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_email_key" UNIQUE (email);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Attachment_intentId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Attachment_intentId_idx" ON public."Attachment" USING btree ("intentId");


--
-- Name: Attachment_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Attachment_orgId_idx" ON public."Attachment" USING btree ("orgId");


--
-- Name: Blob_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Blob_orgId_idx" ON public."Blob" USING btree ("orgId");


--
-- Name: Blob_orgId_objectKey_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Blob_orgId_objectKey_idx" ON public."Blob" USING btree ("orgId", "objectKey");


--
-- Name: Event_correlationId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_correlationId_idx" ON public."Event" USING btree ("correlationId");


--
-- Name: Event_occurredAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_occurredAt_idx" ON public."Event" USING btree ("occurredAt");


--
-- Name: Event_orgId_subjectId_type_occurredAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_orgId_subjectId_type_occurredAt_idx" ON public."Event" USING btree ("orgId", "subjectId", type, "occurredAt");


--
-- Name: Intent_createdByUserId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_createdByUserId_idx" ON public."Intent" USING btree ("createdByUserId");


--
-- Name: Intent_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_idx" ON public."Intent" USING btree ("orgId");


--
-- Name: Intent_orgId_stage_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_stage_idx" ON public."Intent" USING btree ("orgId", stage);


--
-- Name: Organization_slug_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "Organization_slug_key" ON public."Organization" USING btree (slug);


--
-- Name: PasswordResetToken_expiresAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "PasswordResetToken_expiresAt_idx" ON public."PasswordResetToken" USING btree ("expiresAt");


--
-- Name: PasswordResetToken_tokenHash_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "PasswordResetToken_tokenHash_key" ON public."PasswordResetToken" USING btree ("tokenHash");


--
-- Name: PasswordResetToken_userId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "PasswordResetToken_userId_idx" ON public."PasswordResetToken" USING btree ("userId");


--
-- Name: Session_expiresAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Session_expiresAt_idx" ON public."Session" USING btree ("expiresAt");


--
-- Name: Session_tokenHash_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "Session_tokenHash_key" ON public."Session" USING btree ("tokenHash");


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: Attachment Attachment_blobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_blobId_fkey" FOREIGN KEY ("blobId") REFERENCES public."Blob"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Attachment Attachment_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Blob Blob_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Blob"
    ADD CONSTRAINT "Blob_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Event Event_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Intent Intent_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Intent Intent_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict NbVYUBkD3OF0vJkmekYf10zxxjnyq6asdf0clLPYQFdsgSMLkBvP5llik2vmlkv

