--
-- PostgreSQL database dump
--

\restrict NnG5o2Zdw2cEUYCSO705dOSegIkfHeoHiVeNxFEFVYPidwgaBeHw4QssFB900ix

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AttachmentSource; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AttachmentSource" AS ENUM (
    'email_ingest',
    'manual_upload',
    'export'
);


ALTER TYPE public."AttachmentSource" OWNER TO enabion;

--
-- Name: BlobStorageDriver; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."BlobStorageDriver" AS ENUM (
    'local',
    's3'
);


ALTER TYPE public."BlobStorageDriver" OWNER TO enabion;

--
-- Name: ConfidentialityLevel; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."ConfidentialityLevel" AS ENUM (
    'L1',
    'L2',
    'L3'
);


ALTER TYPE public."ConfidentialityLevel" OWNER TO enabion;

--
-- Name: IntentSource; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."IntentSource" AS ENUM (
    'manual',
    'paste',
    'email'
);


ALTER TYPE public."IntentSource" OWNER TO enabion;

--
-- Name: IntentStage; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."IntentStage" AS ENUM (
    'NEW',
    'CLARIFY',
    'MATCH',
    'COMMIT',
    'WON',
    'LOST'
);


ALTER TYPE public."IntentStage" OWNER TO enabion;

--
-- Name: NdaChannel; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."NdaChannel" AS ENUM (
    'ui',
    'api'
);


ALTER TYPE public."NdaChannel" OWNER TO enabion;

--
-- Name: NdaType; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."NdaType" AS ENUM (
    'MUTUAL'
);


ALTER TYPE public."NdaType" OWNER TO enabion;

--
-- Name: OrganizationStatus; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."OrganizationStatus" AS ENUM (
    'ACTIVE',
    'SUSPENDED'
);


ALTER TYPE public."OrganizationStatus" OWNER TO enabion;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Attachment; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Attachment" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text,
    source public."AttachmentSource" DEFAULT 'manual_upload'::public."AttachmentSource" NOT NULL,
    filename text NOT NULL,
    "blobId" text NOT NULL,
    "createdByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Attachment" OWNER TO enabion;

--
-- Name: Blob; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Blob" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "storageDriver" public."BlobStorageDriver" DEFAULT 'local'::public."BlobStorageDriver" NOT NULL,
    "objectKey" text NOT NULL,
    "sizeBytes" integer NOT NULL,
    sha256 character(64) NOT NULL,
    "contentType" text NOT NULL,
    confidentiality public."ConfidentialityLevel" DEFAULT 'L1'::public."ConfidentialityLevel" NOT NULL,
    encrypted boolean DEFAULT false NOT NULL,
    "encryptionAlg" text,
    "encryptionKeyId" text,
    "encryptionIvB64" text,
    "encryptionTagB64" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Blob" OWNER TO enabion;

--
-- Name: Event; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Event" (
    id text NOT NULL,
    "schemaVersion" integer NOT NULL,
    type text NOT NULL,
    "occurredAt" timestamp(3) without time zone NOT NULL,
    "recordedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "orgId" text NOT NULL,
    "actorUserId" text,
    "actorOrgId" text,
    "subjectType" text NOT NULL,
    "subjectId" text NOT NULL,
    "lifecycleStep" text DEFAULT 'CLARIFY'::text NOT NULL,
    "pipelineStage" text DEFAULT 'NEW'::text NOT NULL,
    channel text NOT NULL,
    "correlationId" text NOT NULL,
    payload jsonb NOT NULL
);


ALTER TABLE public."Event" OWNER TO enabion;

--
-- Name: Intent; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Intent" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "createdByUserId" text NOT NULL,
    goal text NOT NULL,
    context text,
    scope text,
    kpi text,
    risks text,
    "deadlineAt" timestamp(3) without time zone,
    stage public."IntentStage" DEFAULT 'NEW'::public."IntentStage" NOT NULL,
    "confidentialityLevel" public."ConfidentialityLevel" DEFAULT 'L1'::public."ConfidentialityLevel" NOT NULL,
    source public."IntentSource" DEFAULT 'manual'::public."IntentSource" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    title text,
    "sourceTextRaw" text,
    "sourceTextSha256" character(64),
    "sourceTextLength" integer,
    client text,
    "ownerUserId" text,
    language text DEFAULT 'EN'::text NOT NULL,
    "lastActivityAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Intent" OWNER TO enabion;

--
-- Name: IntentShareLink; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."IntentShareLink" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text NOT NULL,
    "createdByUserId" text NOT NULL,
    "tokenHashSha256" character(64) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone,
    "revokedByUserId" text,
    "lastAccessAt" timestamp(3) without time zone,
    "accessCount" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."IntentShareLink" OWNER TO enabion;

--
-- Name: NdaAcceptance; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."NdaAcceptance" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "counterpartyOrgId" text,
    "ndaType" public."NdaType" DEFAULT 'MUTUAL'::public."NdaType" NOT NULL,
    "ndaVersion" text NOT NULL,
    "enHashSha256" character(64) NOT NULL,
    "acceptedByUserId" text NOT NULL,
    "acceptedAt" timestamp(3) without time zone NOT NULL,
    language text NOT NULL,
    channel public."NdaChannel" NOT NULL,
    "typedName" text NOT NULL,
    "typedRole" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."NdaAcceptance" OWNER TO enabion;

--
-- Name: NdaDocument; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."NdaDocument" (
    id text NOT NULL,
    "ndaType" public."NdaType" DEFAULT 'MUTUAL'::public."NdaType" NOT NULL,
    "ndaVersion" text NOT NULL,
    "enMarkdown" text NOT NULL,
    "summaryPl" text,
    "summaryDe" text,
    "summaryNl" text,
    "enHashSha256" character(64) NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."NdaDocument" OWNER TO enabion;

--
-- Name: Organization; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    slug text NOT NULL,
    "defaultLanguage" text DEFAULT 'EN'::text NOT NULL,
    "policyAiEnabled" boolean DEFAULT true NOT NULL,
    "policyShareLinksEnabled" boolean DEFAULT false NOT NULL,
    "policyEmailIngestEnabled" boolean DEFAULT false NOT NULL,
    status public."OrganizationStatus" DEFAULT 'ACTIVE'::public."OrganizationStatus" NOT NULL
);


ALTER TABLE public."Organization" OWNER TO enabion;

--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone
);


ALTER TABLE public."PasswordResetToken" OWNER TO enabion;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


ALTER TABLE public."Session" OWNER TO enabion;

--
-- Name: ThemePalette; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."ThemePalette" (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    "tokensJson" jsonb NOT NULL,
    "isGlobalDefault" boolean DEFAULT false NOT NULL,
    "createdByUserId" text,
    "updatedByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ThemePalette" OWNER TO enabion;

--
-- Name: ThemePaletteRevision; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."ThemePaletteRevision" (
    id text NOT NULL,
    "paletteId" text NOT NULL,
    revision integer NOT NULL,
    "tokensJson" jsonb NOT NULL,
    "createdByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ThemePaletteRevision" OWNER TO enabion;

--
-- Name: User; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "passwordHash" text,
    "passwordUpdatedAt" timestamp(3) without time zone,
    "lastLoginAt" timestamp(3) without time zone,
    "deactivatedAt" timestamp(3) without time zone
);


ALTER TABLE public."User" OWNER TO enabion;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO enabion;

--
-- Data for Name: Attachment; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Attachment" (id, "orgId", "intentId", source, filename, "blobId", "createdByUserId", "createdAt") FROM stdin;
a18908ca-43ce-4050-b996-fdff09dea594	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	manual_upload	SWZ - na Åwiadczeniu usÅug dotyczÄcych przygotowania dokumentacji przetargowej i udziaÅ w przeprowadzeniu postÄpowaÅ-sig.pdf	a885d294-2b0c-4e3c-b668-28ba3ce3378b	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 11:17:51.189
68903f1d-3d55-4d20-b2a3-e69e6e24a7d7	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	manual_upload	Wzor_zapytania_ofertowego_31082018.pdf	732de7ff-3d34-439c-a1e0-6329f7fdbb23	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 11:18:22.789
55dd579c-72a2-486b-98ea-58bc5c90307e	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	manual_upload	Wzor_zapytania_ofertowego_31082018.pdf	d8defd33-e568-457b-b2ce-41dbabb11e36	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 11:24:03.061
28186488-2989-428f-8b96-a7db41abf6a5	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	manual_upload	Wzor_zapytania_ofertowego_31082018.pdf	5836ed3e-df1b-41a8-8ee1-a6330d0866e6	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 11:28:33.711
2bf33850-1abc-48cf-b737-974c780e934d	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	manual_upload	quantum.png	eccdb471-212a-4dd8-8b45-fbb2e897afba	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 11:29:47.784
fc5c4518-ab41-4653-979c-62e62253fa6b	cmk12kr4u000do1hxva29zgyd	cmk5tiyvu000j1341uqwwes3f	manual_upload	Adv01.JPEG	64890f69-bd33-4b9d-aa60-ea77efd21865	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 11:30:27.453
d31f1aaf-b18f-40db-a3c7-50e06dbc87fd	cmk12kr4u000do1hxva29zgyd	cmk5tiyvu000j1341uqwwes3f	manual_upload	Wzor_zapytania_ofertowego_31082018 (1).pdf	7ad147ca-4584-464e-a84a-d420cdddd7d0	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 11:30:41.776
a79ef63f-750e-4e3d-bec4-4d3b7ada409c	cmk12kr4u000do1hxva29zgyd	cmk5tiyvu000j1341uqwwes3f	manual_upload	Wzor_zapytania_ofertowego_31082018.pdf	b17f8104-3602-4ae5-ba66-b80668fa7a96	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 12:37:09.01
de3d27d3-23a2-4a68-afb5-6c7c0d835d7a	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	manual_upload	Phase1_MVP-Spec (1).md	0c10ee21-2d34-47ed-ba3e-98f292a3254c	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 12:37:59.984
af124402-0346-4076-aaf0-0a4578e1e1bc	cmk12kr4u000do1hxva29zgyd	cmk5tiyvu000j1341uqwwes3f	manual_upload	Phase1_MVP-Spec.md	d04d65df-4f8a-42be-bb7d-5019bf270bc6	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 12:40:16.989
f25d9e08-7a0f-48f1-b257-55a2cbb86a85	cmk12kr4u000do1hxva29zgyd	cmk5tiyvu000j1341uqwwes3f	manual_upload	Phase1_MVP-Spec.md	e75020f7-f8a8-4c89-8412-6f6892e14e72	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 13:14:16.561
cd1f3b9a-1ce1-4e43-b8c4-1da4874d14b5	cmk12kr4u000do1hxva29zgyd	cmk5te87r000e1341tr7y1dat	manual_upload	Phase1_MVP-Spec.md	43ca167b-fd8a-4eaa-bbc4-b1021a989884	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 13:39:01.362
3068d846-ba20-4074-863a-9eb1dde45477	cmk12kr4u000do1hxva29zgyd	cmk5te87r000e1341tr7y1dat	manual_upload	Phase1_MVP-Spec (1).md	f01fdb8d-1821-4175-b8bb-e3da609acf05	cmk12kr4x000fo1hxdcjik7rt	2026-01-09 13:39:07.276
\.


--
-- Data for Name: Blob; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Blob" (id, "orgId", "storageDriver", "objectKey", "sizeBytes", sha256, "contentType", confidentiality, encrypted, "encryptionAlg", "encryptionKeyId", "encryptionIvB64", "encryptionTagB64", "createdAt") FROM stdin;
a885d294-2b0c-4e3c-b668-28ba3ce3378b	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/a885d294-2b0c-4e3c-b668-28ba3ce3378b/SWZ_-_na___wiadczeniu_us__ug_dotycz__cych_przygotowania_dokumentacji_przetargowej_i_udzia___w_przeprowadzeniu_post__powa__-sig.pdf	1211889	0236e48a0de3d169350b8bfa2b9ba7031a70c2c8f49dfa45830821d49de5c2ce	application/pdf	L1	f	\N	\N	\N	\N	2026-01-09 11:17:51.179
732de7ff-3d34-439c-a1e0-6329f7fdbb23	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/732de7ff-3d34-439c-a1e0-6329f7fdbb23/Wzor_zapytania_ofertowego_31082018.pdf	225728	ba630097b331722853ea1e97183738c13c050ebf84c0f0f54234c24ee13d88ff	application/pdf	L1	f	\N	\N	\N	\N	2026-01-09 11:18:22.786
d8defd33-e568-457b-b2ce-41dbabb11e36	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/d8defd33-e568-457b-b2ce-41dbabb11e36/Wzor_zapytania_ofertowego_31082018.pdf	225728	ba630097b331722853ea1e97183738c13c050ebf84c0f0f54234c24ee13d88ff	application/pdf	L1	f	\N	\N	\N	\N	2026-01-09 11:24:03.054
5836ed3e-df1b-41a8-8ee1-a6330d0866e6	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/5836ed3e-df1b-41a8-8ee1-a6330d0866e6/Wzor_zapytania_ofertowego_31082018.pdf	225728	ba630097b331722853ea1e97183738c13c050ebf84c0f0f54234c24ee13d88ff	application/pdf	L2	t	AES-256-GCM	master-v1	0nKAb3JwABwOEezF	A8r9sUVkWaXTIFiBITjs+g==	2026-01-09 11:28:33.705
eccdb471-212a-4dd8-8b45-fbb2e897afba	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/eccdb471-212a-4dd8-8b45-fbb2e897afba/quantum.png	42676	3202eaaaab76f9e53133bf692fe95e51daa3d8e153d3e4acd86183b80cea4a03	image/png	L2	t	AES-256-GCM	master-v1	k+fJzBbhs5e1/axn	3AeR7iomT1tyloS0kPvX4A==	2026-01-09 11:29:47.778
64890f69-bd33-4b9d-aa60-ea77efd21865	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/64890f69-bd33-4b9d-aa60-ea77efd21865/Adv01.JPEG	1169162	af0ba070c9a2e90e83099a1ebbe48aa792f139f367e62a991989ecbb0105dbb9	image/jpeg	L2	t	AES-256-GCM	master-v1	qK3GPgxoppu9ld/C	hHbEGFriC5Q8liQi6psviQ==	2026-01-09 11:30:27.446
7ad147ca-4584-464e-a84a-d420cdddd7d0	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/7ad147ca-4584-464e-a84a-d420cdddd7d0/Wzor_zapytania_ofertowego_31082018__1_.pdf	225728	ba630097b331722853ea1e97183738c13c050ebf84c0f0f54234c24ee13d88ff	application/pdf	L1	f	\N	\N	\N	\N	2026-01-09 11:30:41.771
b17f8104-3602-4ae5-ba66-b80668fa7a96	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/b17f8104-3602-4ae5-ba66-b80668fa7a96/Wzor_zapytania_ofertowego_31082018.pdf	225728	ba630097b331722853ea1e97183738c13c050ebf84c0f0f54234c24ee13d88ff	application/pdf	L1	f	\N	\N	\N	\N	2026-01-09 12:37:09.004
0c10ee21-2d34-47ed-ba3e-98f292a3254c	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/0c10ee21-2d34-47ed-ba3e-98f292a3254c/Phase1_MVP-Spec__1_.md	31283	2340628e58e9cd401bce7b77ed2e6dfafcd2b0aaec910dcfb9d3d3bb98852ce5	application/octet-stream	L2	t	AES-256-GCM	master-v1	JSjLoWjVj777Pa8C	dBueYTJT/1h7PJveVB4P0Q==	2026-01-09 12:37:59.98
d04d65df-4f8a-42be-bb7d-5019bf270bc6	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/d04d65df-4f8a-42be-bb7d-5019bf270bc6/Phase1_MVP-Spec.md	31283	2340628e58e9cd401bce7b77ed2e6dfafcd2b0aaec910dcfb9d3d3bb98852ce5	application/octet-stream	L2	t	AES-256-GCM	master-v1	9c+8kKtuBjMM7AIM	fb6RcuSvA5UhF+47R/S4FQ==	2026-01-09 12:40:16.984
e75020f7-f8a8-4c89-8412-6f6892e14e72	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/e75020f7-f8a8-4c89-8412-6f6892e14e72/Phase1_MVP-Spec.md	31283	2340628e58e9cd401bce7b77ed2e6dfafcd2b0aaec910dcfb9d3d3bb98852ce5	application/octet-stream	L2	t	AES-256-GCM	master-v1	JSSmKp32a+xvQFuI	B935FMSWta0CHZ+wjLBObQ==	2026-01-09 13:14:16.556
43ca167b-fd8a-4eaa-bbc4-b1021a989884	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/43ca167b-fd8a-4eaa-bbc4-b1021a989884/Phase1_MVP-Spec.md	31283	2340628e58e9cd401bce7b77ed2e6dfafcd2b0aaec910dcfb9d3d3bb98852ce5	application/octet-stream	L2	t	AES-256-GCM	master-v1	ELH42xxg7Zm5W0fR	AsfuxlXuWBuc3E2h5p8Lfg==	2026-01-09 13:39:01.349
f01fdb8d-1821-4175-b8bb-e3da609acf05	cmk12kr4u000do1hxva29zgyd	local	cmk12kr4u000do1hxva29zgyd/f01fdb8d-1821-4175-b8bb-e3da609acf05/Phase1_MVP-Spec__1_.md	31283	2340628e58e9cd401bce7b77ed2e6dfafcd2b0aaec910dcfb9d3d3bb98852ce5	application/octet-stream	L1	f	\N	\N	\N	\N	2026-01-09 13:39:07.27
\.


--
-- Data for Name: Event; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Event" (id, "schemaVersion", type, "occurredAt", "recordedAt", "orgId", "actorUserId", "actorOrgId", "subjectType", "subjectId", "lifecycleStep", "pipelineStage", channel, "correlationId", payload) FROM stdin;
01KCW322DF84P22Q3CGW3GA29T	1	USER_SIGNED_UP	2025-12-19 19:58:16.494	2025-12-19 19:58:16.495	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW322DE2NR8R14VJRQ4RFC5	{"role": "Owner", "email": "info1@staadit.com", "orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdakp0p0005ut2uz4saqcrf", "payloadVersion": 1}
01KCW32H23AE8XH2MK87W8ZK82	1	USER_LOGGED_OUT	2025-12-19 19:58:31.49	2025-12-19 19:58:31.491	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW32H22S91HDZZTJQ84G8EZ	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdakp0p0005ut2uz4saqcrf", "payloadVersion": 1}
01KCW333YN1N9EH7CGWS6KC445	1	USER_LOGGED_IN	2025-12-19 19:58:50.837	2025-12-19 19:58:50.838	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW333YNYE7A0XFYRVSF64H9	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdalfiq0008ut2u50saciqk", "payloadVersion": 1}
01KCW33BG9KMDR0MKJ4X2VRGCW	1	USER_LOGGED_OUT	2025-12-19 19:58:58.569	2025-12-19 19:58:58.569	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW33BG9RTNRN6AV7159DBY0	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdalfiq0008ut2u50saciqk", "payloadVersion": 1}
01KCXCWPE6THSKE0BT0YVMXRGG	1	USER_LOGGED_IN	2025-12-20 08:09:20.582	2025-12-20 08:09:20.583	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCXCWPE6GMS4DXR4FR14894V	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmje0ourm000but2usyvwb2tw", "payloadVersion": 1}
01KCXCX7HAJMH1RMK2G8TS6JV0	1	USER_LOGGED_OUT	2025-12-20 08:09:38.089	2025-12-20 08:09:38.09	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCXCX7H93JEADJYDXS4QBEV8	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmje0ourm000but2usyvwb2tw", "payloadVersion": 1}
01KCXCXQ99DK0X205PVDWVGFW2	1	USER_SIGNED_UP	2025-12-20 08:09:54.217	2025-12-20 08:09:54.217	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXCXQ99EGVTD8PWW83GX75M	{"role": "Owner", "email": "info2@staadit.com", "orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0pkpz000hut2u9qbj5swy", "payloadVersion": 1}
01KCXD07PWVXAEBTQJ9ABPGN36	1	USER_LOGGED_OUT	2025-12-20 08:11:16.572	2025-12-20 08:11:16.572	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXD07PWP59TZC3V1F4R6DPD	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0pkpz000hut2u9qbj5swy", "payloadVersion": 1}
01KCXD6A60GEA8S5KK4FDGD0CF	1	USER_LOGGED_IN	2025-12-20 08:14:35.711	2025-12-20 08:14:35.712	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXD6A5ZCVATDQNA1XV1Y6RK	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0vlx7000kut2umcar3fvt", "payloadVersion": 1}
01KCXD6JGTMQFNJKQT49SWJ5BB	1	USER_LOGGED_OUT	2025-12-20 08:14:44.25	2025-12-20 08:14:44.25	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXD6JGT8PE45ETWP2SPS834	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0vlx7000kut2umcar3fvt", "payloadVersion": 1}
01KCXD79H8QB3TV99AQ5PJVSHG	1	USER_LOGGED_IN	2025-12-20 08:15:07.816	2025-12-20 08:15:07.816	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXD79H84C6FJ2QMX9QDC6TC	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0wap1000rut2ut8mdyltc", "payloadVersion": 1}
01KCXE2TVRSA6HYT702W2GEQCN	1	USER_LOGGED_OUT	2025-12-20 08:30:10.295	2025-12-20 08:30:10.296	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXE2TVQ6J5MBDH7WSE29744	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje0wap1000rut2ut8mdyltc", "payloadVersion": 1}
01KCXE2XPKEF566813T3BMWTZB	1	USER_LOGGED_IN	2025-12-20 08:30:13.202	2025-12-20 08:30:13.203	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXE2XPJW8NSNVX6ZGSRGKFE	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje1fpal0002tvgv5d0v0jq4", "payloadVersion": 1}
01KCXE35M7EXN7RCAQQR586ACG	1	USER_LOGGED_OUT	2025-12-20 08:30:21.319	2025-12-20 08:30:21.319	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXE35M7WGCSDMDH2XQ8C8DC	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje1fpal0002tvgv5d0v0jq4", "payloadVersion": 1}
01KCXEPCN4VTQVJG0TVM4T26X3	1	USER_LOGGED_IN	2025-12-20 08:40:51.108	2025-12-20 08:40:51.108	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCXEPCN43ZCZ21BC34CKSPMJ	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje1tdi80005tvgvyduak82j", "payloadVersion": 1}
01KCY9DDMBKCZXN0F4SC3FBC79	1	USER_LOGGED_OUT	2025-12-20 16:27:48.746	2025-12-20 16:27:48.748	cmje0pkpu000dut2u1z41ciku	cmje0pkpw000fut2uqq8am6xm	\N	USER	cmje0pkpw000fut2uqq8am6xm	CLARIFY	NEW	api	01KCY9DDMBV0Y4MTNJBDPYH1RN	{"orgId": "cmje0pkpu000dut2u1z41ciku", "userId": "cmje0pkpw000fut2uqq8am6xm", "sessionId": "cmje1tdi80005tvgvyduak82j", "payloadVersion": 1}
01KCY9DJ1VGA1HZ58DW0TY13SE	1	USER_LOGGED_IN	2025-12-20 16:27:53.275	2025-12-20 16:27:53.276	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCY9DJ1VRWD7EX2VS2SVYY4H	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjeihzjs0002g1h76qvc4v6y", "payloadVersion": 1}
01KCY9DKWARW1Z280E86SJXNF5	1	USER_LOGGED_OUT	2025-12-20 16:27:55.146	2025-12-20 16:27:55.146	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCY9DKWAE9FPC71E8YAGPV3E	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjeihzjs0002g1h76qvc4v6y", "payloadVersion": 1}
01KCY9T8JJ35WWG6RKF4DWMS82	1	USER_LOGGED_IN	2025-12-20 16:34:49.553	2025-12-20 16:34:49.554	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCY9T8JH3Y97ESB2T01WD734	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjeiqwr10002o1hxa6cnazc3", "payloadVersion": 1}
01KCY9TAF29WHFD2XGZM0JTKJX	1	USER_LOGGED_OUT	2025-12-20 16:34:51.489	2025-12-20 16:34:51.49	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCY9TAF2V23YQ18FYWJRHGJW	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjeiqwr10002o1hxa6cnazc3", "payloadVersion": 1}
01KCYAQ2X8GHEGQT1VYWCVJ9FP	1	USER_LOGGED_IN	2025-12-20 16:50:34.024	2025-12-20 16:50:34.024	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCYAQ2X8MRHER2B9ED3DJY9D	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjejb5ic0005o1hxkowop4vc", "payloadVersion": 1}
01KCYAQ4DFPRJA58EPVJFJGCE6	1	USER_LOGGED_OUT	2025-12-20 16:50:35.567	2025-12-20 16:50:35.568	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCYAQ4DFSBKRXYZ2785FX3FT	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjejb5ic0005o1hxkowop4vc", "payloadVersion": 1}
01KCYAQEMZT4ZB38G954R22NPA	1	USER_SIGNED_UP	2025-12-20 16:50:46.046	2025-12-20 16:50:46.047	cmjejbes70007o1hxngxzzzw7	cmjejbesa0009o1hxza9o6wpx	\N	USER	cmjejbesa0009o1hxza9o6wpx	CLARIFY	NEW	api	01KCYAQEMYRJEDQ11DAWJ2WR1G	{"role": "Owner", "email": "info3@staadit.com", "orgId": "cmjejbes70007o1hxngxzzzw7", "userId": "cmjejbesa0009o1hxza9o6wpx", "sessionId": "cmjejbesc000bo1hx5jfbo3ea", "payloadVersion": 1}
01KCYAQHA312TAHSQM88YAMH0D	1	USER_LOGGED_OUT	2025-12-20 16:50:48.771	2025-12-20 16:50:48.771	cmjejbes70007o1hxngxzzzw7	cmjejbesa0009o1hxza9o6wpx	\N	USER	cmjejbesa0009o1hxza9o6wpx	CLARIFY	NEW	api	01KCYAQHA3H50CA88SMPREQ76T	{"orgId": "cmjejbes70007o1hxngxzzzw7", "userId": "cmjejbesa0009o1hxza9o6wpx", "sessionId": "cmjejbesc000bo1hx5jfbo3ea", "payloadVersion": 1}
01KE6Y6V38MHS03WF25107ACY4	1	USER_SIGNED_UP	2026-01-05 11:20:50.536	2026-01-05 11:20:50.537	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE6Y6V38P4W2R2DMYXNTSFB7	{"role": "Owner", "email": "test01@enabion.com", "orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk12kr50000ho1hxukaj9r7i", "payloadVersion": 1}
01KE6YMXWAG2TH47G1HHDCCYJK	1	USER_LOGGED_OUT	2026-01-05 11:28:32.138	2026-01-05 11:28:32.138	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE6YMXWA41Q84PDQRA9RPRF0	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk12kr50000ho1hxukaj9r7i", "payloadVersion": 1}
01KE6YN0X38351YC5Q7R0V9EWW	1	USER_LOGGED_IN	2026-01-05 11:28:35.234	2026-01-05 11:28:35.235	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE6YN0X206ENMBYN3QV0MXAK	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk12upp9000ko1hxepfys1ze", "payloadVersion": 1}
01KE6YN31PPABSE921QCA2HXGB	1	USER_LOGGED_OUT	2026-01-05 11:28:37.43	2026-01-05 11:28:37.43	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE6YN31P8FV3YV9YRHE15GK4	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk12upp9000ko1hxepfys1ze", "payloadVersion": 1}
01KE709CK9G9XJ89G5QXMM204W	1	USER_PASSWORD_RESET_REQUESTED	2026-01-05 11:57:11.145	2026-01-05 11:57:11.145	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE709CJWH7RK63ZMC4NG09BR	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk13vhpg000213n32bejppkt", "payloadVersion": 1}
01KE709CQFQSTPV470QKB4S7YE	1	EMAIL_FAILED	2026-01-05 11:57:11.279	2026-01-05 11:57:11.279	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE709CJWH7RK63ZMC4NG09BR	{"errorCode": "esocket", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk13vhpg000213n32bejppkt", "payloadVersion": 1}
01KE70MSSBEJBK9D2X072V299Y	1	USER_PASSWORD_RESET_REQUESTED	2026-01-05 12:03:25.099	2026-01-05 12:03:25.1	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE70MSS30P8MS0W2970QJAWA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk143i94000513n3w2do6ecr", "payloadVersion": 1}
01KE70MSVB1C07KEEADGPXTN11	1	EMAIL_FAILED	2026-01-05 12:03:25.163	2026-01-05 12:03:25.163	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE70MSS30P8MS0W2970QJAWA	{"errorCode": "esocket", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk143i94000513n3w2do6ecr", "payloadVersion": 1}
01KE72Q0VGB63ZQKWQDEZBZ5EB	1	USER_PASSWORD_RESET_REQUESTED	2026-01-05 12:39:35.024	2026-01-05 12:39:35.024	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE72Q0V3HEQF1G21H3MN096Y	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk15e0kq0002ya7ahsshryg5", "payloadVersion": 1}
01KE72Q13H454QYX5K91536WNY	1	EMAIL_SENT	2026-01-05 12:39:35.281	2026-01-05 12:39:35.282	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE72Q0V3HEQF1G21H3MN096Y	{"messageId": "<28ffe788-086b-0096-d7c8-f2c0e0037d61@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk15e0kq0002ya7ahsshryg5", "payloadVersion": 1}
01KE7384H00EY5K3VAF3MZ4WAG	1	USER_PASSWORD_RESET_REQUESTED	2026-01-05 12:48:55.84	2026-01-05 12:48:55.84	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE7384GPAYQ6DB3D984SH1D3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk15q1b00005ya7af25k5v22", "payloadVersion": 1}
01KE7384PBPD4Y1R2ZDSWR4DTP	1	EMAIL_SENT	2026-01-05 12:48:56.011	2026-01-05 12:48:56.012	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE7384GPAYQ6DB3D984SH1D3	{"messageId": "<c92bc974-b238-eb73-eca1-74f7fea6f22c@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk15q1b00005ya7af25k5v22", "payloadVersion": 1}
01KE788MMBS4NGA5CWR4QAW48C	1	USER_PASSWORD_RESET_REQUESTED	2026-01-05 14:16:35.211	2026-01-05 14:16:35.211	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE788MM23TZDT8MMWF8Y80ZN	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk18urgn0008ya7aephyu2jp", "payloadVersion": 1}
01KE788MSCXYJ174THJG2R1NQ7	1	EMAIL_SENT	2026-01-05 14:16:35.372	2026-01-05 14:16:35.372	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KE788MM23TZDT8MMWF8Y80ZN	{"messageId": "<dd87af4b-3979-06d4-930f-33b1fcc7ad9e@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk18urgn0008ya7aephyu2jp", "payloadVersion": 1}
01KEBS11GSTBJFRCR0PSTGMAEN	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 08:26:29.785	2026-01-07 08:26:29.785	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBS11GD4CKHNYVDA0K56PN6	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3r88wk000bya7av3fodj38", "payloadVersion": 1}
01KEBS11QHNMP1927GNRKK1DG2	1	EMAIL_SENT	2026-01-07 08:26:30.001	2026-01-07 08:26:30.001	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBS11GD4CKHNYVDA0K56PN6	{"messageId": "<6f33c0d5-3c8e-3294-0726-97e471e734c0@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk3r88wk000bya7av3fodj38", "payloadVersion": 1}
01KEBS3PXA5SNP55SXYYTVBXE6	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 08:27:57.226	2026-01-07 08:27:57.226	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBS3PX4K070TNSFXQC5J42W	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3ra4dj000eya7aou676wpg", "payloadVersion": 1}
01KEBS3Q0RDGCY4PNXKKGK67B4	1	EMAIL_SENT	2026-01-07 08:27:57.336	2026-01-07 08:27:57.336	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBS3PX4K070TNSFXQC5J42W	{"messageId": "<773580db-69eb-16ec-0d9a-c1405ebef553@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk3ra4dj000eya7aou676wpg", "payloadVersion": 1}
01KEBSPQXSQ4TA6KH1PF32KK36	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 08:38:20.857	2026-01-07 08:38:20.857	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBSPQXFWMQXJWAT0VJ1K73F	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3rnhkl000hya7aaxdi1t10", "payloadVersion": 1}
01KEBSPR33PHYAJPP3PKPR4BTC	1	EMAIL_SENT	2026-01-07 08:38:21.027	2026-01-07 08:38:21.027	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBSPQXFWMQXJWAT0VJ1K73F	{"messageId": "<d74b8cb9-68af-40a5-9a82-f688fef2f86b@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk3rnhkl000hya7aaxdi1t10", "payloadVersion": 1}
01KEBSY5WZEGWQN3QMARXWX0N4	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 08:42:24.543	2026-01-07 08:42:24.544	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBSY5WSRVSV7VNVSFSH0SH8	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3rsplo000kya7a6zutneko", "payloadVersion": 1}
01KEBSY61FJC0829SGKER6EQ5R	1	EMAIL_SENT	2026-01-07 08:42:24.687	2026-01-07 08:42:24.687	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEBSY5WSRVSV7VNVSFSH0SH8	{"messageId": "<ebf25292-05ea-1278-a391-99ff2b071410@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk3rsplo000kya7a6zutneko", "payloadVersion": 1}
01KEC6SKCEHT44RQ35C6961KGY	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 12:27:05.998	2026-01-07 12:27:05.999	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC6SKC386MDCCGTGMTCTSZE	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3ztnyi000215kosdnx7uui", "payloadVersion": 1}
01KEC6SKKF65WD2PPHR00FQJS4	1	EMAIL_SENT	2026-01-07 12:27:06.223	2026-01-07 12:27:06.223	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC6SKC386MDCCGTGMTCTSZE	{"messageId": "<23051ede-d946-b0b4-c5f0-89f1c5f890e0@staadit.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk3ztnyi000215kosdnx7uui", "payloadVersion": 1}
01KEC6YH07XY4W30VEJA1WXCN2	1	USER_PASSWORD_RESET_COMPLETED	2026-01-07 12:29:47.398	2026-01-07 12:29:47.399	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC6YH06W8QAARHV2VCH8NH5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk3ztnyi000215kosdnx7uui", "payloadVersion": 1}
01KEC6YZQ3XMV4ASKNF6289K1Z	1	USER_LOGGED_IN	2026-01-07 12:30:02.467	2026-01-07 12:30:02.467	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC6YZQ336D199QSNPGC7EY5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk3zxg3z000615kox8o064g4", "payloadVersion": 1}
01KEC733E83J1DKPRG3NXAAB65	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 12:32:17.352	2026-01-07 12:32:17.352	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC733DVF8G24YXW95GTJWP6	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk400c770002kr4xvoalh8i3", "payloadVersion": 1}
01KEC733NZ4A1W53N31CK19BS7	1	EMAIL_SENT	2026-01-07 12:32:17.599	2026-01-07 12:32:17.6	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC733DVF8G24YXW95GTJWP6	{"messageId": "<b719c7ff-298c-4f87-0402-debacfaf7fb8@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk400c770002kr4xvoalh8i3", "payloadVersion": 1}
01KEC9QPE28SDP7JG7PH9D9T2P	1	USER_LOGGED_OUT	2026-01-07 13:18:29.313	2026-01-07 13:18:29.314	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC9QPE1WMFXKH1R9ZCGVTEC	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk3zxg3z000615kox8o064g4", "payloadVersion": 1}
01KEC9R2C344H7R93217X1MXWW	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 13:18:41.539	2026-01-07 13:18:41.539	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC9R2BQZZ0SV38EG3EPVKBH	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk41o0hr0002i0v0dn8en4kf", "payloadVersion": 1}
01KEC9R2KR5GMAJKWH0E9TSQVH	1	EMAIL_SENT	2026-01-07 13:18:41.784	2026-01-07 13:18:41.784	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC9R2BQZZ0SV38EG3EPVKBH	{"messageId": "<4b2e3e31-ddb1-7bc1-b05a-47de94a9eda0@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk41o0hr0002i0v0dn8en4kf", "payloadVersion": 1}
01KEC9S70YKXR7J81XPMDWDJ49	1	USER_PASSWORD_RESET_COMPLETED	2026-01-07 13:19:19.07	2026-01-07 13:19:19.07	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC9S70YNQZ14030CYRQW0W9	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk41o0hr0002i0v0dn8en4kf", "payloadVersion": 1}
01KEC9SG5V4W2DK9WSWSPH97QY	1	USER_LOGGED_IN	2026-01-07 13:19:28.442	2026-01-07 13:19:28.443	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEC9SG5TYY8GAX7CTR4MT9TT	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk41p0on0006i0v0f9yumxui", "payloadVersion": 1}
01KECB8KPGB7G79HDHGWZX25Y3	1	USER_LOGGED_OUT	2026-01-07 13:45:12.143	2026-01-07 13:45:12.144	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECB8KPFBNTQFG693T1T0C5S	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk41p0on0006i0v0f9yumxui", "payloadVersion": 1}
01KECH3WD9F7CKTVN4DCP19Z5X	1	USER_LOGGED_IN	2026-01-07 15:27:28.681	2026-01-07 15:27:28.681	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECH3WD994X6B2T3ZZVTGF11	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk469msl0002t8cit8rq2pux", "payloadVersion": 1}
01KESGDZ954FYJS8ZY3XPYHWSS	1	INTENT_VIEWED	2026-01-12 16:25:38.341	2026-01-12 16:25:38.341	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5jhwcq0006bdrsvh8hnxme	CLARIFY	CLARIFY	ui	01KESGDZ944PVZ95M6ER06TVXV	{"intentId": "cmk5jhwcq0006bdrsvh8hnxme", "viewContext": "owner", "payloadVersion": 1}
01KECHA5CHE7Q2M51X4WZJB6G9	1	USER_LOGGED_OUT	2026-01-07 15:30:54.481	2026-01-07 15:30:54.481	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECHA5CHH1YQQWJBQ4RQ121Q	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk469msl0002t8cit8rq2pux", "payloadVersion": 1}
01KECHAE2DCW902X3RJ0RZBH7Y	1	USER_LOGGED_IN	2026-01-07 15:31:03.373	2026-01-07 15:31:03.373	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECHAE2DG1NEGJA8YDFQF89S	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk46e8g90005t8ci4a1tj9xw", "payloadVersion": 1}
01KECHB922AFC2Y14R7JV19QAH	1	USER_LOGGED_IN	2026-01-07 15:31:31.01	2026-01-07 15:31:31.01	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECHB922D31M4PVTNYJP07HF	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk46etry0008t8cia912fv9m", "payloadVersion": 1}
01KECK9TC45P3RDK02414ZEV9Y	1	ORG_PROFILE_UPDATED	2026-01-07 16:05:40.355	2026-01-07 16:05:40.356	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ORG	cmk12kr4u000do1hxva29zgyd	CLARIFY	NEW	ui	01KECK9TC3G4E5PG91S03WMQV2	{"orgId": "cmk12kr4u000do1hxva29zgyd", "changedFields": ["name", "slug"], "payloadVersion": 1}
01KECKZZ785JB9FRQKTBWXXF90	1	USER_PASSWORD_RESET_REQUESTED	2026-01-07 16:17:46.216	2026-01-07 16:17:46.216	cmk12kr4u000do1hxva29zgyd	cmk482b4p0001bmbck6q90zvv	\N	USER	cmk482b4p0001bmbck6q90zvv	CLARIFY	NEW	api	01KECKZZ6Y7HCT8YV1XBFGN5GA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk482b4p0001bmbck6q90zvv", "resetTokenId": "cmk482b510004bmbc6a4l42az", "payloadVersion": 1}
01KECKZZF4TMSHC1PFJ1A393B2	1	EMAIL_SENT	2026-01-07 16:17:46.468	2026-01-07 16:17:46.469	cmk12kr4u000do1hxva29zgyd	cmk482b4p0001bmbck6q90zvv	\N	USER	cmk482b4p0001bmbck6q90zvv	CLARIFY	NEW	api	01KECKZZ6Y7HCT8YV1XBFGN5GA	{"messageId": "<4fafc15d-ad8a-a318-aeb7-4d060ce84ce0@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk482b510004bmbc6a4l42az", "payloadVersion": 1}
01KECM06J9JDXJEP7EF7NYVP0D	1	ORG_MEMBER_ROLE_CHANGED	2026-01-07 16:17:53.736	2026-01-07 16:17:53.737	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	USER	cmk482b4p0001bmbck6q90zvv	CLARIFY	NEW	ui	01KECM06J8512RDV2K768MZVR9	{"toRole": "BD_AM", "fromRole": "Viewer", "targetUserId": "cmk482b4p0001bmbck6q90zvv", "payloadVersion": 1}
01KECM08KJQ3WHJVD05WV9FDSN	1	ORG_MEMBER_ROLE_CHANGED	2026-01-07 16:17:55.826	2026-01-07 16:17:55.826	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	USER	cmk482b4p0001bmbck6q90zvv	CLARIFY	NEW	ui	01KECM08KJGR3Y6C03D69PGNX2	{"toRole": "Viewer", "fromRole": "BD_AM", "targetUserId": "cmk482b4p0001bmbck6q90zvv", "payloadVersion": 1}
01KECMKJ4651AACR38JKGY1JXP	1	USER_LOGGED_OUT	2026-01-07 16:28:28.165	2026-01-07 16:28:28.166	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KECMKJ457QRPK7X8Z0C385JC	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk46e8g90005t8ci4a1tj9xw", "payloadVersion": 1}
01KECMMHRVJY6PSTCEGC7PNA3X	1	USER_SIGNED_UP	2026-01-07 16:29:00.571	2026-01-07 16:29:00.572	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KECMMHRVDM6H8ZD704VA16ND	{"role": "Owner", "email": "admin@enabion.com", "orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk48grh3000abmbc9dwdqdp1", "payloadVersion": 1}
01KECMN6FVNPMAJX6XNWGQSD6T	1	USER_LOGGED_OUT	2026-01-07 16:29:21.787	2026-01-07 16:29:21.787	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KECMN6FVA2Y68SE08Y5XP0BV	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk48grh3000abmbc9dwdqdp1", "payloadVersion": 1}
01KECPY3Z7QYDXX54Z1VMBPEF5	1	USER_LOGGED_IN	2026-01-07 17:09:11.27	2026-01-07 17:09:11.271	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KECPY3Z7XA6XNNJD57Q3CSD3	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk49wfky000210ufpmjytmgm", "payloadVersion": 1}
01KECPYAGMFP4WKVZCBA3Y7ZF1	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:09:17.971	2026-01-07 17:09:17.972	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECPYAGK91CYAB2PF10MJ86Y	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECPYY59RKJQ7V4RTK49FK3R	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:09:38.089	2026-01-07 17:09:38.089	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECPYY59HCFYH439HR40QNC0	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECPZXQSKD91JZRD0EP0YEM4	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:10:10.425	2026-01-07 17:10:10.425	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECPZXQSQB47JPZA143YYPR5	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ05CTG91Q4F2Q9WH96KCH	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:10:18.265	2026-01-07 17:10:18.266	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ05CSN68B8J4EQEY8B90D	{"query": {"limit": 50, "orgId": "admin"}, "action": "EVENTS_QUERY", "targetType": "EVENTS", "resultCount": 0, "payloadVersion": 1}
01KECQ0JD2MFDWR3Y2YQHY33G2	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:10:31.586	2026-01-07 17:10:31.586	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ0JD2WFR4Z1M2BE0SMXD0	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ17XXMQGM5V98FQKPSK7J	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:10:53.628	2026-01-07 17:10:53.629	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ17XW140YZYG5CTZCNBDW	{"query": {"email": "test01"}, "action": "USER_SEARCH", "targetType": "USER", "resultCount": 0, "payloadVersion": 1}
01KECQ19NF3QVVDPAV4KRG9AZ3	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:10:55.407	2026-01-07 17:10:55.407	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ19NF8MPF9YPX2ZARNM08	{"query": {"email": "test01"}, "action": "USER_SEARCH", "targetType": "USER", "resultCount": 0, "payloadVersion": 1}
01KECQ3RVD4GKS68D5JPHTMEGG	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:16.493	2026-01-07 17:12:16.493	cmjejbes70007o1hxngxzzzw7	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3RVD4SQJ0MYZMKC1XSRN	{"action": "TENANT_VIEW", "targetId": "cmjejbes70007o1hxngxzzzw7", "targetType": "TENANT", "targetOrgId": "cmjejbes70007o1hxngxzzzw7", "payloadVersion": 1}
01KECQ1FZAWTSV1ARXS4JGMKDQ	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:01.866	2026-01-07 17:11:01.867	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ1FZA96JGEZZD6BJYT1HN	{"query": {"email": "test01@enabion.com"}, "action": "USER_SEARCH", "targetId": "cmk12kr4x000fo1hxdcjik7rt", "targetType": "USER", "resultCount": 1, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "targetUserId": "cmk12kr4x000fo1hxdcjik7rt", "payloadVersion": 1}
01KECQ1QNXN6ZTN70ACY8C6B6B	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:09.757	2026-01-07 17:11:09.757	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ1QNXQ78DA83HVYVVZRT9	{"query": {"email": "test02@enabion.com"}, "action": "USER_SEARCH", "targetId": "cmk482b4p0001bmbck6q90zvv", "targetType": "USER", "resultCount": 1, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "targetUserId": "cmk482b4p0001bmbck6q90zvv", "payloadVersion": 1}
01KECQ204CDKR0BME175CD8ZY8	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:18.412	2026-01-07 17:11:18.412	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ204CV2PHSEVRSZ8WX5DE	{"action": "USER_VIEW", "targetId": "cmk482b4p0001bmbck6q90zvv", "targetType": "USER", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "targetUserId": "cmk482b4p0001bmbck6q90zvv", "payloadVersion": 1}
01KECQ2DKEX9HZRYKAXN65D41T	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:32.205	2026-01-07 17:11:32.206	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2DKDTXQEACH6XASKBCGG	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ2F93EHHH80WJK3PT6245	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:33.923	2026-01-07 17:11:33.923	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2F93MD73P17SH5CFNRQQ	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ2F9QYN3Y9XHP5MXVXC5M	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:33.943	2026-01-07 17:11:33.943	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2F9QA7AH2J1J11X1MDVG	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ2KG9F3YF4PGPXPNTAEM7	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:38.249	2026-01-07 17:11:38.249	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2KG9YZZSDQXT5702976Q	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ2MJZD30W8YBB6YVZ54TD	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:39.358	2026-01-07 17:11:39.359	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2MJYZMYMM236ZAX95M44	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KECQ2MK0TH8SVYQDZJ2DEV7M	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:39.36	2026-01-07 17:11:39.36	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2MK031G4CMEEE4XS3XDJ	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KECQ2PD1MXC45XN16BCJA44N	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:41.217	2026-01-07 17:11:41.217	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2PD16KNXH4YK4P7DRBP5	{"action": "USER_VIEW", "targetId": "cmk48grgz0008bmbcp8s2vrap", "targetType": "USER", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "targetUserId": "cmk48grgz0008bmbcp8s2vrap", "payloadVersion": 1}
01KECQ2S2T9VQCDHW4PXW045ZH	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:43.962	2026-01-07 17:11:43.962	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2S2TSTZ79GCC3BSZA7NE	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ2TC6TZYKV2V8GW3CK53Q	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:45.286	2026-01-07 17:11:45.287	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2TC6TBR4BSJWP7KK3ME6	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KECQ2TCARBTH0KR9QERGG7QK	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:11:45.289	2026-01-07 17:11:45.29	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ2TC9NXJYS8Y29E2CXPZ7	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KECQ3DESBBV5T36SYCEK4QZZ	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:04.825	2026-01-07 17:12:04.826	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3DESVY6A166H34CKNK6F	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ3EG4H1RMBXH447PMECHP	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:05.892	2026-01-07 17:12:05.892	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3EG4K5XN8SAPPBF0JTR2	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ3EG5JQ5YNCSEB9NM0X04	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:05.893	2026-01-07 17:12:05.893	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3EG50TZ22R1DKVMZS9QC	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ3QKZATHTPS22ESAZAXV5	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:15.231	2026-01-07 17:12:15.232	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3QKZM555JDX0F6NVY6Z6	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEER7JJADXH67EH5M6W6MP2R	1	USER_LOGGED_OUT	2026-01-08 12:10:18.57	2026-01-08 12:10:18.57	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEER7JJAQBTTXXX3GD80EKGN	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5em84v0002h66lyo9xac54", "payloadVersion": 1}
01KECQ3RVHB0ABTRM36SKBER2G	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:16.497	2026-01-07 17:12:16.497	cmjejbes70007o1hxngxzzzw7	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ3RVHWMAMQTVETR6B96EE	{"action": "TENANT_USERS_LIST", "targetId": "cmjejbes70007o1hxngxzzzw7", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmjejbes70007o1hxngxzzzw7", "payloadVersion": 1}
01KECQ40XF68JXW8ZEW4MZZ1M1	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:24.751	2026-01-07 17:12:24.751	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ40XFB7N536A0DE9Q93SP	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ43TW1N6QD1BY1S4YD974	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:27.74	2026-01-07 17:12:27.74	cmje0pkpu000dut2u1z41ciku	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ43TWDXC44TE6KY0YV607	{"action": "TENANT_USERS_LIST", "targetId": "cmje0pkpu000dut2u1z41ciku", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmje0pkpu000dut2u1z41ciku", "payloadVersion": 1}
01KECQ4DPJ5GJA89A17TEWJNC5	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:37.842	2026-01-07 17:12:37.842	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ4DPJF90ZAE756D6YTM5A	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ43TX70M6HAM2XRQ2BMDK	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:27.741	2026-01-07 17:12:27.741	cmje0pkpu000dut2u1z41ciku	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ43TXE46676595Z2C92MK	{"action": "TENANT_VIEW", "targetId": "cmje0pkpu000dut2u1z41ciku", "targetType": "TENANT", "targetOrgId": "cmje0pkpu000dut2u1z41ciku", "payloadVersion": 1}
01KECQ47XZBXNRQTZFXM0MS6Y3	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:31.935	2026-01-07 17:12:31.935	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ47XZYVBDBZBRN0MM6G55	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ4933BESPM9FM14284GKB	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:33.122	2026-01-07 17:12:33.123	cmjdakp0f0001ut2uv0n881s3	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ4932R69YV796E9D27QJN	{"action": "TENANT_VIEW", "targetId": "cmjdakp0f0001ut2uv0n881s3", "targetType": "TENANT", "targetOrgId": "cmjdakp0f0001ut2uv0n881s3", "payloadVersion": 1}
01KECQ493K7B4J9QQYKVM83SFR	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:33.138	2026-01-07 17:12:33.139	cmjdakp0f0001ut2uv0n881s3	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ493JW1Y5T816V6GYFHFY	{"action": "TENANT_USERS_LIST", "targetId": "cmjdakp0f0001ut2uv0n881s3", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmjdakp0f0001ut2uv0n881s3", "payloadVersion": 1}
01KECQ4CN6YN4ZKXCAEVCQXATT	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:36.773	2026-01-07 17:12:36.774	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ4CN5D3NWWBXK8V4G3HX0	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ4DPHQXJ2G1WNB6VDM19G	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:12:37.841	2026-01-07 17:12:37.841	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ4DPH7XA5C68EERQ09FSE	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ9D28VDH1GNKAXWZN2CN2	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:15:21.032	2026-01-07 17:15:21.032	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ9D28RXWXAE4NJF0MB6A4	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KECQ9E2CS7F5XPA7JRN8DCJT	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:15:22.059	2026-01-07 17:15:22.06	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ9E2BQE9801F15R6NJ8TN	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQ9E31232REE8N7V83NRDT	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:15:22.08	2026-01-07 17:15:22.081	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQ9E30Z9FY2B7SAX9NMTN5	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KECQBXADQGWEJE8QPF46S7BJ	1	PLATFORM_ADMIN_AUDIT	2026-01-07 17:16:43.212	2026-01-07 17:16:43.213	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KECQBXAC3YX48YY0KFAWXCK6	{"action": "USER_VIEW", "targetId": "cmk482b4p0001bmbck6q90zvv", "targetType": "USER", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "targetUserId": "cmk482b4p0001bmbck6q90zvv", "payloadVersion": 1}
01KEEMPZ2Q5W6Z79E60CF76K19	1	USER_LOGGED_IN	2026-01-08 11:08:48.599	2026-01-08 11:08:48.599	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEMPZ2QGV6FTV7VJYPAX722	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5cgu36000510ufair0t79h", "payloadVersion": 1}
01KEEMQ5REQYRWB6HRDA255456	1	PLATFORM_ADMIN_AUDIT	2026-01-08 11:08:55.438	2026-01-08 11:08:55.438	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEEMQ5RE68GN2283K2B0CT3C	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEEMQR9K2RX333QMSFD95YPV	1	PLATFORM_ADMIN_AUDIT	2026-01-08 11:09:14.419	2026-01-08 11:09:14.419	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEEMQR9KS59B9QTFGJQQ1X42	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEEQ9J4WNWAV865HAET3YQHH	1	USER_LOGGED_OUT	2026-01-08 11:53:55.1	2026-01-08 11:53:55.1	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEQ9J4WEYBRX0WW61M9N8AQ	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5cgu36000510ufair0t79h", "payloadVersion": 1}
01KEEQ9MCT8M0DZWWE6FS8ZKFB	1	USER_LOGGED_IN	2026-01-08 11:53:57.402	2026-01-08 11:53:57.402	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEQ9MCTZBHRYA4A2Y9TYKNR	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5e2w7q000810ufvs1whblh", "payloadVersion": 1}
01KEEQ9X3766SJR69ZTE98KVYK	1	PLATFORM_ADMIN_AUDIT	2026-01-08 11:54:06.311	2026-01-08 11:54:06.311	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEEQ9X376WER61CSG6WWQN65	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEER3ST0E6Q6067K4YTVC8PR	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:08:14.911	2026-01-08 12:08:14.913	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEER3ST07RQA9T7CKCV1J2B0	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEER4ZJP8S9DBJZVZ3FB2RGY	1	USER_LOGGED_OUT	2026-01-08 12:08:53.589	2026-01-08 12:08:53.59	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEER4ZJNJZA24YHDP9PQGDWT	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5e2w7q000810ufvs1whblh", "payloadVersion": 1}
01KEER555KSN4KMYYBPKCGDWA4	1	USER_LOGGED_IN	2026-01-08 12:08:59.315	2026-01-08 12:08:59.315	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEER555KGQP9H0N4KNBXTG07	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5em84v0002h66lyo9xac54", "payloadVersion": 1}
01KEER7N2ZZMDPZFHM86A00MFK	1	USER_LOGGED_IN	2026-01-08 12:10:21.151	2026-01-08 12:10:21.151	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEER7N2ZV35QW75W8GS95PV3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5enza40005h66lh94scp4y", "payloadVersion": 1}
01KEER96PS2NC3ZV9P9NE92XS3	1	USER_LOGGED_OUT	2026-01-08 12:11:11.961	2026-01-08 12:11:11.961	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEER96PST5CBC8K0XGBGY9VE	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5enza40005h66lh94scp4y", "payloadVersion": 1}
01KEERA3M6MSTQEGKQF4EFZ10X	1	USER_LOGGED_IN	2026-01-08 12:11:41.574	2026-01-08 12:11:41.575	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEERA3M6E4ESCQDH3BG2VC7P	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5eppc20008h66lovk0zw5j", "payloadVersion": 1}
01KEERQX2RW8HMVWNVQHGNWX1M	1	USER_LOGGED_OUT	2026-01-08 12:19:13.624	2026-01-08 12:19:13.624	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEERQX2R0SVW7DSEHM9JNVPA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5eppc20008h66lovk0zw5j", "payloadVersion": 1}
01KEERQZ1DB3W4HXV4B4HJ2SVG	1	USER_LOGGED_IN	2026-01-08 12:19:15.629	2026-01-08 12:19:15.629	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEERQZ1DBTYTDX3D4TMGWGYK	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5ezfop000bh66lppwyol68", "payloadVersion": 1}
01KEESNHKGWG6VN3K5K30ET34C	1	USER_LOGGED_OUT	2026-01-08 12:35:24.911	2026-01-08 12:35:24.912	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEESNHKFBB8X4GWGTXGBZBVW	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5ezfop000bh66lppwyol68", "payloadVersion": 1}
01KEESNKRZDJ6ETDSANENJ6VZD	1	USER_LOGGED_IN	2026-01-08 12:35:27.135	2026-01-08 12:35:27.135	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEESNKRZMTSAVEY4102ZGGY3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5fk9aw00029x9sqe9w53g9", "payloadVersion": 1}
01KEESP7FN65NN3KNXQZHJFEPM	1	USER_LOGGED_OUT	2026-01-08 12:35:47.317	2026-01-08 12:35:47.317	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEESP7FN6W86W1F593KTVKNY	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5fk9aw00029x9sqe9w53g9", "payloadVersion": 1}
01KEESPB6DA7BZN95M9K4MQHK3	1	USER_LOGGED_IN	2026-01-08 12:35:51.117	2026-01-08 12:35:51.117	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEESPB6D4AA60C163ZYPDT9Y	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5fkrt300059x9s3dod0n47", "payloadVersion": 1}
01KEETFXDVD4B30EZT8TG4ZYKG	1	USER_LOGGED_OUT	2026-01-08 12:49:48.986	2026-01-08 12:49:48.987	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEETFXDTF80P7S6N6NVCVKNV	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5fkrt300059x9s3dod0n47", "payloadVersion": 1}
01KEETFZSWQT7F0NJFRWKP314M	1	USER_LOGGED_IN	2026-01-08 12:49:51.42	2026-01-08 12:49:51.421	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEETFZSWC39PYDV5G24QNX8M	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5g2s6u000210ytbbztu53x", "payloadVersion": 1}
01KEETG2TX9M523K8MBFAZM0AW	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:49:54.525	2026-01-08 12:49:54.526	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEETG2TXQDWAWW5PX7WZ7XNM	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEETGCBAPC24R2Y91F9NA1GN	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:50:04.266	2026-01-08 12:50:04.266	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEETGCBAJYRGF72HFHSRJ3FK	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEETGQT8CGTTZXR0GQBGC45J	1	USER_LOGGED_OUT	2026-01-08 12:50:16.008	2026-01-08 12:50:16.009	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEETGQT8MF70QQDPF2WGK0JS	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5g2s6u000210ytbbztu53x", "payloadVersion": 1}
01KEETGWGJQDN62J9J03G2F5CP	1	USER_LOGGED_IN	2026-01-08 12:50:20.818	2026-01-08 12:50:20.818	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEETGWGJHGJVYAWS9WAV949T	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5g3evh000510ytxdm5ju30", "payloadVersion": 1}
01KEETH12RZ289MYJZ3GHXQ2FV	1	USER_LOGGED_OUT	2026-01-08 12:50:25.496	2026-01-08 12:50:25.497	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEETH12R9PDPCGFVV1FP9CXQ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5g3evh000510ytxdm5ju30", "payloadVersion": 1}
01KEETH4NP1TJESVAEW2794JY4	1	USER_LOGGED_IN	2026-01-08 12:50:29.173	2026-01-08 12:50:29.174	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEETH4NN49E774VF7B3K6ZKE	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5g3lbl000810yt15ql6i2o", "payloadVersion": 1}
01KEETH7P8WDG1HAQ2Y6BY1G4R	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:50:32.264	2026-01-08 12:50:32.264	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEETH7P8X2DMFSZF00A9QGQN	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEETHGE0XKTN6AE243CG0Q4K	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:50:41.216	2026-01-08 12:50:41.216	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEETHGE0FMABQEN7PM8CYY4C	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEETHGEZ4Z3HJ0RH3FD06M15	1	PLATFORM_ADMIN_AUDIT	2026-01-08 12:50:41.247	2026-01-08 12:50:41.247	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEETHGEZ2X1VY6CJ3M4SJ3YJ	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEETHVXZY0YTJABGVK5MEMZ0	1	USER_LOGGED_OUT	2026-01-08 12:50:52.991	2026-01-08 12:50:52.991	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEETHVXZAC1XMSR1J7421W2H	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5g3lbl000810yt15ql6i2o", "payloadVersion": 1}
01KEEXBMQ5MCQMC9Y9NAKN4SJB	1	USER_LOGGED_IN	2026-01-08 13:39:54.724	2026-01-08 13:39:54.725	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEXBMQ43RGW8P8SKNQGWWD6	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5hv5jv000b10ytbdyu1ki8", "payloadVersion": 1}
01KEEXCXSBN783KVY5E2YVMPBD	1	USER_LOGGED_OUT	2026-01-08 13:40:36.778	2026-01-08 13:40:36.779	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEXCXSA0W9924XJN2WE1WMP	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5hv5jv000b10ytbdyu1ki8", "payloadVersion": 1}
01KEEXCZQX459ES9WW1GRATGHJ	1	USER_LOGGED_IN	2026-01-08 13:40:38.781	2026-01-08 13:40:38.781	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEXCZQXPM6EA4E2Q1VZQ8DK	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5hw3jt000e10yt4vt51e33", "payloadVersion": 1}
01KEEXE94B37K1M5G0NG34VXXB	1	USER_LOGGED_OUT	2026-01-08 13:41:21.162	2026-01-08 13:41:21.163	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEEXE94AXHN6G12J7DB0C32R	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk5hw3jt000e10yt4vt51e33", "payloadVersion": 1}
01KEEXEEYT2HKSDHB4G0AWQNE4	1	USER_LOGGED_IN	2026-01-08 13:41:27.13	2026-01-08 13:41:27.131	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEEXEEYT59VQFNBGMGM77MJM	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5hx4ut000h10ytxlbssx14", "payloadVersion": 1}
01KEEZPNKSHCT9NSTGE2Y10465	1	USER_LOGGED_OUT	2026-01-08 14:20:53.24	2026-01-08 14:20:53.241	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEEZPNKREQW16G6DF0AXTSMD	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5hx4ut000h10ytxlbssx14", "payloadVersion": 1}
01KEEZPQV908HYHK8KETZYZCHT	1	USER_LOGGED_IN	2026-01-08 14:20:55.528	2026-01-08 14:20:55.529	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEEZPQV8QZ0VS49PFSGV3V7Z	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5jbwbl0002bdrs3rx68h66", "payloadVersion": 1}
01KEEZTTH5Q7K7YZNFX57D06VB	1	INTENT_CREATED	2026-01-08 14:23:09.349	2026-01-08 14:23:09.349	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5jerkv0004bdrsfs3tf5hs	CLARIFY	NEW	ui	01KEEZTTH5P1Z30STY3KDQ774J	{"kpi": "1 car pwer week.", "goal": "Sell new car.", "risks": "no", "scope": "Only new cars", "title": "Sell new car.", "source": "manual", "context": "We have plenty of new cars and we need to sell it.", "intentId": "cmk5jerkv0004bdrsfs3tf5hs", "language": "EN", "deadlineAt": "2026-06-30T00:00:00.000Z", "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEEZZ98FM6E5VFYYBT8T6QZJ	1	INTENT_CREATED	2026-01-08 14:25:35.502	2026-01-08 14:25:35.503	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5jhwcq0006bdrsvh8hnxme	CLARIFY	NEW	ui	01KEEZZ98EQ4FTQMQ77H3CD8PD	{"kpi": "1000 eur / month", "goal": "Sell IT training", "risks": "in huge demant may strugle with trainers", "scope": "IT development trainings.", "title": "Sell IT training", "source": "manual", "context": "We have a portfolio of IT traininhg and can offer it to other companies.", "intentId": "cmk5jhwcq0006bdrsvh8hnxme", "language": "EN", "deadlineAt": "2026-12-30T00:00:00.000Z", "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEF2CJK7EYB143BHFN1TTRNZ	1	USER_LOGGED_OUT	2026-01-08 15:07:48.199	2026-01-08 15:07:48.199	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2CJK7QQ77B31JWAERH2MV	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5jbwbl0002bdrs3rx68h66", "payloadVersion": 1}
01KEF2CMTYFEFVZZRCBSXDK3B8	1	USER_LOGGED_IN	2026-01-08 15:07:50.494	2026-01-08 15:07:50.494	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2CMTY7Y9CXWDYT4NN2GAQ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l08d30009bdrscqqo00b9", "payloadVersion": 1}
01KEF2E1H99Q3KZ5CZ0A0KCR3P	1	USER_LOGGED_OUT	2026-01-08 15:08:36.264	2026-01-08 15:08:36.265	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2E1H8DQKW7RMHGVRRQAN5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l08d30009bdrscqqo00b9", "payloadVersion": 1}
01KEF2E6CD18KZQ611K2RYPNYA	1	USER_LOGGED_IN	2026-01-08 15:08:41.229	2026-01-08 15:08:41.229	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2E6CDNW2AKFYQKY80HG0C	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l1big000cbdrs69eubfa2", "payloadVersion": 1}
01KEF2SKWSD23K8EY1S50V9ACA	1	USER_LOGGED_OUT	2026-01-08 15:14:55.512	2026-01-08 15:14:55.513	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2SKWRVJ9Y5Z2RD5MEJ1YX	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l1big000cbdrs69eubfa2", "payloadVersion": 1}
01KEF2SPC96TSY4FVH3T4033J8	1	USER_LOGGED_IN	2026-01-08 15:14:58.057	2026-01-08 15:14:58.057	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF2SPC916D7G0CHYBB6SXNW	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l9e9x000fbdrsh05vepg4", "payloadVersion": 1}
01KEF4GRW60QWTCHW8AZSFW2TS	1	USER_LOGGED_OUT	2026-01-08 15:45:02.854	2026-01-08 15:45:02.854	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF4GRW6WHF43C29KKWG1TSC	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5l9e9x000fbdrsh05vepg4", "payloadVersion": 1}
01KEF4GV3M7BQ5S14NT8VJMYWV	1	USER_LOGGED_IN	2026-01-08 15:45:05.14	2026-01-08 15:45:05.14	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF4GV3M8C8BH9HYDH102FT2	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mc4mj000ibdrs149u8m0e", "payloadVersion": 1}
01KEF4W8ZBNF2DHN0W0ZYP4X99	1	USER_LOGGED_IN	2026-01-08 15:51:19.787	2026-01-08 15:51:19.787	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF4W8ZB05HM5F2RZTYCWNZG	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mk5pi000lbdrsoh4u8722", "payloadVersion": 1}
01KEF5BSDSF9NB2YF2ES730WAQ	1	USER_LOGGED_IN	2026-01-08 15:59:48.152	2026-01-08 15:59:48.153	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5BSDR4CZ5Z7G9RD20NHCS	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mv1yq000obdrs9tcnuzz3", "payloadVersion": 1}
01KEF5CQRYVTXEJ883PZMR63V2	1	USER_LOGGED_IN	2026-01-08 16:00:19.23	2026-01-08 16:00:19.231	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5CQRYXKPRTW34T71S07XJ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mvpxz000rbdrs6i5po5wz", "payloadVersion": 1}
01KEF5EDQWJ867X5ZXK8D9J94S	1	USER_LOGGED_IN	2026-01-08 16:01:14.492	2026-01-08 16:01:14.492	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5EDQW7AFZNN25HNR1XCP3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mwwl3000ubdrs0kuwp3tt", "payloadVersion": 1}
01KEF5F4D5VXHQMHQAWNV0ZHF4	1	USER_LOGGED_IN	2026-01-08 16:01:37.7	2026-01-08 16:01:37.701	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5F4D41G8RBYHK2NCMCN78	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mxehr000xbdrsib5u6lqf", "payloadVersion": 1}
01KEF5GJEJ96HJJP1K07V6N808	1	USER_LOGGED_IN	2026-01-08 16:02:24.849	2026-01-08 16:02:24.85	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5GJEHDT6B2JRK2BMYVDA1	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5myevh0010bdrsg1ewy7de", "payloadVersion": 1}
01KEF5RXJ9RSNCFNFMM29TE7M5	1	USER_LOGGED_IN	2026-01-08 16:06:58.377	2026-01-08 16:06:58.377	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5RXJ96ZR9H7NTHVGWZZH9	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5n49xf0013bdrsldnagcld", "payloadVersion": 1}
01KEF5SJHX2ZBNWGJRCWNPM394	1	USER_LOGGED_IN	2026-01-08 16:07:19.869	2026-01-08 16:07:19.869	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEF5SJHXT9N54H6529S6348H	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5n4qid0016bdrs07j3nfcu", "payloadVersion": 1}
01KEFFBH30XXRJ1Q6YBV6QRBZ0	1	USER_LOGGED_IN	2026-01-08 18:54:25.376	2026-01-08 18:54:25.376	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFBH30VCEEBFSW5J1V7DHJ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5t3m8p0019bdrsvmml8dyl", "payloadVersion": 1}
01KEFFFDNSQ7NFN96N7JSFDDJT	1	USER_LOGGED_IN	2026-01-08 18:56:32.953	2026-01-08 18:56:32.953	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFFDNSMSA3W99HZS6TZ73W	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5t6col001cbdrsj7swhztf", "payloadVersion": 1}
01KEFFQCB9YGR0Y188JYE84GZB	1	USER_LOGGED_IN	2026-01-08 19:00:53.736	2026-01-08 19:00:53.737	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFQCB8Q6Q497VGYDW9S8FS	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5tbxwd00021341akvvbg40", "payloadVersion": 1}
01KEFFSJDDE6WV13T9NPY1AJNK	1	USER_LOGGED_IN	2026-01-08 19:02:05.485	2026-01-08 19:02:05.486	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFSJDD48HWYFDX9SENER5Q	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5tdh9k00071341iavxyeut", "payloadVersion": 1}
01KEFFSJMV0A5NNAWGZYVSPSRD	1	INTENT_CREATED	2026-01-08 19:02:05.723	2026-01-08 19:02:05.723	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tdhg6000913412o3bqd4x	CLARIFY	NEW	ui	01KEFFSJMVPVC0ADSEET787YAE	{"title": "Test title", "source": "paste", "intentId": "cmk5tdhg6000913412o3bqd4x", "language": "EN", "sourceText": {"length": 10, "sha256": "95ba55c6ea6f04420f293d4a0fb0d28562e6aae18c1c8b05cd31ab7ed0c3c45a"}, "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEFFT87XRMZF63TSYKFXD3C1	1	USER_LOGGED_OUT	2026-01-08 19:02:27.837	2026-01-08 19:02:27.838	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFT87XHPMDHHC9JWY5FYH1	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5mc4mj000ibdrs149u8m0e", "payloadVersion": 1}
01KEFFTAHS3CJRN8N2GP74C6ZF	1	USER_LOGGED_IN	2026-01-08 19:02:30.201	2026-01-08 19:02:30.201	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFFTAHSF4FBGA7E6ZGBN0QE	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5te0c4000c1341951gp5ni", "payloadVersion": 1}
01KEFFTMGT0V64P8T7TW57N0KV	1	INTENT_CREATED	2026-01-08 19:02:40.41	2026-01-08 19:02:40.41	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5te87r000e1341tr7y1dat	CLARIFY	NEW	ui	01KEFFTMGTX9KJJ5R4PR1CY333	{"title": "Creating…", "source": "paste", "intentId": "cmk5te87r000e1341tr7y1dat", "language": "EN", "sourceText": {"length": 9, "sha256": "c79ed9492e3c17199ab50694e07f5525cc6d598a02531528b0eb5ed933cd5466"}, "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEFG1C5FYYCH2YVBPZGDBP1J	1	USER_LOGGED_IN	2026-01-08 19:06:21.231	2026-01-08 19:06:21.231	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFG1C5FB56HBQJSV3A1TFDZ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5tiylh000h1341k759b9ak", "payloadVersion": 1}
01KEFG1CH7T2WVZ5QT1BFD3FD7	1	INTENT_CREATED	2026-01-08 19:06:21.606	2026-01-08 19:06:21.607	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tiyvu000j1341uqwwes3f	CLARIFY	NEW	ui	01KEFG1CH6FH5P2WF6AFDDQNC3	{"title": "Smoke paste", "source": "paste", "intentId": "cmk5tiyvu000j1341uqwwes3f", "language": "EN", "sourceText": {"length": 18, "sha256": "1778bd5652ffd8cce22d6273040675e2a093e695ca5662c8d63498ecc488f515"}, "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEFGSHGSNVEH650VABF8DNRD	1	USER_LOGGED_IN	2026-01-08 19:19:33.144	2026-01-08 19:19:33.145	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEFGSHGR0NCZ9RH6P9JWNJTH	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk5tzxn5000m1341cg25lge8", "payloadVersion": 1}
01KEFGSHJRJYJ9RP7E538HR1M8	1	INTENT_CREATED	2026-01-08 19:19:33.207	2026-01-08 19:19:33.208	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	CLARIFY	NEW	ui	01KEFGSHJQKDCZHQJ5MKSYQNVB	{"title": "[SMOKE] Paste intent", "source": "paste", "intentId": "cmk5tzxoz000o1341jzo45i8m", "language": "EN", "sourceText": {"length": 29, "sha256": "d40b3acd936da11d958e23ef3994c743874f1238ddcfebd62be37a46570556f0"}, "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEGV35A63SMM8SSJ9G6NAXV6	1	USER_LOGGED_IN	2026-01-09 07:38:48.517	2026-01-09 07:38:48.518	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEGV35A572PKH8S8EXJEQ15H	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6kemgs000r134140cvgzis", "payloadVersion": 1}
01KEGZJKEFZPWF53G8KHY8HZ8P	1	USER_LOGGED_OUT	2026-01-09 08:57:08.815	2026-01-09 08:57:08.815	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEGZJKEFZVV7T0KDE0HX39QS	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6kemgs000r134140cvgzis", "payloadVersion": 1}
01KEGZJNVES97GYQMNZ9741AZQ	1	USER_LOGGED_IN	2026-01-09 08:57:11.278	2026-01-09 08:57:11.278	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEGZJNVEMECEENX1VN12690J	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6n7f55000u1341ji6dhf3k", "payloadVersion": 1}
01KEH3881K6X235ZJYWC6D3XNS	1	USER_LOGGED_OUT	2026-01-09 10:01:23.762	2026-01-09 10:01:23.763	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEH3881JM3ZTH8V4CTEPXF2W	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6n7f55000u1341ji6dhf3k", "payloadVersion": 1}
01KEH38C3VE2H2KXEMW5KG1EY6	1	USER_LOGGED_IN	2026-01-09 10:01:27.931	2026-01-09 10:01:27.932	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEH38C3VFZ1TM7A098SB6TW9	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk6pi2yd00021fdlkit62p0v", "payloadVersion": 1}
01KEH38EQT674JD266T62Q0XP9	1	PLATFORM_ADMIN_AUDIT	2026-01-09 10:01:30.618	2026-01-09 10:01:30.618	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEH38EQTRAGQ5T457NZC88Z3	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEH399CJ4Y1TN30RRHT6H3CH	1	PLATFORM_ADMIN_AUDIT	2026-01-09 10:01:57.906	2026-01-09 10:01:57.906	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEH399CJAZMENMTT3B4M5ZHM	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEH39R2SYZPZ4AQPZMM2QE0E	1	PLATFORM_ADMIN_AUDIT	2026-01-09 10:02:12.952	2026-01-09 10:02:12.953	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEH39R2RZ4MRX3R8WHDDJ63T	{"query": {"limit": 50, "orgId": "test01-tname"}, "action": "EVENTS_QUERY", "targetType": "EVENTS", "resultCount": 0, "payloadVersion": 1}
01KEH39WQ3PR74ARJW679FE8GB	1	PLATFORM_ADMIN_AUDIT	2026-01-09 10:02:17.699	2026-01-09 10:02:17.699	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEH39WQ372FAAFK3VECYFMRK	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEH3A4GY6H1EN1F509P5X8XX	1	PLATFORM_ADMIN_AUDIT	2026-01-09 10:02:25.694	2026-01-09 10:02:25.694	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEH3A4GY4BPSMBRCJ4DATG8S	{"query": {"limit": 50, "orgId": "cmk12kr4u000do1hxva29zgyd"}, "action": "EVENTS_QUERY", "targetType": "EVENTS", "resultCount": 50, "payloadVersion": 1}
01KEH3CJ12MN3350CWA303FVR7	1	PLATFORM_ADMIN_AUDIT	2026-01-09 10:03:45.058	2026-01-09 10:03:45.058	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEH3CJ12F0KT53XAMV36THT0	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEH3D5E7YP6RFFNPV692R1ZF	1	PLATFORM_ADMIN_AUDIT	2026-01-09 10:04:04.934	2026-01-09 10:04:04.935	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEH3D5E6BKDSF9AT6FYJBF4A	{"query": {"userId": "cmk12kr4u000do1hxva29zgyd"}, "action": "USER_SEARCH", "targetType": "USER", "resultCount": 0, "payloadVersion": 1}
01KEH3DEVR25Y55AQN7XJ4HH2X	1	PLATFORM_ADMIN_AUDIT	2026-01-09 10:04:14.584	2026-01-09 10:04:14.584	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEH3DEVR5H6C162JD1KQHG99	{"query": {"email": "test01@enabion.com"}, "action": "USER_SEARCH", "targetId": "cmk12kr4x000fo1hxdcjik7rt", "targetType": "USER", "resultCount": 1, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "targetUserId": "cmk12kr4x000fo1hxdcjik7rt", "payloadVersion": 1}
01KEH3DMAV4MKKT351B7A9H1C4	1	USER_LOGGED_OUT	2026-01-09 10:04:20.187	2026-01-09 10:04:20.187	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEH3DMAV8E6NWMAXB3QGS30A	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk6pi2yd00021fdlkit62p0v", "payloadVersion": 1}
01KEH3DR0PJNGKBPEF374F4WF5	1	USER_LOGGED_IN	2026-01-09 10:04:23.958	2026-01-09 10:04:23.958	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEH3DR0PTTKCZAC0D48F2JTZ	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk6plus000051fdl5g7gcl8a", "payloadVersion": 1}
01KEH3KYJ7SGC2QZ5W0GDP9E1B	1	INTENT_CREATED	2026-01-09 10:07:47.265	2026-01-09 10:07:47.271	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	cmjdakp0f0001ut2uv0n881s3	INTENT	cmk6pq7nm00071fdlp1zekwp7	CLARIFY	NEW	ui	01KEH3KYJ7HSJKDZ5Q77RK6Q3W	{"kpi": "kpoi", "goal": "Test geal", "risks": "no", "scope": "scope scope scope scope scope scope scope", "title": "Test geal", "source": "manual", "context": "contect text contect text contect text contect text contect text contect text", "intentId": "cmk6pq7nm00071fdlp1zekwp7", "language": "EN", "deadlineAt": "2026-04-24T00:00:00.000Z", "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEH3P1PP3SDPHMF0Y232H1GC	1	INTENT_CREATED	2026-01-09 10:08:56.017	2026-01-09 10:08:56.022	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	cmjdakp0f0001ut2uv0n881s3	INTENT	cmk6prope00091fdlrmf971oe	CLARIFY	NEW	ui	01KEH3P1PNRS9CDJ7P98B8QQXZ	{"title": "test from paste", "source": "paste", "intentId": "cmk6prope00091fdlrmf971oe", "language": "EN", "sourceText": {"length": 306, "sha256": "c665ed3e848c967df34a70ab003f5c006a71950a81fd85f1b6202dec20d1c4d4"}, "payloadVersion": 1, "confidentialityLevel": "L1"}
01KEH7F2Y84K2BBQ9A31MYFPB7	1	USER_LOGGED_IN	2026-01-09 11:15:02.212	2026-01-09 11:15:02.216	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEH7F2Y4430SDXSZNWTNGW6F	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6s4p0x0002u9ict4dj6ivv", "payloadVersion": 1}
01KEH7M7YX6BHCXG95HEE26W7C	1	ATTACHMENT_UPLOADED	2026-01-09 11:17:51.197	2026-01-09 11:17:51.197	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	a18908ca-43ce-4050-b996-fdff09dea594	CLARIFY	NEW	api	c3cadc53-68d2-4724-985e-9a9834183765	{"filename": "SWZ - na Åwiadczeniu usÅug dotyczÄcych przygotowania dokumentacji przetargowej i udziaÅ w przeprowadzeniu postÄpowaÅ-sig.pdf", "intentId": "cmk5tzxoz000o1341jzo45i8m", "sizeBytes": 1211889, "attachmentId": "a18908ca-43ce-4050-b996-fdff09dea594", "payloadVersion": 1}
01KEH7N6T9ARJN3HDY1MB93TXK	1	ATTACHMENT_UPLOADED	2026-01-09 11:18:22.793	2026-01-09 11:18:22.793	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	68903f1d-3d55-4d20-b2a3-e69e6e24a7d7	CLARIFY	NEW	api	fb2e94a1-0b3d-4d3b-b991-9a5a0f8333cd	{"filename": "Wzor_zapytania_ofertowego_31082018.pdf", "intentId": "cmk5tzxoz000o1341jzo45i8m", "sizeBytes": 225728, "attachmentId": "68903f1d-3d55-4d20-b2a3-e69e6e24a7d7", "payloadVersion": 1}
01KEH7ZK3VD6K4YD04A57954W6	1	ATTACHMENT_UPLOADED	2026-01-09 11:24:03.067	2026-01-09 11:24:03.068	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	55dd579c-72a2-486b-98ea-58bc5c90307e	CLARIFY	NEW	api	53596fa9-9980-4c3f-9e56-77d8ec567df5	{"filename": "Wzor_zapytania_ofertowego_31082018.pdf", "intentId": "cmk5tzxoz000o1341jzo45i8m", "sizeBytes": 225728, "attachmentId": "55dd579c-72a2-486b-98ea-58bc5c90307e", "payloadVersion": 1}
01KEH81G427TNEPJ6PW3MCBCQV	1	USER_LOGGED_OUT	2026-01-09 11:25:05.538	2026-01-09 11:25:05.539	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEH81G42PSHNGJ1PJVNGX2CA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6s4p0x0002u9ict4dj6ivv", "payloadVersion": 1}
01KEH81JG4WNB0J625H9NERG38	1	USER_LOGGED_IN	2026-01-09 11:25:07.972	2026-01-09 11:25:07.972	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEH81JG4H6HHZ13CCHXQDNVE	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6shofv0002nqfueg244379", "payloadVersion": 1}
01KEH87VDQR8FQZWYZEQGY4M4N	1	ATTACHMENT_UPLOADED	2026-01-09 11:28:33.718	2026-01-09 11:28:33.719	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	28186488-2989-428f-8b96-a7db41abf6a5	CLARIFY	NEW	api	c9f2a35c-ce3c-4751-817e-bd87bc0d1d62	{"filename": "Wzor_zapytania_ofertowego_31082018.pdf", "intentId": "cmk5tzxoz000o1341jzo45i8m", "sizeBytes": 225728, "attachmentId": "28186488-2989-428f-8b96-a7db41abf6a5", "payloadVersion": 1}
01KEH881JT7QQFQ3XR6THB7MQY	1	ATTACHMENT_DOWNLOADED	2026-01-09 11:28:40.026	2026-01-09 11:28:40.026	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	55dd579c-72a2-486b-98ea-58bc5c90307e	CLARIFY	NEW	api	ee7f5018-6792-4991-9062-186239177288	{"via": "owner", "intentId": "cmk5tzxoz000o1341jzo45i8m", "attachmentId": "55dd579c-72a2-486b-98ea-58bc5c90307e", "payloadVersion": 1}
01KEH88BNB5YS9QDFW2W0ZTB9A	1	ATTACHMENT_DOWNLOADED	2026-01-09 11:28:50.347	2026-01-09 11:28:50.348	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	28186488-2989-428f-8b96-a7db41abf6a5	CLARIFY	NEW	api	220cf43b-cd8e-4355-8e06-0359ae5bf53b	{"via": "owner", "intentId": "cmk5tzxoz000o1341jzo45i8m", "attachmentId": "28186488-2989-428f-8b96-a7db41abf6a5", "payloadVersion": 1}
01KEH8A3RBZ6TFTQBR5QBXDWP9	1	ATTACHMENT_UPLOADED	2026-01-09 11:29:47.787	2026-01-09 11:29:47.787	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	2bf33850-1abc-48cf-b737-974c780e934d	CLARIFY	NEW	api	689af626-c0cb-42f2-80b2-4721e0805566	{"filename": "quantum.png", "intentId": "cmk5tzxoz000o1341jzo45i8m", "sizeBytes": 42676, "attachmentId": "2bf33850-1abc-48cf-b737-974c780e934d", "payloadVersion": 1}
01KEH8BAG23YY9GRMSBXY93M9R	1	ATTACHMENT_UPLOADED	2026-01-09 11:30:27.458	2026-01-09 11:30:27.458	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	fc5c4518-ab41-4653-979c-62e62253fa6b	CLARIFY	NEW	api	7cfa9f9c-8786-4c2e-afac-d2fdecc48abf	{"filename": "Adv01.JPEG", "intentId": "cmk5tiyvu000j1341uqwwes3f", "sizeBytes": 1169162, "attachmentId": "fc5c4518-ab41-4653-979c-62e62253fa6b", "payloadVersion": 1}
01KEH8BRFMTY7EZ0GFFG09WS6T	1	ATTACHMENT_UPLOADED	2026-01-09 11:30:41.78	2026-01-09 11:30:41.781	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	d31f1aaf-b18f-40db-a3c7-50e06dbc87fd	CLARIFY	NEW	api	46d313f6-d8db-4b8d-8c3d-fa15656d3962	{"filename": "Wzor_zapytania_ofertowego_31082018 (1).pdf", "intentId": "cmk5tiyvu000j1341uqwwes3f", "sizeBytes": 225728, "attachmentId": "d31f1aaf-b18f-40db-a3c7-50e06dbc87fd", "payloadVersion": 1}
01KEHBT0YN1D608YJ0EDTH583T	1	USER_PASSWORD_RESET_REQUESTED	2026-01-09 12:30:54.933	2026-01-09 12:30:54.934	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHBT0YB6QXNNMMGT5MFRATS	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk6uu9xt00028cfegbsjaca4", "payloadVersion": 1}
01KEHBT16YD5TER00S67CW71RM	1	EMAIL_SENT	2026-01-09 12:30:55.198	2026-01-09 12:30:55.198	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHBT0YB6QXNNMMGT5MFRATS	{"messageId": "<11c2bc13-ee85-3842-8fbb-0263133e40a1@enabion.com>", "transport": "smtp", "messageType": "password_reset", "resetTokenId": "cmk6uu9xt00028cfegbsjaca4", "payloadVersion": 1}
01KEHBZS84P8A00N5NSMJ9FW8C	1	USER_PASSWORD_RESET_COMPLETED	2026-01-09 12:34:03.651	2026-01-09 12:34:03.652	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHBZS83JRJSSRRKPABY06WJ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "resetTokenId": "cmk6uu9xt00028cfegbsjaca4", "payloadVersion": 1}
01KEHC0ZCZAZ2JZHG8KCV7Y45Y	1	USER_LOGGED_IN	2026-01-09 12:34:42.719	2026-01-09 12:34:42.719	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHC0ZCZP4V94ZHSFJRQHMAG	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6uz5p500068cfekphhe7xu", "payloadVersion": 1}
01KEHC17KC9GXV0ETFVH72XR8Y	1	USER_LOGGED_OUT	2026-01-09 12:34:51.115	2026-01-09 12:34:51.116	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHC17KB8BDBS55CXYPJ848D	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6uz5p500068cfekphhe7xu", "payloadVersion": 1}
01KEHC1BQH6E4XVTH8BY0Q9RY1	1	USER_LOGGED_IN	2026-01-09 12:34:55.345	2026-01-09 12:34:55.345	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHC1BQHJ9MCSDZW8M3NZB9T	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk6uzffv00098cfegcmu6dku", "payloadVersion": 1}
01KEHC4VCST00VPVH1G1JV9WPE	1	USER_LOGGED_IN	2026-01-09 12:36:49.689	2026-01-09 12:36:49.689	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHC4VCSJHTQQD1DVFBJSZH5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6v1vo1000c8cfeb72g7670", "payloadVersion": 1}
01KEHC5E8R29A7D6KZ8KJ1R21R	1	ATTACHMENT_UPLOADED	2026-01-09 12:37:09.016	2026-01-09 12:37:09.016	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	a79ef63f-750e-4e3d-bec4-4d3b7ada409c	CLARIFY	NEW	api	cafdeb31-ac08-4629-9d07-5838e29f7d58	{"filename": "Wzor_zapytania_ofertowego_31082018.pdf", "intentId": "cmk5tiyvu000j1341uqwwes3f", "sizeBytes": 225728, "attachmentId": "a79ef63f-750e-4e3d-bec4-4d3b7ada409c", "payloadVersion": 1}
01KEHC701MSVTQHPPMWEZGY657	1	ATTACHMENT_UPLOADED	2026-01-09 12:37:59.988	2026-01-09 12:37:59.988	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	de3d27d3-23a2-4a68-afb5-6c7c0d835d7a	CLARIFY	NEW	api	9528a6b5-3051-4f25-ab46-fbba29b207fc	{"filename": "Phase1_MVP-Spec (1).md", "intentId": "cmk5tzxoz000o1341jzo45i8m", "sizeBytes": 31283, "attachmentId": "de3d27d3-23a2-4a68-afb5-6c7c0d835d7a", "payloadVersion": 1}
01KEHC7SJMHAMY0SYTD77J7P2K	1	USER_LOGGED_IN	2026-01-09 12:38:26.132	2026-01-09 12:38:26.132	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHC7SJMTN0XR8CQBKXK2ZTR	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6v3y33000f8cfer68q0gv7", "payloadVersion": 1}
01KEHCA9RSY8E0VQPTCCD0T9KE	1	USER_LOGGED_OUT	2026-01-09 12:39:48.249	2026-01-09 12:39:48.249	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHCA9RSGG81H9KT0MQMADCN	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6v3y33000f8cfer68q0gv7", "payloadVersion": 1}
01KEHCAKGPSBQ4FHSMAYX5Z77H	1	USER_LOGGED_IN	2026-01-09 12:39:58.229	2026-01-09 12:39:58.23	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHCAKGNK0DAW6GJW92T0T6M	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6v5x5d000i8cfeq5k74e57", "payloadVersion": 1}
01KEHCAWP7APMS815WY33450KM	1	USER_LOGGED_IN	2026-01-09 12:40:07.622	2026-01-09 12:40:07.623	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHCAWP64B80XKAZQSDXCHTX	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6v64e8000l8cfevigalycw", "payloadVersion": 1}
01KEHCB5V1ZBZ92Q9PQ5GC2J6Y	1	ATTACHMENT_UPLOADED	2026-01-09 12:40:16.993	2026-01-09 12:40:16.994	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	af124402-0346-4076-aaf0-0a4578e1e1bc	CLARIFY	NEW	api	ba950842-7000-48e5-8909-70668f21fa6f	{"filename": "Phase1_MVP-Spec.md", "intentId": "cmk5tiyvu000j1341uqwwes3f", "sizeBytes": 31283, "attachmentId": "af124402-0346-4076-aaf0-0a4578e1e1bc", "payloadVersion": 1}
01KEHD3DNJWXXV5RP3D9BQ764R	1	USER_LOGGED_IN	2026-01-09 12:53:31.441	2026-01-09 12:53:31.442	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHD3DNHTFG67QR1GJNJHQMF	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6vncmi000o8cfegks6ecmx", "payloadVersion": 1}
01KEHE8QG3X6V30EKMB5GSB6QY	1	USER_LOGGED_IN	2026-01-09 13:13:53.922	2026-01-09 13:13:53.923	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHE8QG2A0N114X8ST2B5S7K	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6wdjwa000r8cfeoenzltkc", "payloadVersion": 1}
01KEHE9DKPYFT4E9XV3QAV3FPK	1	ATTACHMENT_UPLOADED	2026-01-09 13:14:16.566	2026-01-09 13:14:16.566	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	f25d9e08-7a0f-48f1-b257-55a2cbb86a85	CLARIFY	NEW	api	3a7d5e7f-d2a7-420f-91d9-959043f15c99	{"filename": "Phase1_MVP-Spec.md", "intentId": "cmk5tiyvu000j1341uqwwes3f", "sizeBytes": 31283, "attachmentId": "f25d9e08-7a0f-48f1-b257-55a2cbb86a85", "payloadVersion": 1}
01KEHE9JY8KVGTFJB4D00ZNZ3R	1	USER_LOGGED_OUT	2026-01-09 13:14:22.024	2026-01-09 13:14:22.024	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHE9JY83DF739XTBWDDKCWH	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6wdjwa000r8cfeoenzltkc", "payloadVersion": 1}
01KEHFP5TCGR9QZ32N0ZGETJTH	1	USER_LOGGED_IN	2026-01-09 13:38:43.147	2026-01-09 13:38:43.148	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHFP5TB9J6C0ZABZW6B7APB	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6x9gzd0002grbrvybbpk95", "payloadVersion": 1}
01KEHFPQKVFVNFE4M1KT7111MD	1	ATTACHMENT_UPLOADED	2026-01-09 13:39:01.371	2026-01-09 13:39:01.371	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	cd1f3b9a-1ce1-4e43-b8c4-1da4874d14b5	CLARIFY	NEW	api	f9c667ee-c5f5-42ea-a404-bb00a36f60e0	{"filename": "Phase1_MVP-Spec.md", "intentId": "cmk5te87r000e1341tr7y1dat", "sizeBytes": 31283, "attachmentId": "cd1f3b9a-1ce1-4e43-b8c4-1da4874d14b5", "payloadVersion": 1}
01KEHFPXCGN0QMAG9JGJ8N5G1B	1	ATTACHMENT_UPLOADED	2026-01-09 13:39:07.28	2026-01-09 13:39:07.28	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	3068d846-ba20-4074-863a-9eb1dde45477	CLARIFY	NEW	api	0ad96470-cadc-48d9-bd45-8fd2be5561f1	{"filename": "Phase1_MVP-Spec (1).md", "intentId": "cmk5te87r000e1341tr7y1dat", "sizeBytes": 31283, "attachmentId": "3068d846-ba20-4074-863a-9eb1dde45477", "payloadVersion": 1}
01KEHG16KHQGYB4TQBEWTSZTEM	1	USER_LOGGED_OUT	2026-01-09 13:44:44.4	2026-01-09 13:44:44.401	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHG16KGM5JGPJ7F2CK5XXF5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6x9gzd0002grbrvybbpk95", "payloadVersion": 1}
01KEHG1A75FAFC0Y4B2HXQH3V8	1	USER_LOGGED_IN	2026-01-09 13:44:48.101	2026-01-09 13:44:48.101	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHG1A75VES6PRBC0FC9CEZA	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk6xhalb0005grbrgavaw5w0", "payloadVersion": 1}
01KEHG1CD0NJMTT27FQ0YAKMAB	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:44:50.335	2026-01-09 13:44:50.336	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG1CCZ3C8C6Z9V12F2QJTD	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHG1EQ0E0A1XA5DNSAAH5BN	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:44:52.704	2026-01-09 13:44:52.704	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG1EQ0M40HNPEWXX6TBWH9	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHG1FRN8SDY7NEWYNZ0QMPW	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:44:53.781	2026-01-09 13:44:53.781	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG1FRNHHR94EXSKRNMEDCZ	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEHG1FS9J2V1WN3FQ00SYAWV	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:44:53.801	2026-01-09 13:44:53.801	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG1FS9V01WQ1G0TFMB7YKV	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEHG1HX350SCJVGAFP0JFWQJ	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:44:55.971	2026-01-09 13:44:55.971	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG1HX3D1FMNEJEQ147JF0G	{"action": "USER_VIEW", "targetId": "cmk48grgz0008bmbcp8s2vrap", "targetType": "USER", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "targetUserId": "cmk48grgz0008bmbcp8s2vrap", "payloadVersion": 1}
01KEHG1VZSTKZWDHAZ5QBVEXGB	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:06.297	2026-01-09 13:45:06.297	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG1VZSPEZBZ79TRPW91MK5	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHG1ZY2RAVWNYEBQ0JX6VHZ	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:10.338	2026-01-09 13:45:10.338	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG1ZY21ZX3FSFDZZXXT88Q	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHG1ZYT8KGSYRZAHDXY2TYF	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:10.362	2026-01-09 13:45:10.362	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG1ZYT12H89F50M8BQ2XME	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHG2B37S3B2M3GAE7WGV5FS	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:21.767	2026-01-09 13:45:21.767	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG2B370HJ78V2EXQXPXBDK	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHG2CEH45MH8S9P8NFEATCW	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:23.153	2026-01-09 13:45:23.153	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG2CEH6MXHGQ3YMD59DYDQ	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEHG2CEMET9771W4WKQECQQQ	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:23.156	2026-01-09 13:45:23.157	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG2CEMQ2D5DGBPP2KQBNA5	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEHG2F4D6847P4D3XV0A1XHV	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:25.901	2026-01-09 13:45:25.901	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG2F4DS0W8QN49FKJ1F8PG	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHG2G5RWWDCACG4E56D9A3S	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:26.968	2026-01-09 13:45:26.968	cmjejbes70007o1hxngxzzzw7	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG2G5R8350JRHB0QETSDFY	{"action": "TENANT_VIEW", "targetId": "cmjejbes70007o1hxngxzzzw7", "targetType": "TENANT", "targetOrgId": "cmjejbes70007o1hxngxzzzw7", "payloadVersion": 1}
01KEHG2G5WCGXWGHJ6W5A543TE	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:26.972	2026-01-09 13:45:26.972	cmjejbes70007o1hxngxzzzw7	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG2G5WJ399BP9FW3Q1X4PP	{"action": "TENANT_USERS_LIST", "targetId": "cmjejbes70007o1hxngxzzzw7", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmjejbes70007o1hxngxzzzw7", "payloadVersion": 1}
01KEHG2JJN3TAQ9H9KPG419Y9W	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:29.429	2026-01-09 13:45:29.43	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG2JJNB9XTA5F488PX65GY	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHG2KNX4W4HHH5KTNDPJENA	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:30.557	2026-01-09 13:45:30.557	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG2KNX1H0P601NAHHBNENZ	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHG2KNYYJ1NJ1FC2BV2XM3F	1	PLATFORM_ADMIN_AUDIT	2026-01-09 13:45:30.558	2026-01-09 13:45:30.558	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHG2KNYG76ZED71DQYV2FEY	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHG35N7AYWFYZDNCW7S70FK	1	USER_LOGGED_OUT	2026-01-09 13:45:48.967	2026-01-09 13:45:48.967	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHG35N7X7YYA6G4NHATJBG5	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk6xhalb0005grbrgavaw5w0", "payloadVersion": 1}
01KEHG3C0P6VYX1KD3S23K5DDZ	1	USER_LOGGED_IN	2026-01-09 13:45:55.478	2026-01-09 13:45:55.479	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHG3C0P2MD9RFQTFR0V8MA5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6xiqkw0008grbrssdllum4", "payloadVersion": 1}
01KEHHYE8RGKS5JBGV8RD8V9EG	1	INTENT_UPDATED	2026-01-09 14:18:11.083	2026-01-09 14:18:11.097	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	CLARIFY	CLARIFY	ui	01KEHHYE8Q9SZGF2ACGF32DRF0	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "changeSummary": "Pipeline stage changed from NEW to CLARIFY", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEHHYKHNNDNEC0NPQ6F6BVDK	1	INTENT_UPDATED	2026-01-09 14:18:16.496	2026-01-09 14:18:16.501	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KEHHYKHNN7EM9H47E7SRGRY4	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "changeSummary": "Pipeline stage changed from CLARIFY to MATCH", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEHHYY5CDMEWD2BEXCY9KQ40	1	INTENT_UPDATED	2026-01-09 14:18:27.367	2026-01-09 14:18:27.372	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5te87r000e1341tr7y1dat	CLARIFY	CLARIFY	ui	01KEHHYY5C47X9ZHBW0AFJPWS9	{"intentId": "cmk5te87r000e1341tr7y1dat", "changeSummary": "Pipeline stage changed from NEW to CLARIFY", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEHHZ4975RBW6CEDTZD6JVF7	1	INTENT_UPDATED	2026-01-09 14:18:33.635	2026-01-09 14:18:33.639	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tiyvu000j1341uqwwes3f	CLARIFY	CLARIFY	ui	01KEHHZ497WDY063Z7Y5CF1FZT	{"intentId": "cmk5tiyvu000j1341uqwwes3f", "changeSummary": "Pipeline stage changed from NEW to CLARIFY", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEHHZ9ETFGM3CFQK6V8HRRXG	1	INTENT_UPDATED	2026-01-09 14:18:38.933	2026-01-09 14:18:38.938	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	COMMIT_ASSURE	COMMIT	ui	01KEHHZ9ET465R33YXFT838KQ8	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "changeSummary": "Pipeline stage changed from MATCH to COMMIT", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEHHZAS7X4T06PG9GS89HK8B	1	INTENT_UPDATED	2026-01-09 14:18:40.292	2026-01-09 14:18:40.295	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5jhwcq0006bdrsvh8hnxme	MATCH_ALIGN	MATCH	ui	01KEHHZAS7KZGKFY3S8JA8C0X2	{"intentId": "cmk5jhwcq0006bdrsvh8hnxme", "changeSummary": "Pipeline stage changed from NEW to MATCH", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEHJB5YADAD8K4C0FR9ZDXP5	1	USER_LOGGED_OUT	2026-01-09 14:25:08.554	2026-01-09 14:25:08.555	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHJB5YA031QEVD7BSQYP31S	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6xiqkw0008grbrssdllum4", "payloadVersion": 1}
01KEHJB85FQF8F81ZM3CKHED9F	1	USER_LOGGED_IN	2026-01-09 14:25:10.831	2026-01-09 14:25:10.832	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHJB85F6JX4AVDWFMP156WP	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6yx7zc0002padg8zhbkzvh", "payloadVersion": 1}
01KEHJBH04HRF14Z2CTF5SYSG6	1	USER_LOGGED_OUT	2026-01-09 14:25:19.876	2026-01-09 14:25:19.876	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHJBH04HXA3BWHYQ8174AMB	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6yx7zc0002padg8zhbkzvh", "payloadVersion": 1}
01KEHJBNE8W5FMK4B14XNZ6ZBX	1	USER_LOGGED_IN	2026-01-09 14:25:24.424	2026-01-09 14:25:24.424	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHJBNE8AG0HVB5VWB3305V1	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk6yxigz0005padgmrxcr7e5", "payloadVersion": 1}
01KEHJBQHKS12DMCPJQSCBMFHR	1	PLATFORM_ADMIN_AUDIT	2026-01-09 14:25:26.578	2026-01-09 14:25:26.579	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHJBQHJZ71N1C5E7J8HPS3B	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHJC3CZTR05QTB6RT32YH65	1	USER_LOGGED_OUT	2026-01-09 14:25:38.718	2026-01-09 14:25:38.719	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHJC3CYPZ2SCVJT4F5DBB07	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk6yxigz0005padgmrxcr7e5", "payloadVersion": 1}
01KEHJC8KNMCFFBZAKFR71W4EX	1	USER_LOGGED_IN	2026-01-09 14:25:44.053	2026-01-09 14:25:44.053	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHJC8KNSEKD78PN5ZYK0MDM	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6yxxm70008padg9w2v2zsq", "payloadVersion": 1}
01KEHJQC22SMWH01C6G53G5A88	1	USER_LOGGED_OUT	2026-01-09 14:31:48.033	2026-01-09 14:31:48.034	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHJQC212RP1CZXAQA7P31VC	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6yxxm70008padg9w2v2zsq", "payloadVersion": 1}
01KEHJQEXRYVWCVBXZ2Y791X4Z	1	USER_LOGGED_IN	2026-01-09 14:31:50.968	2026-01-09 14:31:50.969	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHJQEXRGTJS1MPGXS1CHEEY	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6z5sq7000bpadgmavswyub", "payloadVersion": 1}
01KEHJRPCTXXDEVBPZM7R2WJ7F	1	USER_LOGGED_OUT	2026-01-09 14:32:31.386	2026-01-09 14:32:31.386	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHJRPCT3MGZKEQ43V1SVMXR	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6z5sq7000bpadgmavswyub", "payloadVersion": 1}
01KEHJRVQM66FYDC3HAXKKW5TA	1	USER_LOGGED_IN	2026-01-09 14:32:36.852	2026-01-09 14:32:36.852	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHJRVQMBMN5M5AJHJSFERBQ	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk6z6s4v000epadggb51z95v", "payloadVersion": 1}
01KEHJS04TA9H6C86M04PCD22A	1	PLATFORM_ADMIN_AUDIT	2026-01-09 14:32:41.369	2026-01-09 14:32:41.37	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHJS04S0TGBT4F6CV7WJ8J4	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHJS62S8P1RFDSK2BX6YKTA	1	PLATFORM_ADMIN_AUDIT	2026-01-09 14:32:47.449	2026-01-09 14:32:47.449	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHJS62SQS5SCC3Z2SYG664A	{"query": {"limit": 50, "orgId": "cmk12kr4u000do1hxva29zgyd"}, "action": "EVENTS_QUERY", "targetType": "EVENTS", "resultCount": 50, "payloadVersion": 1}
01KEHK1B9R2998AZGQG1632DS7	1	USER_LOGGED_OUT	2026-01-09 14:37:14.936	2026-01-09 14:37:14.936	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHK1B9RZVNJGCGM1YGYBAAK	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk6z6s4v000epadggb51z95v", "payloadVersion": 1}
01KEHK1FX81TQM95ZBBST4FMAX	1	USER_LOGGED_IN	2026-01-09 14:37:19.656	2026-01-09 14:37:19.656	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHK1FX8W6K1B4BHP88M9PQC	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6zcuci000hpadgowq8k7r0", "payloadVersion": 1}
01KEHKCEFH7E94W0P186W7FFN2	1	USER_LOGGED_OUT	2026-01-09 14:43:18.641	2026-01-09 14:43:18.641	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHKCEFHGD1NB2CN3CZ79HJ9	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6zcuci000hpadgowq8k7r0", "payloadVersion": 1}
01KEHKCGY0N98FNSZXQYNZ4AD6	1	USER_LOGGED_IN	2026-01-09 14:43:21.152	2026-01-09 14:43:21.152	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHKCGY08BW5WC6WRSPWC7TF	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6zkla1000kpadgt4kfi41b", "payloadVersion": 1}
01KEHKDH7M054GCM1J3YJBJT1V	1	USER_LOGGED_OUT	2026-01-09 14:43:54.227	2026-01-09 14:43:54.228	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHKDH7K27AKRK8Z2FPMT1Z6	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6zkla1000kpadgt4kfi41b", "payloadVersion": 1}
01KEHKDKA143717287EFY8P3NP	1	USER_LOGGED_IN	2026-01-09 14:43:56.353	2026-01-09 14:43:56.353	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHKDKA1NZP1SSYJ3QDW9DK5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6zlcfx000npadgy47ja86n", "payloadVersion": 1}
01KEHMAZM32977ZP7X1RA1AJQ7	1	USER_LOGGED_OUT	2026-01-09 14:59:59.234	2026-01-09 14:59:59.235	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHMAZM21T2TJNK3DW16P26E	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk6zlcfx000npadgy47ja86n", "payloadVersion": 1}
01KEHMBAVMJG2JP7G3J4MEN2FE	1	USER_LOGGED_IN	2026-01-09 15:00:10.739	2026-01-09 15:00:10.74	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHMBAVKEVNYK7JB08PW2W6K	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk70689t000217eacxm7i6pi", "payloadVersion": 1}
01KEHMZY3D4C0FRQF5W5P2YNKB	1	USER_LOGGED_OUT	2026-01-09 15:11:25.805	2026-01-09 15:11:25.806	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHMZY3D903RMBN122WXJ7TT	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk70689t000217eacxm7i6pi", "payloadVersion": 1}
01KEHN00BESCBKWHY6N041KC14	1	USER_LOGGED_IN	2026-01-09 15:11:28.109	2026-01-09 15:11:28.11	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHN00BD3K3DVQ0ZR3RZ5J30	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk70kqxz000517eael15e9xg", "payloadVersion": 1}
01KEHN1BEV78TPP31Z1Q74043E	1	INTENT_UPDATED	2026-01-09 15:12:12.246	2026-01-09 15:12:12.251	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	COMMIT_ASSURE	LOST	ui	01KEHN1BEV6VDGSZN2YPH96E05	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "changeSummary": "Pipeline stage changed from COMMIT to LOST", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEHNEH6DWX8CMQG4W5ZD8E1R	1	INTENT_UPDATED	2026-01-09 15:19:24.101	2026-01-09 15:19:24.109	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	COMMIT_ASSURE	COMMIT	ui	01KEHNEH6CHCAGJX5CGNT3JRWD	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "changeSummary": "Pipeline stage changed from LOST to COMMIT", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEHPNXKCYHS12F0B4YGWZP69	1	INTENT_UPDATED	2026-01-09 15:40:54.754	2026-01-09 15:40:54.764	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5jhwcq0006bdrsvh8hnxme	CLARIFY	CLARIFY	ui	01KEHPNXKBWQM3D7AR7FTBR23C	{"intentId": "cmk5jhwcq0006bdrsvh8hnxme", "changeSummary": "Pipeline stage changed from MATCH to CLARIFY", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEHRME0E5MTNH0QBF15WHFXM	1	USER_LOGGED_OUT	2026-01-09 16:15:03.181	2026-01-09 16:15:03.182	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHRME0DDZ2833N08P2W5Y99	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk70kqxz000517eael15e9xg", "payloadVersion": 1}
01KEHRMJQXXWKE31WPHN50S3KM	1	USER_LOGGED_IN	2026-01-09 16:15:08.028	2026-01-09 16:15:08.029	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHRMJQWKSXG4QP1RYEVRW33	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk72umen0002dq0dmju82snf", "payloadVersion": 1}
01KEHRMPKQH1TJTP4SWNJYSC3E	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:15:11.99	2026-01-09 16:15:11.991	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHRMPKPVC933SB3XF9SNYA7	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHRN01E5NAWFA6BNMNSVNK5	1	USER_LOGGED_OUT	2026-01-09 16:15:21.645	2026-01-09 16:15:21.646	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHRN01D5G0QBSYEWSNF8EFS	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk72umen0002dq0dmju82snf", "payloadVersion": 1}
01KEHRN2M17A268JDYJXNYQP5Z	1	USER_LOGGED_IN	2026-01-09 16:15:24.289	2026-01-09 16:15:24.289	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHRN2M1XV7NGS2XV6NZYVNS	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk72uyyk0005dq0dfelm397t", "payloadVersion": 1}
01KEHRNW29JEM96F6EPXQD354R	1	USER_LOGGED_OUT	2026-01-09 16:15:50.345	2026-01-09 16:15:50.345	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHRNW29EVPX0X99FWPY8C07	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk72uyyk0005dq0dfelm397t", "payloadVersion": 1}
01KEHRP2NY4279385CCX6TRKSN	1	USER_LOGGED_IN	2026-01-09 16:15:57.118	2026-01-09 16:15:57.118	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHRP2NYXQA43A73KJM47A6B	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk72voah0008dq0dbhngl0ql", "payloadVersion": 1}
01KEHRP8QK42RW446Q34HWGKGP	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:16:03.315	2026-01-09 16:16:03.315	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHRP8QKE92W2BFNRA4PJWC7	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHRPBPNNJ1FEWE0Y3DDACCT	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:16:06.357	2026-01-09 16:16:06.357	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHRPBPNMCNRDJ94390EMDTM	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHRPBQB5S860G4VY1336KH3	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:16:06.379	2026-01-09 16:16:06.379	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHRPBQB9R83QM291E2Q6Q31	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHRPJY5VW2HH87VNZS9A4R3	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:16:13.765	2026-01-09 16:16:13.765	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHRPJY52SW49NJ4NX3T91JQ	{"query": {"type": "INTENT_CREATED", "limit": 50, "orgId": "cmk12kr4u000do1hxva29zgyd"}, "action": "EVENTS_QUERY", "targetType": "EVENTS", "resultCount": 6, "payloadVersion": 1}
01KEHRPRQCYAXQ8GJR44GGBEMH	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:16:19.692	2026-01-09 16:16:19.692	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHRPRQC296A8CGVG2N7Z9VN	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHRPRQYAH8BZMPEZ6HM9BD1	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:16:19.71	2026-01-09 16:16:19.71	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHRPRQY6YSYKT9KB913KQA5	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHRPWP9N4F2WQ1FK77TWREY	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:16:23.752	2026-01-09 16:16:23.753	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHRPWP8M801RXXC1Q5N55RH	{"query": {"type": "INTENT_CREATED", "limit": 50, "orgId": "cmk12kr4u000do1hxva29zgyd"}, "action": "EVENTS_QUERY", "targetType": "EVENTS", "resultCount": 6, "payloadVersion": 1}
01KEHRQ0CTA1HTCAV4XFGQBFK5	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:16:27.546	2026-01-09 16:16:27.546	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHRQ0CTFQQKA5QQM9HAGNRV	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHRQ0CV8KJEKZ8BHN16B9FB	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:16:27.547	2026-01-09 16:16:27.548	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHRQ0CV0HBJGXAJVW8GW8SB	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHS25E2TQXKMWHW6SEVD194	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:22:33.153	2026-01-09 16:22:33.154	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHS25E1SCDM7P19P1Q0P7FE	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHS28EB157TJ8D120SQYC2H	1	USER_LOGGED_OUT	2026-01-09 16:22:36.235	2026-01-09 16:22:36.235	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHS28EBDSM70M88PAKMQW2Z	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk72voah0008dq0dbhngl0ql", "payloadVersion": 1}
01KEHS2D3N4XGCBQRZDTE7ZG5S	1	USER_LOGGED_IN	2026-01-09 16:22:41.013	2026-01-09 16:22:41.013	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHS2D3NAKZHZDRJR499FS2K	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk734bxo0002oyv7bw5uo2zv", "payloadVersion": 1}
01KEHS2NCQEHV96RQJKA31RPTN	1	USER_LOGGED_OUT	2026-01-09 16:22:49.494	2026-01-09 16:22:49.495	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHS2NCP4JQE19Z97BBKB0JX	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk734bxo0002oyv7bw5uo2zv", "payloadVersion": 1}
01KEHS3PWFPC8PR841NN11ZS98	1	USER_LOGGED_IN	2026-01-09 16:23:23.791	2026-01-09 16:23:23.792	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHS3PWFQ5ZT0Z35WMREE12X	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk7358y30005oyv79ww3j28c", "payloadVersion": 1}
01KEHS3VH82SHDNT0YZSN27DGG	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:23:28.552	2026-01-09 16:23:28.552	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHS3VH8CH7QJNVJJF6AJHCT	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHS3XVDGJWBC2QCBC48VX4C	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:23:30.925	2026-01-09 16:23:30.926	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHS3XVDXNMMCGVXFDAJYT9H	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHS3XVP8TM210X42R0VAPNJ	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:23:30.933	2026-01-09 16:23:30.934	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHS3XVNN7EWXAV7R4G9Z3TK	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEHS408Y3FX72SHVW4F0STME	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:23:33.406	2026-01-09 16:23:33.406	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHS408Y8VD4JWV7AZDJ764M	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHS423DAF1JXD5X0FYZ1MCF	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:23:35.277	2026-01-09 16:23:35.277	cmjejbes70007o1hxngxzzzw7	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHS423DH9TGZP6ZQ25XCARZ	{"action": "TENANT_VIEW", "targetId": "cmjejbes70007o1hxngxzzzw7", "targetType": "TENANT", "targetOrgId": "cmjejbes70007o1hxngxzzzw7", "payloadVersion": 1}
01KEHS4243JXBVHM09BGY71KD5	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:23:35.299	2026-01-09 16:23:35.299	cmjejbes70007o1hxngxzzzw7	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHS4243E7DK0P3EC3N4C16P	{"action": "TENANT_USERS_LIST", "targetId": "cmjejbes70007o1hxngxzzzw7", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmjejbes70007o1hxngxzzzw7", "payloadVersion": 1}
01KEHS44Y46V1NDY687EMSYJ5X	1	PLATFORM_ADMIN_AUDIT	2026-01-09 16:23:38.18	2026-01-09 16:23:38.181	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEHS44Y4P2SKX60CHCKM2ZZ2	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEHS48SCGMF97RHCDZFJKR79	1	USER_LOGGED_OUT	2026-01-09 16:23:42.124	2026-01-09 16:23:42.124	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEHS48SC4VWZKY02H80W2R4Q	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk7358y30005oyv79ww3j28c", "payloadVersion": 1}
01KEHS5FKVVRNEV6HNTDM0JN2R	1	USER_SIGNED_UP	2026-01-09 16:24:21.883	2026-01-09 16:24:21.883	cmk736hrf0007oyv7jcxtvn9k	cmk736hrm0009oyv7mm2wm20e	\N	USER	cmk736hrm0009oyv7mm2wm20e	CLARIFY	NEW	api	01KEHS5FKVEX8JBT6BPFDNTZAA	{"role": "Owner", "email": "info04@staadit.com", "orgId": "cmk736hrf0007oyv7jcxtvn9k", "userId": "cmk736hrm0009oyv7mm2wm20e", "sessionId": "cmk736hrr000boyv7s17tdeqp", "payloadVersion": 1}
01KEHS6B0A50ZY42YBMJY9MJYB	1	USER_LOGGED_OUT	2026-01-09 16:24:49.93	2026-01-09 16:24:49.93	cmk736hrf0007oyv7jcxtvn9k	cmk736hrm0009oyv7mm2wm20e	\N	USER	cmk736hrm0009oyv7mm2wm20e	CLARIFY	NEW	api	01KEHS6B0A9SFZ629VBX7E93MA	{"orgId": "cmk736hrf0007oyv7jcxtvn9k", "userId": "cmk736hrm0009oyv7mm2wm20e", "sessionId": "cmk736hrr000boyv7s17tdeqp", "payloadVersion": 1}
01KEHS6J7V8WSSMM8EG0DDQRS3	1	USER_LOGGED_IN	2026-01-09 16:24:57.338	2026-01-09 16:24:57.339	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHS6J7TN4K54TFVP8T9T3Z3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk73794j000eoyv7l7h41mnr", "payloadVersion": 1}
01KEHS6MT01RA4ZPQHVNYHPTDM	1	USER_LOGGED_OUT	2026-01-09 16:24:59.968	2026-01-09 16:24:59.969	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHS6MT0QW60AHNP2R7TKRZZ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk73794j000eoyv7l7h41mnr", "payloadVersion": 1}
01KEHZA9CYR26ZEZH0EBV736CY	1	USER_LOGGED_IN	2026-01-09 18:11:50.814	2026-01-09 18:11:50.814	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHZA9CY8998FY2W5SJBBKYR	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk770psl000hoyv70erspo3h", "payloadVersion": 1}
01KEHZBT21VTXNBES32V1MSC98	1	USER_LOGGED_OUT	2026-01-09 18:12:40.641	2026-01-09 18:12:40.641	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEHZBT21HKMVPJJ9NTBYVFD7	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk770psl000hoyv70erspo3h", "payloadVersion": 1}
01KEJ57YFRDH64TMVFC39PA950	1	USER_LOGGED_IN	2026-01-09 19:55:25.56	2026-01-09 19:55:25.56	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEJ57YFR3SG9P7TZZ877KSVP	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk7apx4f000koyv7b5c17gii", "payloadVersion": 1}
01KEJAZK5WE88MYHCHK03J5C1A	1	USER_LOGGED_IN	2026-01-09 21:35:43.292	2026-01-09 21:35:43.292	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEJAZK5W482N7Z0BVFG3HCG9	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk7eawfp000noyv7sr4n4okk", "payloadVersion": 1}
01KEJCWBGDRA1HCCM5ZTJQE93F	1	USER_LOGGED_OUT	2026-01-09 22:08:54.285	2026-01-09 22:08:54.286	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEJCWBGDVK7C83VJ9HAMHGYX	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk7eawfp000noyv7sr4n4okk", "payloadVersion": 1}
01KEJCWFD4TKTXXKAE5DKSHMTS	1	USER_LOGGED_IN	2026-01-09 22:08:58.276	2026-01-09 22:08:58.276	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEJCWFD4DXDE4G4EY8G2VDF5	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk7fhnrz0002rlysw0pn7aux", "payloadVersion": 1}
01KEJCWK3B3D0T97STC7R6X1D2	1	PLATFORM_ADMIN_AUDIT	2026-01-09 22:09:02.058	2026-01-09 22:09:02.059	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEJCWK3A7NF2MFB9KPNFVN4C	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 0, "payloadVersion": 1}
01KEJCXNMDDM7EXJ4AA5V2EQ61	1	PLATFORM_ADMIN_AUDIT	2026-01-09 22:09:37.421	2026-01-09 22:09:37.421	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEJCXNMD77WGC5YYKJZZ6FZB	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 0, "payloadVersion": 1}
01KEJCXSGS15YWVMD6H9W0052S	1	USER_LOGGED_OUT	2026-01-09 22:09:41.4	2026-01-09 22:09:41.401	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEJCXSGRG39NM1ZEQSKKFFDB	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk7fhnrz0002rlysw0pn7aux", "payloadVersion": 1}
01KEJCXYJDQJVTZAH2FK7WK2RS	1	USER_LOGGED_IN	2026-01-09 22:09:46.573	2026-01-09 22:09:46.573	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEJCXYJDZCYQ8YWAH84284D0	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk7fip1l0005rlys3fh3mvex", "payloadVersion": 1}
01KEKHBNCT7BTEVAYQANH6Y8R3	1	USER_LOGGED_IN	2026-01-10 08:46:24.666	2026-01-10 08:46:24.666	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKHBNCTW8CBHDFC1AG0X3ZN	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk829evo0008rlysytuy9ld8", "payloadVersion": 1}
01KEKHCYDF7PHWKM0ANNMYV0BF	1	USER_LOGGED_OUT	2026-01-10 08:47:06.671	2026-01-10 08:47:06.671	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKHCYDFCZYRJARS64P39BQY	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk829evo0008rlysytuy9ld8", "payloadVersion": 1}
01KEKHD1X7477WN0T35WWNQDC9	1	USER_LOGGED_IN	2026-01-10 08:47:10.247	2026-01-10 08:47:10.248	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEKHD1X7BR5VQ66DGHAFE1MA	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk82ae1u000brlyszex4zi57", "payloadVersion": 1}
01KEKHD5FP1329C0NM1ZBFVC9N	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:47:13.91	2026-01-10 08:47:13.911	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHD5FPP6240PP8MMM54BQ0	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 0, "payloadVersion": 1}
01KEKHMV5NNX0WZGW4QZVVK9PA	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:51:25.493	2026-01-10 08:51:25.494	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHMV5NZP9KFRX847H40121	{"action": "NDA_CREATE", "targetId": "cmk82fv01000drlysjzro5gr6", "targetType": "NDA", "payloadVersion": 1}
01KEKHMV981GHGF44Z5C5TJ588	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:51:25.608	2026-01-10 08:51:25.609	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHMV98323N3GD5CW4E72DK	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 1, "payloadVersion": 1}
01KEKHPBCGS8TGRAKJHW9M3YKZ	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:52:14.863	2026-01-10 08:52:14.864	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHPBCFH389067W80EZQBQZ	{"action": "NDA_CREATE", "targetId": "cmk82gx3b000frlyscetkmbm9", "targetType": "NDA", "payloadVersion": 1}
01KEKHPBF3YT0TSCPYB2GCRRPV	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:52:14.947	2026-01-10 08:52:14.947	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHPBF3ETPYR13HBYHED3JW	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKHPH6D6JVM09HF46F03ABE	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:52:20.812	2026-01-10 08:52:20.813	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHPH6CM7KBGY77X74J7EYC	{"action": "NDA_UPDATE", "targetId": "cmk82gx3b000frlyscetkmbm9", "targetType": "NDA", "payloadVersion": 1}
01KEKHPH8VFZRREEAVJA4DVQKE	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:52:20.891	2026-01-10 08:52:20.891	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHPH8V8PMW9BAVJY24MQCV	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKHPMHPVS4CBBDE75B552TW	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:52:24.246	2026-01-10 08:52:24.246	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHPMHP322596D8FNVXC4T7	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKHPP6PY0K7TAPDFFA9VJ4R	1	USER_LOGGED_OUT	2026-01-10 08:52:25.942	2026-01-10 08:52:25.942	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEKHPP6P4WQS3309F7BHQNDF	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk82ae1u000brlyszex4zi57", "payloadVersion": 1}
01KEKHPVQJJ5NMD4T1AQEMGST7	1	USER_LOGGED_IN	2026-01-10 08:52:31.602	2026-01-10 08:52:31.602	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKHPVQJ33WVD3PRAY4SXHQ2	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk82ha0c000jrlysi4hfn7rc", "payloadVersion": 1}
01KEKHQ9TFYSXCWJMXHVCX2SM9	1	USER_LOGGED_OUT	2026-01-10 08:52:46.03	2026-01-10 08:52:46.031	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKHQ9TERXQ72E3F9NC5EB96	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk82ha0c000jrlysi4hfn7rc", "payloadVersion": 1}
01KEKHQD90YXAFSJNW7ZSSXY77	1	USER_LOGGED_IN	2026-01-10 08:52:49.568	2026-01-10 08:52:49.568	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEKHQD90DMNR9X9JAAVPWZD4	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk82hnve000mrlysqfah52qq", "payloadVersion": 1}
01KEKHQF5ED9JMCKZ4F5WS3PEJ	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:52:51.502	2026-01-10 08:52:51.503	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHQF5EGM6ES2QBNF1XH9QM	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKHQZGQQAMHTRBDB3MX3ZFA	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:53:08.246	2026-01-10 08:53:08.247	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHQZGPE4KD91CCCZ7957QT	{"action": "NDA_UPDATE", "targetId": "cmk82gx3b000frlyscetkmbm9", "targetType": "NDA", "payloadVersion": 1}
01KEKHQZK4PH8E1EH40PRBRKQG	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:53:08.324	2026-01-10 08:53:08.324	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHQZK4HKQ5H3Y8JTX0MY89	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKHR59B28FAFF4WBFN2Y229	1	USER_LOGGED_OUT	2026-01-10 08:53:14.155	2026-01-10 08:53:14.155	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEKHR59BSH2MW9VBJZ4KTJZN	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk82hnve000mrlysqfah52qq", "payloadVersion": 1}
01KEKHR8PED1RSN5Q5T4TGQWVA	1	USER_LOGGED_IN	2026-01-10 08:53:17.646	2026-01-10 08:53:17.646	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKHR8PEZYN5KNY5FBQ7ZKT8	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk82i9je000qrlysgwj0nipr", "payloadVersion": 1}
01KEKHRD74SHM2W596QD6F2NER	1	USER_LOGGED_OUT	2026-01-10 08:53:22.276	2026-01-10 08:53:22.276	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKHRD74C0SKSSGZE90WDFWP	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk82i9je000qrlysgwj0nipr", "payloadVersion": 1}
01KEKHRGDCCPF6K2AMFBWC2BD1	1	USER_LOGGED_IN	2026-01-10 08:53:25.547	2026-01-10 08:53:25.548	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEKHRGDB2V1M08GFZNM2NYV8	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk82ifmv000trlysqp3nmard", "payloadVersion": 1}
01KEKHRJ1VRJBNJ7H74CZNJDFD	1	PLATFORM_ADMIN_AUDIT	2026-01-10 08:53:27.227	2026-01-10 08:53:27.227	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKHRJ1V7M0SR33EQ3RBY73F	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKK3WJ7G3J0XRY5ZBGN1KVT	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:17:07.014	2026-01-10 09:17:07.015	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKK3WJ6MPHW4SVG25A9V0NM	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKK3XZY346VCSWE9ZAWVSXF	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:17:08.477	2026-01-10 09:17:08.478	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKK3XZXBCFBZKTPV9A413VE	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKK3YNZJH0FN4WYNKZEBXAN	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:17:09.182	2026-01-10 09:17:09.183	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKK3YNYXE4Q7N6BGGF6R4KE	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKK41TXDSWFV0JYQDPEWVS3	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:17:12.413	2026-01-10 09:17:12.413	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKK41TXEJPBN0PTV9DBW869	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKK7G45X0K94E7V2GF23WCH	1	USER_LOGGED_IN	2026-01-10 09:19:05.349	2026-01-10 09:19:05.349	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKK7G45N8VMZDKF4TM2PE17	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk83ffqy000wrlysit0p92zf", "payloadVersion": 1}
01KEKK9A42T1F29WBQ8RR75F7K	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:20:04.738	2026-01-10 09:20:04.739	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKK9A42HKW3AK770H6ZVQ5S	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKK9BKZ640GJS8VBZ8PQ2QZ	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:20:06.27	2026-01-10 09:20:06.271	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKK9BKYVF7JQZYZHN7VZXHH	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKK9EA066AS98M6SVCAY7GV	1	USER_LOGGED_OUT	2026-01-10 09:20:09.023	2026-01-10 09:20:09.024	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEKK9EA0RD4R8MYWFHMWHF3K	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk82ifmv000trlysqp3nmard", "payloadVersion": 1}
01KEKK9GC8GRHMZXX6HF2MXPTA	1	USER_LOGGED_IN	2026-01-10 09:20:11.143	2026-01-10 09:20:11.144	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEKK9GC7CKND0P6Z796XSHSP	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk83guiq0002fbz0r3wfku9a", "payloadVersion": 1}
01KEKK9J3T2CN2B0YKQ726B4Q5	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:20:12.922	2026-01-10 09:20:12.922	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKK9J3T9CCW3Y5GYHKWRVKZ	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKKBHM6A88VE2WDXGSCE2BX	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:21:17.958	2026-01-10 09:21:17.958	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKBHM6GAE3V5WZYDYNVN4J	{"action": "NDA_UPDATE", "targetId": "cmk82fv01000drlysjzro5gr6", "targetType": "NDA", "payloadVersion": 1}
01KEKKBHPVMWQ0WT31FZ1SD375	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:21:18.043	2026-01-10 09:21:18.043	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKBHPV3M6TKBAGBQ50Z0BD	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKKCF802KMZDVZ0X15FSNR9	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:21:48.288	2026-01-10 09:21:48.288	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKCF8086P4RNZSAQAEFAXB	{"action": "NDA_UPDATE", "targetId": "cmk82gx3b000frlyscetkmbm9", "targetType": "NDA", "payloadVersion": 1}
01KEKKCFAET0B7C0K1H73W3NQ0	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:21:48.366	2026-01-10 09:21:48.366	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKCFAEJ3CYB8XXVEBW5DZG	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKKE4NHRKD00B44JC6YEVS9	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:22:42.993	2026-01-10 09:22:42.994	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKE4NH3BKB8A8H3SEQAZ5D	{"action": "NDA_UPDATE", "targetId": "cmk82gx3b000frlyscetkmbm9", "targetType": "NDA", "payloadVersion": 1}
01KEKKE4R81TE7PMQ6MGSVYVS6	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:22:43.079	2026-01-10 09:22:43.08	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKE4R7EHRR8HF2XZ5QY3CD	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKKENZSEK0R3RN6CEFSWZ5A	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:23:00.729	2026-01-10 09:23:00.729	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKENZSH8AJ3ZNMDK1J1VAB	{"action": "NDA_UPDATE", "targetId": "cmk82fv01000drlysjzro5gr6", "targetType": "NDA", "payloadVersion": 1}
01KEKKEP29WDWCCQW5HAXRXAJ7	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:23:00.808	2026-01-10 09:23:00.809	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKEP28ZFJPA2CKAZ2B0RX6	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKKFBP1MT3NP7WA5QC2SGAX	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:23:22.944	2026-01-10 09:23:22.945	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKFBP0MRQ5H3J4N7TG2P60	{"action": "NDA_UPDATE", "targetId": "cmk82gx3b000frlyscetkmbm9", "targetType": "NDA", "payloadVersion": 1}
01KEKKFBRG499EWG16Y5AHWXPG	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:23:23.024	2026-01-10 09:23:23.024	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKFBRGS4JAEM1N8ZBBW6ZQ	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 2, "payloadVersion": 1}
01KEKKGN0QMAG3PBWEQZFXBA5N	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:24:05.271	2026-01-10 09:24:05.271	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKGN0Q2FRW8V2XJ9TAEHZA	{"action": "NDA_CREATE", "targetId": "cmk83lv680009fbz0rv7s91fk", "targetType": "NDA", "payloadVersion": 1}
01KEKKGN3838DPAKC31T7A0H61	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:24:05.351	2026-01-10 09:24:05.352	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKKGN37KYMB13VMWZA54EGD	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEKMR007DZ7WJB8PWM6CYK3H	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:45:34.47	2026-01-10 09:45:34.471	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKMR0068VDE4DR8XD9JP993	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEKNHNAWHC38H73XEHC0ACJT	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:59:35.515	2026-01-10 09:59:35.516	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKNHNAVH81B1KZSZZNM5096	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEKNHQHNPY7CKB4QGHGTZK0V	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:59:37.781	2026-01-10 09:59:37.781	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKNHQHN2HR2RJZX50X0Y70B	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEKNHSZNZYJJ772MKBHHQKHJ	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:59:40.277	2026-01-10 09:59:40.277	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKNHSZNZ5X2YWW6Y87P1E02	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEKNHSZSS1AVY2BFECW61ZYF	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:59:40.281	2026-01-10 09:59:40.281	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKNHSZSZRQ8Y1CG8RX27PX5	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEKNHW3FDJ23C3ASWKNGT8MB	1	PLATFORM_ADMIN_AUDIT	2026-01-10 09:59:42.447	2026-01-10 09:59:42.447	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKNHW3FYBBQMTT9AJJ229MM	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEKNK9D7060FTEKP8YR6D653	1	ATTACHMENT_DOWNLOADED	2026-01-10 10:00:28.839	2026-01-10 10:00:28.839	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	de3d27d3-23a2-4a68-afb5-6c7c0d835d7a	CLARIFY	NEW	api	4e230380-4bd7-44ca-b22a-2d85fbe9f7fc	{"via": "owner", "intentId": "cmk5tzxoz000o1341jzo45i8m", "attachmentId": "de3d27d3-23a2-4a68-afb5-6c7c0d835d7a", "payloadVersion": 1}
01KEKNKM6XY338TZ3DHMQS7RHN	1	ATTACHMENT_DOWNLOADED	2026-01-10 10:00:39.901	2026-01-10 10:00:39.902	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	28186488-2989-428f-8b96-a7db41abf6a5	CLARIFY	NEW	api	2e6aff62-eab4-4fc0-b48a-3167412171f8	{"via": "owner", "intentId": "cmk5tzxoz000o1341jzo45i8m", "attachmentId": "28186488-2989-428f-8b96-a7db41abf6a5", "payloadVersion": 1}
01KEKXB9TR1FGTCWD5BD9HTWBS	1	USER_LOGGED_IN	2026-01-10 12:15:55.736	2026-01-10 12:15:55.736	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKXB9TR0CTDG4PQA7B7AYA5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk89qury0002s35hmghae2jo", "payloadVersion": 1}
01KEKXCH5YR3HYX8HZZ3AD1AY6	1	USER_LOGGED_IN	2026-01-10 12:16:36.03	2026-01-10 12:16:36.03	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKXCH5YXA4KT1R2SYCG7A83	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk89rpv90005s35ht732uyrz", "payloadVersion": 1}
01KEKXDNBBP9R39AV16GNE2SSZ	1	USER_LOGGED_IN	2026-01-10 12:17:13.066	2026-01-10 12:17:13.067	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKXDNBA2AJJJMFSJCP807D8	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk89sig50008s35hualp8yl5", "payloadVersion": 1}
01KEKXJMCF3HBABNFY3P6NJH6N	1	USER_LOGGED_OUT	2026-01-10 12:19:55.919	2026-01-10 12:19:55.919	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKXJMCFA5MMC7XDGMRBXK9Z	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk83ffqy000wrlysit0p92zf", "payloadVersion": 1}
01KEKXJQEN38B42RXK4Z0B8ZBZ	1	USER_LOGGED_IN	2026-01-10 12:19:59.061	2026-01-10 12:19:59.061	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKXJQEN9ME54B14ZSJMH6NH	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk89w2j4000bs35hrsngezkb", "payloadVersion": 1}
01KEKXJSHWJF8MKC1A4PXS6E8A	1	USER_LOGGED_OUT	2026-01-10 12:20:01.211	2026-01-10 12:20:01.212	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKXJSHVKQ90HPR7B38PSPEG	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk89w2j4000bs35hrsngezkb", "payloadVersion": 1}
01KEKXK4354TRB112DWR10DJ34	1	USER_LOGGED_IN	2026-01-10 12:20:12.004	2026-01-10 12:20:12.005	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKXK434220GXNJM52KVNYGQ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk89wcil000es35hdrkydlpe", "payloadVersion": 1}
01KEKXN5ZRYAPRNGQFJPMBMZWS	1	USER_LOGGED_IN	2026-01-10 12:21:19.48	2026-01-10 12:21:19.48	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKXN5ZRPZ0M7YTNHVJ87TS6	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk89xsky000hs35h8208f760", "payloadVersion": 1}
01KEKXNYN20TAJ7G39VB6JJ4AH	1	USER_LOGGED_IN	2026-01-10 12:21:44.737	2026-01-10 12:21:44.738	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKXNYN190SSFZ1Q6KVZF7KA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk89yc2k000ks35h7bng4iv4", "payloadVersion": 1}
01KEKXSZYH1Y05HCBP4YEP8Z1R	1	USER_LOGGED_IN	2026-01-10 12:23:57.137	2026-01-10 12:23:57.137	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKXSZYH824ZN3W40SA74PCQ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8a168d000ns35hknovuowo", "payloadVersion": 1}
01KEKY0PVWASM85SPQT6ABHMT8	1	USER_LOGGED_IN	2026-01-10 12:27:37.211	2026-01-10 12:27:37.212	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKY0PVVHFV3KBVY1CZWXKN3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8a5w1h000qs35hpapzye0b", "payloadVersion": 1}
01KEKYK96KCTKANBKW4AY4TC7D	1	USER_LOGGED_IN	2026-01-10 12:37:45.81	2026-01-10 12:37:45.811	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKYK96J2W659SNFHHAQ8MTZ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8aixmy0002h9jo855n4iit", "payloadVersion": 1}
01KEKYQ2H7NSFPD676Z3GEPNGY	1	USER_LOGGED_IN	2026-01-10 12:39:50.054	2026-01-10 12:39:50.055	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKYQ2H69RWBNAH0Z8R0GWG8	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8allia0005h9johqfg845v", "payloadVersion": 1}
01KEKYQXHN1Z5K8C30NFKTK9AX	1	USER_LOGGED_IN	2026-01-10 12:40:17.717	2026-01-10 12:40:17.717	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKYQXHNTGYFNNHNJQFV6DWZ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8am6un0008h9jo9yftnis4", "payloadVersion": 1}
01KEKYRKE2ZEFZE2KMPQ507QC5	1	USER_LOGGED_IN	2026-01-10 12:40:40.129	2026-01-10 12:40:40.13	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKYRKE15R23B7EPQCD29RPQ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8amo59000bh9joz6i1apfq", "payloadVersion": 1}
01KEKYSHCYSTHXMMX7CTF9VFA6	1	USER_LOGGED_IN	2026-01-10 12:41:10.814	2026-01-10 12:41:10.814	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKYSHCY4V28MDT6CPSA58KY	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8anbtl000eh9joy9ddbaki", "payloadVersion": 1}
01KEKYTDM4AF5NHBJVR36Q7PNE	1	USER_LOGGED_IN	2026-01-10 12:41:39.716	2026-01-10 12:41:39.716	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKYTDM4PAKGC0RZYM753BVV	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8any4h000hh9jo3au35fht", "payloadVersion": 1}
01KEKYVWAZ2348TPVW19GR212V	1	USER_LOGGED_IN	2026-01-10 12:42:27.55	2026-01-10 12:42:27.551	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKYVWAYBPQNDD4KEFXZY0YV	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8aoz15000kh9joy71uwkzg", "payloadVersion": 1}
01KEKYYGZ0CPKRD30JBWK2ESXH	1	PLATFORM_ADMIN_AUDIT	2026-01-10 12:43:54.208	2026-01-10 12:43:54.209	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEKYYGZ07CQ6ZX4F1GQSZ72V	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEKYYJX3Y05SHBSV40RTZKV0	1	USER_LOGGED_OUT	2026-01-10 12:43:56.194	2026-01-10 12:43:56.195	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEKYYJX224H5P9VNG2GWR5E0	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk83guiq0002fbz0r3wfku9a", "payloadVersion": 1}
01KEKZ0VPV9B9Z0X6TNWE9K9X8	1	USER_LOGGED_IN	2026-01-10 12:45:10.747	2026-01-10 12:45:10.747	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEKZ0VPVG6ANXMBM9F2NZBBA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8asgyf000nh9jo11oqdfo0", "payloadVersion": 1}
01KEKZ0WND4REW5XAVVCJA39CD	1	USER_LOGGED_IN	2026-01-10 12:45:11.725	2026-01-10 12:45:11.725	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEKZ0WNDE9ZCAY38Q68QYQ6T	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8ashpk000qh9jo6yqwx79i", "payloadVersion": 1}
01KEMS1M9TD9DCRYRSXSZSNK20	1	USER_LOGGED_OUT	2026-01-10 20:19:58.906	2026-01-10 20:19:58.906	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEMS1M9T9C6Q6NPZMD7Z5DGB	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk89wcil000es35hdrkydlpe", "payloadVersion": 1}
01KEMS1TR82C1D56XYC6GSXNP8	1	USER_LOGGED_IN	2026-01-10 20:20:05.511	2026-01-10 20:20:05.512	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEMS1TR8C5S92BTY0EYT7DVK	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8r1hq7000th9jop6df6c0m", "payloadVersion": 1}
01KEMS21F2Z76RPJRY55MDYCEX	1	USER_LOGGED_IN	2026-01-10 20:20:12.385	2026-01-10 20:20:12.386	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEMS21F1PXR62B40JTNNN4E6	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmk8r1n19000wh9jo3gld9uqq", "payloadVersion": 1}
01KEMS237YRT4WQWM7BAESN7RM	1	PLATFORM_ADMIN_AUDIT	2026-01-10 20:20:14.206	2026-01-10 20:20:14.207	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEMS237YH4NT30712PTPWH45	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEMS727FANGGS1VNNXNS7JS6	1	USER_LOGGED_IN	2026-01-10 20:22:57.007	2026-01-10 20:22:57.007	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEMS727F51003685WX9562TM	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmk8r5623000zh9jo2ybc21o9", "payloadVersion": 1}
01KEMS72RZD2YSVJDRC9SGGH1S	1	USER_LOGGED_IN	2026-01-10 20:22:57.567	2026-01-10 20:22:57.567	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMS72RZTCA8ZMEWGWH4KJ4R	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8r56hm0012h9jos6qsy7e8", "payloadVersion": 1}
01KEMSJAJWM31EHXA6YJE0GA7V	1	USER_LOGGED_IN	2026-01-10 20:29:06.012	2026-01-10 20:29:06.012	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSJAJWWQ3TVNMMC8V6VYW9	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rd2s60015h9joav4q9f6p", "payloadVersion": 1}
01KEMSM33KT60F7SP9QEGJ40J9	1	USER_LOGGED_IN	2026-01-10 20:30:03.89	2026-01-10 20:30:03.891	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSM33J2Y4BW8XTMFQ4NDVS	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rebfw0018h9jo0wki4h3c", "payloadVersion": 1}
01KEMSMM5FBSNFN2BJQRS4Q6GN	1	USER_LOGGED_IN	2026-01-10 20:30:21.359	2026-01-10 20:30:21.359	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSMM5F1BXN254S9113X6GT	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8reox5001bh9joiadwecqx", "payloadVersion": 1}
01KEMSNB0D7RYGWAAVDFN4DM3Q	1	USER_LOGGED_IN	2026-01-10 20:30:44.749	2026-01-10 20:30:44.749	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSNB0DE9K0NHJMCJ79WQMJ	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rf6yx001eh9jo978e7t8y", "payloadVersion": 1}
01KEMSNWK353MWZ2R8Z8C3TKBS	1	USER_LOGGED_IN	2026-01-10 20:31:02.754	2026-01-10 20:31:02.755	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSNWK267YJ68HDMC2WGZD9	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rfkv1001hh9jo73448hns", "payloadVersion": 1}
01KEMSPJYS9QTYHQ66FV2Z49CN	1	USER_LOGGED_IN	2026-01-10 20:31:25.657	2026-01-10 20:31:25.657	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSPJYS0ZKKKZ9MZZ10KJJB	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rg2j6001kh9jonvhzaat5", "payloadVersion": 1}
01KEMSQCYPTEPX0CT9Z5TSFMXK	1	USER_LOGGED_IN	2026-01-10 20:31:52.278	2026-01-10 20:31:52.278	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSQCYPJPZDGMF83T5YNR4P	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rgn2p001nh9jor2eog6mb", "payloadVersion": 1}
01KEMSR42DQ6RNHMWDHRWSBP54	1	USER_LOGGED_IN	2026-01-10 20:32:15.949	2026-01-10 20:32:15.949	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSR42DXY2S8DCKK0SKA66T	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rh5c5001qh9joiyd1wu0l", "payloadVersion": 1}
01KEMSRP69H1772KHDVE2VH6B2	1	USER_LOGGED_IN	2026-01-10 20:32:34.505	2026-01-10 20:32:34.505	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSRP6965FKA9XKDRJR19FD	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rhjnn001th9joek34qrpi", "payloadVersion": 1}
01KEMSS95R7M1XGGH4KBWHY335	1	USER_LOGGED_IN	2026-01-10 20:32:53.944	2026-01-10 20:32:53.945	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSS95RB9NPZ1VSV2Q65QPC	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rhynm001wh9jo7qwix3ai", "payloadVersion": 1}
01KEMSTPRPJH38HY9SJ7ZXVVC5	1	USER_LOGGED_IN	2026-01-10 20:33:40.63	2026-01-10 20:33:40.631	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSTPRP7FME5NC7J7FQJ437	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8riyoi001zh9jo7i5lea8v", "payloadVersion": 1}
01KEMSVRCJBCF92Z40VZ1T2A78	1	USER_LOGGED_IN	2026-01-10 20:34:15.058	2026-01-10 20:34:15.058	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSVRCJV7179PJMQ1PQZKJ7	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rjp8s0022h9joclq85fo8", "payloadVersion": 1}
01KEMSWBFNPEYRWQTWQGZN9E9Y	1	USER_LOGGED_IN	2026-01-10 20:34:34.613	2026-01-10 20:34:34.614	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSWBFNKKWD3RZP8AANZR9S	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rk4c10025h9jon6l7glw8", "payloadVersion": 1}
01KEMSXQE4J3AEFQ8SV6YDVFWD	1	USER_LOGGED_IN	2026-01-10 20:35:19.62	2026-01-10 20:35:19.62	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KEMSXQE4ZDXE3GMMEY9Z2K8S	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmk8rl3280028h9jof5odt6gy", "payloadVersion": 1}
01KEMVBFE2EG7YDX32M7NENVYW	1	PLATFORM_ADMIN_AUDIT	2026-01-10 21:00:18.754	2026-01-10 21:00:18.755	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEMVBFE2F0GCCQBH7K0HC2MP	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEMVC5P2PM22SZBMJ5PFDW31	1	PLATFORM_ADMIN_AUDIT	2026-01-10 21:00:41.538	2026-01-10 21:00:41.538	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEMVC5P2RR5MCTA8XMWEW096	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEMVF9HDWC67QSCK2A6XR3C5	1	INTENT_UPDATED	2026-01-10 21:02:23.784	2026-01-10 21:02:23.789	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KEMVF9HDCY19165V3JKCN5ZB	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "changeSummary": "Pipeline stage changed from COMMIT to MATCH", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEMVFBHZK69FTEZ0557KAQG0	1	INTENT_UPDATED	2026-01-10 21:02:25.852	2026-01-10 21:02:25.855	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tiyvu000j1341uqwwes3f	MATCH_ALIGN	MATCH	ui	01KEMVFBHZ7QQ8CQ6GJCGJ1AX1	{"intentId": "cmk5tiyvu000j1341uqwwes3f", "changeSummary": "Pipeline stage changed from CLARIFY to MATCH", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEMVFF6NPMPZ6S3QZ4WJGRGW	1	INTENT_UPDATED	2026-01-10 21:02:29.584	2026-01-10 21:02:29.589	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	COMMIT_ASSURE	COMMIT	ui	01KEMVFF6N5BGS03CEVK5X30PX	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "changeSummary": "Pipeline stage changed from MATCH to COMMIT", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KEMVFH7EXWKV3ARWNRCEPCQH	1	INTENT_UPDATED	2026-01-10 21:02:31.654	2026-01-10 21:02:31.662	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KEMVFH7D41VFDTRG47K07PXM	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "changeSummary": "Pipeline stage changed from COMMIT to MATCH", "changedFields": ["pipelineStage"], "payloadVersion": 1}
01KERVR7PAZ3T70XS0Q46PNWGN	1	USER_LOGGED_IN	2026-01-12 10:24:14.537	2026-01-12 10:24:14.538	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERVR7P9WH70VT0PAHNPBR3Z	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb0mxfh00025otl9457mxta", "payloadVersion": 1}
01KERXGHTGM6WGD26NHVHG82M3	1	ATTACHMENT_DOWNLOADED	2026-01-12 10:54:59.92	2026-01-12 10:54:59.921	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	ATTACHMENT	de3d27d3-23a2-4a68-afb5-6c7c0d835d7a	CLARIFY	NEW	api	7b3f55dc-fe26-4613-8953-c8a206010908	{"via": "owner", "intentId": "cmk5tzxoz000o1341jzo45i8m", "attachmentId": "de3d27d3-23a2-4a68-afb5-6c7c0d835d7a", "payloadVersion": 1}
01KERXJGVY4RQVZT7FKT97KN19	1	USER_LOGGED_OUT	2026-01-12 10:56:04.478	2026-01-12 10:56:04.478	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERXJGVYGYA5T09GABNE3AR1	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb0mxfh00025otl9457mxta", "payloadVersion": 1}
01KERXJK8RF5RSZXEWNYJ8HHBS	1	USER_LOGGED_IN	2026-01-12 10:56:06.936	2026-01-12 10:56:06.937	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERXJK8RPG839E6SFT102MKQ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb1rx1q0002f1s98g9d72yz", "payloadVersion": 1}
01KERXK5XWGXH5922RAADMC5Y5	1	USER_LOGGED_OUT	2026-01-12 10:56:26.043	2026-01-12 10:56:26.044	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERXK5XVMJ9KYQ8Y3G6XNVRV	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb1rx1q0002f1s98g9d72yz", "payloadVersion": 1}
01KERXK952TJRGMG1WBKNXXAN0	1	USER_LOGGED_IN	2026-01-12 10:56:29.346	2026-01-12 10:56:29.346	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KERXK952YSAMV0GBYBN3YBCR	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkb1seca0005f1s9gdrpnwvy", "payloadVersion": 1}
01KERXKB9J64XKH29R0GDRYQW0	1	PLATFORM_ADMIN_AUDIT	2026-01-12 10:56:31.538	2026-01-12 10:56:31.539	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KERXKB9JSQJ26FS35VJ27ZA7	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KERXKGFDVC1N4ZF4TPVGNAQR	1	USER_LOGGED_OUT	2026-01-12 10:56:36.844	2026-01-12 10:56:36.845	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KERXKGFC8BZ5BF1WQAN94B7T	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkb1seca0005f1s9gdrpnwvy", "payloadVersion": 1}
01KERXKP91WF3PPV1ENJ8XB8SQ	1	USER_LOGGED_IN	2026-01-12 10:56:42.785	2026-01-12 10:56:42.785	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERXKP91Y1JHNEKC5BZYK1BJ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb1sopn0008f1s92g2qtwtt", "payloadVersion": 1}
01KERYY7RQA4TT98P3GBNJ11B6	1	USER_LOGGED_OUT	2026-01-12 11:19:56.951	2026-01-12 11:19:56.951	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERYY7RQN1W95J50MGXG0D7Y	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb1sopn0008f1s92g2qtwtt", "payloadVersion": 1}
01KERYY9WCWDYCDYZ9HJA7M76C	1	USER_LOGGED_IN	2026-01-12 11:19:59.116	2026-01-12 11:19:59.116	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERYY9WCJPJ765DA8G0F26J5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb2mm4m000bf1s9i9qa2btr", "payloadVersion": 1}
01KERZ81GFYD1WWRPAB531WTFV	1	USER_LOGGED_OUT	2026-01-12 11:25:18.223	2026-01-12 11:25:18.223	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERZ81GFABAAB0J8G38KQTTW	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb2mm4m000bf1s9i9qa2btr", "payloadVersion": 1}
01KERZ848WNPSPK9X79507YYD9	1	USER_LOGGED_IN	2026-01-12 11:25:21.051	2026-01-12 11:25:21.052	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERZ848VG4TA6RMHB9929K20	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb2tij9000ef1s9099k2903", "payloadVersion": 1}
01KERZ8J486DCB0QPR0SJ163TR	1	USER_LOGGED_OUT	2026-01-12 11:25:35.24	2026-01-12 11:25:35.24	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERZ8J486PGQ8FWP81VQS9WB	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb2tij9000ef1s9099k2903", "payloadVersion": 1}
01KERZ8NEM1EQDXJTB5HDHVT1C	1	USER_LOGGED_IN	2026-01-12 11:25:38.644	2026-01-12 11:25:38.644	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERZ8NEM2FW42ZXMBNDC48ZJ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb2tw3z000hf1s90mb6xfsm", "payloadVersion": 1}
01KERZ8VD931BZKRVC1Q6BCAAP	1	USER_LOGGED_OUT	2026-01-12 11:25:44.744	2026-01-12 11:25:44.745	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERZ8VD8HHFTF3D71WNFCXK1	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb2tw3z000hf1s90mb6xfsm", "payloadVersion": 1}
01KERZ9Q619WH2QDYCWSJ5AQTF	1	USER_LOGGED_IN	2026-01-12 11:26:13.185	2026-01-12 11:26:13.185	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERZ9Q610PWH37JA0Q9RW7ZD	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb2umrh000kf1s9wh2bjf94", "payloadVersion": 1}
01KERZGEXE3XRC1BBYH6JDXXH9	1	USER_LOGGED_OUT	2026-01-12 11:29:54.094	2026-01-12 11:29:54.095	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERZGEXEJE6J2E897J41JJ62	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb2umrh000kf1s9wh2bjf94", "payloadVersion": 1}
01KERZHENV7ZE1NQCF3C7M7Z0N	1	USER_LOGGED_IN	2026-01-12 11:30:26.619	2026-01-12 11:30:26.619	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KERZHENV4PC5KB1Y12EW8NQZ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb302b9000nf1s91o98vfma", "payloadVersion": 1}
01KES20VJDGZVE2AHPW1BYCJJX	1	USER_LOGGED_OUT	2026-01-12 12:13:48.492	2026-01-12 12:13:48.493	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KES20VJC1SRWCENF4PPP3CSG	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb302b9000nf1s91o98vfma", "payloadVersion": 1}
01KES20XMDMGFE0GJ6XCEWN3B6	1	USER_LOGGED_IN	2026-01-12 12:13:50.605	2026-01-12 12:13:50.605	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KES20XMD20F52H3TKYSA7RC9	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb4jvk6001nf1s9eydw3jly", "payloadVersion": 1}
01KES5KTPNAETN57F22CQ9EXH7	1	USER_LOGGED_OUT	2026-01-12 13:16:35.923	2026-01-12 13:16:35.925	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KES5KTPKVQ0YQKFKP59DJ34W	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb4jvk6001nf1s9eydw3jly", "payloadVersion": 1}
01KES5KXKN53HVCRNN2H6BEQHB	1	USER_LOGGED_IN	2026-01-12 13:16:38.901	2026-01-12 13:16:38.901	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KES5KXKNTQSAA9F7WRZQ07K1	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb6sn70000212gfzaj6v9k0", "payloadVersion": 1}
01KES5N7GFZB1HX5W6RRGS2PA3	1	INTENT_CREATED	2026-01-12 13:17:21.797	2026-01-12 13:17:21.807	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KES5N7GFHT9DX49K7D9KB9GN	{"kpi": "kpi", "goal": "goal", "risks": "risk", "scope": "scope", "title": "goal", "source": "manual", "context": "contects", "intentId": "cmkb6tkau000412gfjnhadidf", "language": "EN", "deadlineAt": "2026-01-31T00:00:00.000Z", "payloadVersion": 1, "confidentialityLevel": "L1"}
01KESEN24B4M0W5C42DHM5H3AB	1	USER_LOGGED_OUT	2026-01-12 15:54:33.482	2026-01-12 15:54:33.484	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESEN24B3G3N2F9TGFDMFF7R	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkb6sn70000212gfzaj6v9k0", "payloadVersion": 1}
01KESFKQF5ZN21ZK7W2PRPNPVZ	1	USER_LOGGED_IN	2026-01-12 16:11:18.372	2026-01-12 16:11:18.373	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESFKQF5EF1PN1KJ76SR8DWD	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbd197f00027bo9zmv74p2a", "payloadVersion": 1}
01KESFMVS6M5ZB8QT8HSAMAVA4	1	INTENT_VIEWED	2026-01-12 16:11:55.558	2026-01-12 16:11:55.559	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KESFMVS6KPN9M5FTEWG489R3	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KESFSN66AQR7908F3H3FWTSZ	1	USER_LOGGED_OUT	2026-01-12 16:14:32.645	2026-01-12 16:14:32.646	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESFSN65X87PM5SJ2SAYS4EH	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbd197f00027bo9zmv74p2a", "payloadVersion": 1}
01KESGDR9CGXQ8XP1VE4CQQ1JJ	1	USER_LOGGED_IN	2026-01-12 16:25:31.179	2026-01-12 16:25:31.18	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESGDR9BKZPMR3KTPH4T86XN	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbdjj8i00023q034u8bzu5w", "payloadVersion": 1}
01KESGE3VWFY73AHR7Q4VDYYKM	1	USER_LOGGED_OUT	2026-01-12 16:25:43.035	2026-01-12 16:25:43.036	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESGE3VVH55TS2J3D364TPCY	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbdjj8i00023q034u8bzu5w", "payloadVersion": 1}
01KESH93GJRM6JKFGVP3KK7F3B	1	USER_LOGGED_IN	2026-01-12 16:40:27.41	2026-01-12 16:40:27.411	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESH93GJBECZAP09XPXYBZZ5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbe2qrr000238rpr75nf4fo", "payloadVersion": 1}
01KESH96T8T66P9DM9WGCR4M4T	1	INTENT_VIEWED	2026-01-12 16:40:30.792	2026-01-12 16:40:30.792	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KESH96T7611JX182Y2BZGV9N	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KESK73FJCEF954BCS1VPVCC9	1	INTENT_VIEWED	2026-01-12 17:14:18.994	2026-01-12 17:14:18.994	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KESK73FHAS7ZSMSK3M54N8QR	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KESK7PZHK420CSH1RDKS8YMZ	1	INTENT_VIEWED	2026-01-12 17:14:38.961	2026-01-12 17:14:38.961	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KESK7PZGT1C5EMDH4AX8BJRZ	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KESK88FS1THS04S59PF92BC5	1	INTENT_VIEWED	2026-01-12 17:14:56.889	2026-01-12 17:14:56.889	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KESK88FRXHWC6H3SCMKMP6NK	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KESK9RWMPR9JFA8DMX5X6D2G	1	INTENT_VIEWED	2026-01-12 17:15:46.452	2026-01-12 17:15:46.452	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5jhwcq0006bdrsvh8hnxme	CLARIFY	CLARIFY	ui	01KESK9RWKPPYTDVQQQBQB746E	{"intentId": "cmk5jhwcq0006bdrsvh8hnxme", "viewContext": "owner", "payloadVersion": 1}
01KESK9Z6RHC3NSRX8K8E51X95	1	INTENT_VIEWED	2026-01-12 17:15:52.92	2026-01-12 17:15:52.92	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5jhwcq0006bdrsvh8hnxme	CLARIFY	CLARIFY	ui	01KESK9Z6QYXJCRM2HE6YYS4QN	{"intentId": "cmk5jhwcq0006bdrsvh8hnxme", "viewContext": "owner", "payloadVersion": 1}
01KESKA3VZZCTNP2CRTA3218MQ	1	INTENT_VIEWED	2026-01-12 17:15:57.695	2026-01-12 17:15:57.695	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KESKA3VZY57A5BJMWF0DS6RV	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "viewContext": "owner", "payloadVersion": 1}
01KESNACBHG6HC5E8QZW07RG6W	1	INTENT_VIEWED	2026-01-12 17:51:03.537	2026-01-12 17:51:03.537	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KESNACBHW0C609JGRT0YPGH5	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "viewContext": "owner", "payloadVersion": 1}
01KESNM7B17FMEJGJ00H7GC7QE	1	USER_LOGGED_OUT	2026-01-12 17:56:26.08	2026-01-12 17:56:26.081	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESNM7B0PAEHBYA91CG00PGA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbe2qrr000238rpr75nf4fo", "payloadVersion": 1}
01KESQAGRACTAGANKMFE77MAWJ	1	USER_LOGGED_IN	2026-01-12 18:26:05.194	2026-01-12 18:26:05.195	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESQAGRAYS01S93CCPW8NPE0	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbhul1a00028oa5dj2eexth", "payloadVersion": 1}
01KESQAR8Q1BKT19Y70FXZGNDK	1	USER_LOGGED_OUT	2026-01-12 18:26:12.886	2026-01-12 18:26:12.887	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESQAR8PB4CNWB7QZ1FQ9BE4	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbhul1a00028oa5dj2eexth", "payloadVersion": 1}
01KESQCD2E5CCNFY2DAJ9ZY0F0	1	USER_LOGGED_IN	2026-01-12 18:27:06.958	2026-01-12 18:27:06.958	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESQCD2E0T1DK3D72ZETK51M	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbhvwp500058oa5qdon63nv", "payloadVersion": 1}
01KESQDNCYVH65CVWNA06G75EK	1	USER_LOGGED_OUT	2026-01-12 18:27:48.253	2026-01-12 18:27:48.254	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESQDNCX4BFJCSEMDFWG6Q53	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbhvwp500058oa5qdon63nv", "payloadVersion": 1}
01KESQRK72BYFT1REDBYQEA0SE	1	USER_LOGGED_IN	2026-01-12 18:33:46.465	2026-01-12 18:33:46.466	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESQRK7214F0GP4QX1T54XH2	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbi4gyj00088oa51i2afub4", "payloadVersion": 1}
01KESRRVSQNZ1QRVSTR98Z0W9J	1	USER_LOGGED_OUT	2026-01-12 18:51:23.831	2026-01-12 18:51:23.831	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESRRVSQTAWBYHFEYJ0AQMJ2	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbi4gyj00088oa51i2afub4", "payloadVersion": 1}
01KESS67YSJ943B6RSMDXWWTNX	1	USER_LOGGED_IN	2026-01-12 18:58:42.264	2026-01-12 18:58:42.265	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESS67YRC5Z994MNFMBSGK8E	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbj0j4g0002v00lj65iwb1j", "payloadVersion": 1}
01KESS6JSB8N678T34B7TBWE4E	1	INTENT_VIEWED	2026-01-12 18:58:53.355	2026-01-12 18:58:53.355	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KESS6JSA2W4MPAEG70PHJTWZ	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KESVMZEREWCGHZ43WAW1JD97	1	INTENT_VIEWED	2026-01-12 19:41:42.232	2026-01-12 19:41:42.232	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KESVMZEQ8W3G81DKQZJFDSW5	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KESVN7A21A68C4MGKFXZBQJH	1	INTENT_VIEWED	2026-01-12 19:41:50.274	2026-01-12 19:41:50.274	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KESVN7A29JH0E3Z7M8A5ZVSY	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "viewContext": "owner", "payloadVersion": 1}
01KESVNJWZ1B91NT52SBNHBPGJ	1	INTENT_VIEWED	2026-01-12 19:42:02.143	2026-01-12 19:42:02.143	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KESVNJWZE6QWVKB442R414EV	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "viewContext": "owner", "payloadVersion": 1}
01KESW0RP1ENPBZTDKKGWH0604	1	INTENT_VIEWED	2026-01-12 19:48:08.513	2026-01-12 19:48:08.513	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KESW0RP1Q6KGSAKQKM0AHM0K	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KESW1QDPEMN9SGF1H2FBQZTY	1	INTENT_VIEWED	2026-01-12 19:48:39.99	2026-01-12 19:48:39.99	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KESW1QDNBA2E4RKZE8DKDW17	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "viewContext": "owner", "payloadVersion": 1}
01KESX2YQ3MV4A0TR370PMNA46	1	USER_LOGGED_OUT	2026-01-12 20:06:48.802	2026-01-12 20:06:48.803	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESX2YQ2CQFJFBVE6AKVFAKS	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkbj0j4g0002v00lj65iwb1j", "payloadVersion": 1}
01KESX32D5GFFDNXSVPK9SVZ62	1	USER_LOGGED_IN	2026-01-12 20:06:52.581	2026-01-12 20:06:52.581	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KESX32D5A3VSBDAZY0H36K39	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkblg78e0005yjp6uy0ijd5p", "payloadVersion": 1}
01KESX352TSZEFQK59XKZ41B53	1	PLATFORM_ADMIN_AUDIT	2026-01-12 20:06:55.322	2026-01-12 20:06:55.322	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KESX352TZNV3KBSNRGW65E8V	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KESX39SKG6AJZQY03WXES7QE	1	PLATFORM_ADMIN_AUDIT	2026-01-12 20:07:00.147	2026-01-12 20:07:00.147	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KESX39SK71X8GWRRXEHFV17S	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KESX3BCV5AN88JD8DZFKMVKD	1	USER_LOGGED_OUT	2026-01-12 20:07:01.787	2026-01-12 20:07:01.787	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KESX3BCVD30CCCSZ0T1DD1HB	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkblg78e0005yjp6uy0ijd5p", "payloadVersion": 1}
01KESX3H2Y3G8T1CMY780BZ41N	1	USER_LOGGED_IN	2026-01-12 20:07:07.614	2026-01-12 20:07:07.614	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KESX3H2YKF0GWQN37HJA5MM1	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkblgiu10008yjp6qcauzum9", "payloadVersion": 1}
01KEVBX007PPYFSGFWRV1TQJSV	1	USER_LOGGED_IN	2026-01-13 09:44:56.582	2026-01-13 09:44:56.583	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVBX006JW8GEZH7Y9MXBPVC	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkceo8ou0002wlikz88ddnn3", "payloadVersion": 1}
01KEVBXEKDXAKE4N4QDBMSHYK4	1	INTENT_VIEWED	2026-01-13 09:45:11.533	2026-01-13 09:45:11.533	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KEVBXEKC4V6PQH3JV16RB2AA	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KEVBYYEXV6S73D2PE3GR3GJV	1	USER_LOGGED_OUT	2026-01-13 09:46:00.541	2026-01-13 09:46:00.541	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVBYYEX3E0KY9JCY76KTPZR	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkceo8ou0002wlikz88ddnn3", "payloadVersion": 1}
01KEVBZ2HA718YVPW1RMQNYP9V	1	USER_LOGGED_IN	2026-01-13 09:46:04.714	2026-01-13 09:46:04.714	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVBZ2HAF8VNY65PYPBV3N6Y	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcepp9h0008wlik7rv1wt8s", "payloadVersion": 1}
01KEVBZ8BX2HEMSH3Z2DSKJVXV	1	PLATFORM_ADMIN_AUDIT	2026-01-13 09:46:10.685	2026-01-13 09:46:10.686	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVBZ8BXK5WF7ZJKN7GSAE5G	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVBZDCXHE4AQDH3V7AAFV5V	1	PLATFORM_ADMIN_AUDIT	2026-01-13 09:46:15.836	2026-01-13 09:46:15.837	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVBZDCWS3295VP1RR55WGAD	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVC17E0DD6HMZ2TS4ZMDXNE	1	PLATFORM_ADMIN_AUDIT	2026-01-13 09:47:15.264	2026-01-13 09:47:15.264	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVC17E03HJHWG3JNY9MXK00	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVC77TT87PM7JJ47Z2KG7XX	1	PLATFORM_ADMIN_AUDIT	2026-01-13 09:50:32.282	2026-01-13 09:50:32.283	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVC77TTASZCWG7JQF3NWGV5	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVC79DAFHKG0W11BR9P565P	1	PLATFORM_ADMIN_AUDIT	2026-01-13 09:50:33.898	2026-01-13 09:50:33.898	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVC79DAMKKV4HWEC9785T5N	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVC7AEVXWV9Q9YXNETZT6KV	1	PLATFORM_ADMIN_AUDIT	2026-01-13 09:50:34.971	2026-01-13 09:50:34.972	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVC7AEVNF470T5WNFMCYN4H	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVDGK45TV7883WV8NKYMCFK	1	PLATFORM_ADMIN_AUDIT	2026-01-13 10:13:07.332	2026-01-13 10:13:07.333	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVDGK44TZ04N6H8ZFXTVGFR	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVDGPX8390KPWX5JX5WWTAQ	1	PLATFORM_ADMIN_AUDIT	2026-01-13 10:13:11.208	2026-01-13 10:13:11.208	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVDGPX884R7T6NMTWVYYEXB	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVFMRJCXJH5DJE3MH05EHSW	1	USER_LOGGED_IN	2026-01-13 10:50:21.131	2026-01-13 10:50:21.132	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVFMRJBZN0F98RQ6XTTBG8X	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkch0cvy0003z8kxaigta1sl", "payloadVersion": 1}
01KEVFP484SBAMCGTC5PXQG5TX	1	USER_LOGGED_IN	2026-01-13 10:51:05.86	2026-01-13 10:51:05.86	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVFP484GVH2VDJGNECTPC1B	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkch1bel0006z8kxj59q6gjp", "payloadVersion": 1}
01KEVH1EDD72ZRNHXDQ8ZHASVV	1	PLATFORM_ADMIN_AUDIT	2026-01-13 11:14:45.293	2026-01-13 11:14:45.294	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVH1EDDD0F3W62JVQFN2Y53	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVH5J5BA27925KGJ9DAEQPD	1	PLATFORM_ADMIN_AUDIT	2026-01-13 11:17:00.203	2026-01-13 11:17:00.204	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVH5J5BY4RAQPP5MH1XV91J	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVH5NA7R74AZQ92H0FX87FH	1	PLATFORM_ADMIN_AUDIT	2026-01-13 11:17:03.43	2026-01-13 11:17:03.431	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVH5NA6AEVMJPB76KY3P9FW	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVH5NB7DHK7VGJGXQ4XB9GC	1	PLATFORM_ADMIN_AUDIT	2026-01-13 11:17:03.462	2026-01-13 11:17:03.463	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVH5NB6K3C22D2PFANCM5K1	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3J09948KZKSG931A5M2X	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:20.232	2026-01-13 12:08:20.233	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3J08M2W7W2YQNFS572B8	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3J0E5MJ7ZB1CA0915JN2	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:20.237	2026-01-13 12:08:20.238	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3J0D1ZB8SNW4M464KHXZ	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3N971N3VZVMEN32ZZMBK	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:23.591	2026-01-13 12:08:23.591	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3N97NZM2T0A4BQ3D4ZTS	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3N9R387AN2YWH9W48SXJ	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:23.608	2026-01-13 12:08:23.608	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3N9RFZGSN4DNP6DWEBHD	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3P6ZGNH0VBFR1B86EJ6C	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:24.543	2026-01-13 12:08:24.543	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3P6ZPW7814M6GSFK6X8P	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3P6Y07DB95S640YDVTSX	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:24.542	2026-01-13 12:08:24.542	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3P6YA47PKC7CQBYAY3C8	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3PVF2MXSCP383TZEW5MZ	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:25.198	2026-01-13 12:08:25.199	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3PVEGPKC09CXC686BCP2	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3PVH57C9AJC6VDTXD59E	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:25.201	2026-01-13 12:08:25.201	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3PVHMFRJXNMWH4H026WT	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3Q1F1KJZZHFMPG7FB6Y7	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:25.391	2026-01-13 12:08:25.391	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3Q1FVV2KTJQ1NV6ATREA	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3Q21Q0PR46G29J0MB4N0	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:25.408	2026-01-13 12:08:25.409	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3Q207HJDFV5F1H8WE9CX	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3Q77FP2X0SVHBN0CZV8B	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:25.574	2026-01-13 12:08:25.575	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3Q76PP0J1EQ750ZVSYN2	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3Q7A760P3ZBHDPZN49B4	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:25.577	2026-01-13 12:08:25.578	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3Q7904Y9F16HBS2PJ9VZ	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3QCZSZPJZV51NG76MKV4	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:25.759	2026-01-13 12:08:25.759	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3QCZNVDGHZSBJTMJ9X64	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3QD2RVWWFRNK0FWTNKDJ	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:25.762	2026-01-13 12:08:25.762	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3QD2ERGAC0FX6Z4BECJ3	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM3QJRBBGKF0RWP7QB57PE	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:25.943	2026-01-13 12:08:25.944	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3QJQ7WH6213ER1C9ASPK	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM8ATGQXGZES9B9FS4QJY9	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:10:56.72	2026-01-13 12:10:56.72	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM8ATGMCBZDPKFCF35KPFP	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVM3QJTYPG74F7NQP5WMN9M	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:08:25.946	2026-01-13 12:08:25.946	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM3QJTRKH59134C3WRBH3E	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVM52TJQH3MNTHP8XPXJKDF	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:09:10.226	2026-01-13 12:09:10.226	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM52TJEX8STKV5EB0YA3YN	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVM594VV6JNH187SMRMNKSP	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:09:16.699	2026-01-13 12:09:16.699	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM594VR3HVQAWCMJBXM7CA	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVM59506PSFFTHWJH9386DY	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:09:16.704	2026-01-13 12:09:16.705	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM5950ZDN8SKFP8QRHSA3G	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVM5P91RTPNMMRK62PYFAS3	1	USER_LOGGED_OUT	2026-01-13 12:09:30.145	2026-01-13 12:09:30.145	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVM5P91H54BNDP2TDGRX0VB	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcepp9h0008wlik7rv1wt8s", "payloadVersion": 1}
01KEVM5TXK1J8AD4RDFZKS68ZT	1	USER_LOGGED_IN	2026-01-13 12:09:34.899	2026-01-13 12:09:34.899	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVM5TXK02JRJFE661F7MMJ8	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcju8x700025j850kzv2q1t", "payloadVersion": 1}
01KEVM6B7TG4SCDBW8F67F8HYF	1	USER_LOGGED_OUT	2026-01-13 12:09:51.61	2026-01-13 12:09:51.61	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVM6B7TN5YPWVR079K20DAY	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcju8x700025j850kzv2q1t", "payloadVersion": 1}
01KEVM6F98958T3S0K0Y432A8Q	1	USER_LOGGED_IN	2026-01-13 12:09:55.752	2026-01-13 12:09:55.752	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVM6F98KN0Q9H9GKN8RTAPB	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcjup0j00055j85d35c3szu", "payloadVersion": 1}
01KEVM860NH0A0YEFW87MKN9P7	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:10:51.797	2026-01-13 12:10:51.797	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM860NCWET756J5VKBRSED	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVM89853FQCFPTV2QTJ7388	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:10:55.108	2026-01-13 12:10:55.109	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM8984JA5TWX4725WKWPPW	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVM8ATD6FHEB8ST2J954ZZD	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:10:56.716	2026-01-13 12:10:56.717	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVM8ATC5Y5590C2JK3TP76A	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVMP0MHN3VGX164PV0YGP40	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:18:25.038	2026-01-13 12:18:25.041	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMP0ME464YXVRCF5XJWH96	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVMP0P9N2BRDA97DFF5MPW2	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:18:25.097	2026-01-13 12:18:25.097	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMP0P9NYAXK7QF9DY3FF1Z	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVMP4G7W2BKWC86SPQFWT6F	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:18:28.999	2026-01-13 12:18:28.999	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMP4G7DM6C4WF9KRYF2DRY	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVMP4H6B9EKAN642WK2QVKQ	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:18:29.03	2026-01-13 12:18:29.03	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMP4H6H3H2E6QY5HYJXZSP	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVMP58CA581VQ9Z99KG25MX	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:18:29.772	2026-01-13 12:18:29.772	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMP58CSVSZ5EPAZB0B0DQ8	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVMP58DX6BZBZR7VXNYM6F2	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:18:29.773	2026-01-13 12:18:29.773	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMP58DAEFP7FW2Q4RTAH6H	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVMP5TGH5DJDXKRFAGC63EE	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:18:30.349	2026-01-13 12:18:30.352	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMP5TDNKP1WPV73X6SXA27	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVMP5VHC3YQD0XKSSHA19PR	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:18:30.385	2026-01-13 12:18:30.386	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMP5VH3GCBV2E8C04TE7G2	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVMQJQ2R9QWPGYN4CEVQ3T6	1	USER_LOGGED_IN	2026-01-13 12:19:16.321	2026-01-13 12:19:16.322	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVMQJQ17CPT85GVB80P4QPK	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkck6pju00023tkx3glnht6p", "payloadVersion": 1}
01KEVMQXREW97VE6J603VD2EQN	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:19:27.63	2026-01-13 12:19:27.631	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMQXREBBH6CME7C1BCW9GY	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVMQZHJMV5E4WG1A3W8JY0B	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:19:29.458	2026-01-13 12:19:29.458	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMQZHJSASQK8NX20YEK5DD	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVMQZHPHSWV3J0F2GDD7NSH	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:19:29.462	2026-01-13 12:19:29.462	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVMQZHPCX8AJH1302W0V825	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVN5B71G4CQFE6TV2DRDBNT	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:26:47.392	2026-01-13 12:26:47.394	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVN5B70QN0DA8Y742F6PSZR	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVN5B7H31SX7FFSZFTJ8V33	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:26:47.409	2026-01-13 12:26:47.409	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVN5B7HCZ5DAGX3YV1G16MG	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVN5J5F5SX8SS742MAZHJWN	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:26:54.51	2026-01-13 12:26:54.511	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVN5J5EX0WQ8KQ53X2CFAC7	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVN5MCVV4Z3042TXPARHRA4	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:26:56.795	2026-01-13 12:26:56.796	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVN5MCV57MGPF1VH4FYEC30	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVN5MDEJM2ZX7XC3GF02XNX	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:26:56.814	2026-01-13 12:26:56.814	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVN5MDEBDKWHBGMRB19V6P9	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVNK9R4M5PDW9KR4Q1HGKMN	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:34:24.64	2026-01-13 12:34:24.645	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVNK9R08YPRFYM57Q59TAEH	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVNK9RFZXJK54RPSANBMDXK	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:34:24.655	2026-01-13 12:34:24.655	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVNK9RF89NF2594CWVM37YV	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVNW60BF8FJ11S9EQP20BRP	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:39:15.722	2026-01-13 12:39:15.723	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVNW60A4PGMN3700WCEHJ0T	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVPANBMP0P22EJ10M8CVHR7	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:47:10.195	2026-01-13 12:47:10.196	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPANBK084760NHE4M8P0NR	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVPB05BK98XTCWB2RS6TQMS	1	USER_LOGGED_OUT	2026-01-13 12:47:21.259	2026-01-13 12:47:21.26	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVPB05BE5CJAZ362JY23EJ8	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkck6pju00023tkx3glnht6p", "payloadVersion": 1}
01KEVPB2NYG236XFKFE9TN1TVC	1	USER_LOGGED_IN	2026-01-13 12:47:23.838	2026-01-13 12:47:23.838	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVPB2NYNC6DZXKZHDY1KCMB	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcl6vnb0002cscewhrlrxhz", "payloadVersion": 1}
01KEVPBA6NA3GAPGDK3E7YAJJ5	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:47:31.541	2026-01-13 12:47:31.541	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPBA6N8WVM5A0YJ271YCWT	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVPBB4EEE2F2288VKM0R9BN	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:47:32.493	2026-01-13 12:47:32.494	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPBB4DVMT4V85SEV6Y7Y8G	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVPBB5570V8PSFF5M17CW00	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:47:32.517	2026-01-13 12:47:32.517	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPBB557F79R4TRWA9J29CF	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVPBM3VMFSTZXC73QWFPREB	1	USER_LOGGED_OUT	2026-01-13 12:47:41.69	2026-01-13 12:47:41.691	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVPBM3TT5EDFFVTM2KBXPC0	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcl6vnb0002cscewhrlrxhz", "payloadVersion": 1}
01KEVPBSGJM9JQ21P011S6N4BP	1	USER_LOGGED_IN	2026-01-13 12:47:47.218	2026-01-13 12:47:47.218	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVPBSGJ9Z7MRG89YJ2EDFKZ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcl7dor0005cscezm2k8qix", "payloadVersion": 1}
01KEVPBXMTGXJDR35VKP81W357	1	USER_LOGGED_OUT	2026-01-13 12:47:51.45	2026-01-13 12:47:51.451	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVPBXMTJX8H1THCF44Z73J5	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcl7dor0005cscezm2k8qix", "payloadVersion": 1}
01KEVPC2TTVD2F43BKAXFGKHKR	1	USER_LOGGED_IN	2026-01-13 12:47:56.762	2026-01-13 12:47:56.762	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVPC2TTC8CCWBQ3DCZSXG5C	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcl7l1y0008cscezonrhl25", "payloadVersion": 1}
01KEVPC7EKZPGSF5T4KEPC9QX5	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:48:01.49	2026-01-13 12:48:01.491	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPC7EKJ5M65VG0HAKZ18TX	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVPC8VSCG8W1AWQ8CBSMJX1	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:48:02.937	2026-01-13 12:48:02.937	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPC8VS44KKG7XMZQECNNN0	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVPC8WEVM5QAA06QZ7HF5FF	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:48:02.958	2026-01-13 12:48:02.958	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPC8WEV1J4B3KHRMRZC89F	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVPCN9DZ60G8ATCJ6R4SXF9	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:48:15.661	2026-01-13 12:48:15.661	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPCN9D0S79SHC3PCETN45P	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVPCPC3Z22QE1HWDT6G5B9M	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:48:16.771	2026-01-13 12:48:16.771	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPCPC3CKW76VHF3S30F616	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVPCPCTRD7524SYM2YSBT15	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:48:16.794	2026-01-13 12:48:16.794	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPCPCTA8YZ8K83XME1KVGM	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVPCR079V5YKBC8M13CPKGB	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:48:18.439	2026-01-13 12:48:18.439	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPCR07QMD1SD0PAZ7542RG	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVPCS0PS45Q4XY185EY1580	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:48:19.477	2026-01-13 12:48:19.478	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPCS0N3HD8Z08YC0CCGHH6	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVPCS0R6YWGEGAQFAY2VJHM	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:48:19.479	2026-01-13 12:48:19.48	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPCS0QGEM8F14JQQ3S7VEB	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVPWCHDPZCYHW5ASSMYY9NR	1	USER_LOGGED_OUT	2026-01-13 12:56:50.989	2026-01-13 12:56:50.989	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVPWCHDW9GT6884N9G0836E	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcl7l1y0008cscezonrhl25", "payloadVersion": 1}
01KEVPWGJF4YNFMJ4GKGR54KCG	1	USER_LOGGED_IN	2026-01-13 12:56:55.119	2026-01-13 12:56:55.119	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVPWGJF8JAGQ989TX1FXH9H	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkclj4g7000bcscek4h7dhv9", "payloadVersion": 1}
01KEVPWKACWSW10BGE3Q2HXGC5	1	USER_LOGGED_OUT	2026-01-13 12:56:57.932	2026-01-13 12:56:57.932	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVPWKACXBPRK2MEZ3MQ9PS8	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkclj4g7000bcscek4h7dhv9", "payloadVersion": 1}
01KEVPWPSN5NHW4VZMEWT32AJP	1	USER_LOGGED_IN	2026-01-13 12:57:01.493	2026-01-13 12:57:01.493	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVPWPSNQKD1SQWWFJRYW84N	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkclj9d8000ecsceu2c8dbfc", "payloadVersion": 1}
01KEVPWVVAGE0E9A0C7PJW8EBZ	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:57:06.666	2026-01-13 12:57:06.666	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPWVVAC485W1KMJQV1YREB	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVPWX8JSQRFXH5TQYHDCSDC	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:57:08.114	2026-01-13 12:57:08.114	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPWX8J0PCVP08CBKHJEDS0	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVPWXA48X656J5ZHN8TSQM0	1	PLATFORM_ADMIN_AUDIT	2026-01-13 12:57:08.164	2026-01-13 12:57:08.164	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVPWXA4967V5CWVQV2B6CZV	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVQEYXS7Z3Y6Y3K6WK6875E	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:06:59.64	2026-01-13 13:06:59.641	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVQEYXR63YJAQP2P50H77QS	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVQEYY77P1288SQYR80541A	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:06:59.654	2026-01-13 13:06:59.655	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVQEYY68P6YG693A32M6QQP	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVQG22NJXW0MT2VJPJWT4YG	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:07:35.636	2026-01-13 13:07:35.637	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVQG22M0X2T1YGQMZ822TN8	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVQG4RARH3FA1EGGXFNZHZR	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:07:38.378	2026-01-13 13:07:38.378	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVQG4RAJJDNCF40ZY4JQNTZ	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVQG4RHJHD2ZDDW5AAYDFPY	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:07:38.385	2026-01-13 13:07:38.385	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVQG4RH4VZJP2J5PD4ZQAPQ	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVQGHTEQTCXCESEA0BRBXQY	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:07:51.758	2026-01-13 13:07:51.759	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVQGHTEJVRYTQ3ZH3HNWTJW	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVQGHTQSDCNH6S1E7GE3ES9	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:07:51.766	2026-01-13 13:07:51.767	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVQGHTPRQDHJTSGQ5QVV0HP	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVQGKRWA2ND9H43Y8QDB1MP	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:07:53.755	2026-01-13 13:07:53.756	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVQGKRV2THEMYZ18WVP7JP6	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVQGKRY36GSZFWR4S6J6C2K	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:07:53.758	2026-01-13 13:07:53.759	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVQGKRY0XMDSQ6FE6FYKNMX	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVQRJD1GT08Z42STK5C82QB	1	USER_LOGGED_IN	2026-01-13 13:12:14.497	2026-01-13 13:12:14.497	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVQRJD13HV49ZMEW2651PKB	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcm2tue0002fanb44kx3zmd", "payloadVersion": 1}
01KEVQSGY75JJH7AKH7ZSS2WMV	1	USER_LOGGED_IN	2026-01-13 13:12:45.767	2026-01-13 13:12:45.767	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVQSGY79ZS11HSQQRDDMZV3	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcm3hz40005fanbofq0026e", "payloadVersion": 1}
01KEVQVGTQCB5H12C23Y8EJCCG	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:13:51.19	2026-01-13 13:13:51.191	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVQVGTPTF7D9BNVWT45MHGN	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVRRJFPQZ2954F4T98B0FFR	1	USER_LOGGED_IN	2026-01-13 13:29:43.157	2026-01-13 13:29:43.158	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVRRJFPHRR84FYE7BCHFJCG	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcmpazx0009fanb8jzoirku", "payloadVersion": 1}
01KEVRTJ61GN11T5N326BRGBXA	1	USER_LOGGED_IN	2026-01-13 13:30:48.385	2026-01-13 13:30:48.385	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVRTJ61MEFFDAV5PXQQEEYQ	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcmqpbv000cfanbffpgn0cm", "payloadVersion": 1}
01KEVRTK7P5E3NY14WQ57A09D9	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:30:49.461	2026-01-13 13:30:49.462	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVRTK7NRMAE77Z2X1YK8WVE	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVRTM8YHJZJVY2460JW4G30	1	USER_LOGGED_IN	2026-01-13 13:30:50.526	2026-01-13 13:30:50.526	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVRTM8YMPZW68DXRM6JJ9GA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcmqqzc000ffanbzmjlawxc", "payloadVersion": 1}
01KEVRXFRB0TCN6X715H2HRJWS	1	USER_LOGGED_IN	2026-01-13 13:32:24.203	2026-01-13 13:32:24.203	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVRXFRBBWMYA4JEM0K2XF0R	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcmsr9h000ifanb94i2k6ti", "payloadVersion": 1}
01KEVRZMFCW784MQ1R6RP9M03Q	1	USER_LOGGED_IN	2026-01-13 13:33:34.572	2026-01-13 13:33:34.572	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVRZMFC015ZZ0RMRHEVGA24	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcmu9jd000lfanbomljluye", "payloadVersion": 1}
01KEVRZNKA53ACC8P8C4FMP22K	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:33:35.722	2026-01-13 13:33:35.722	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVRZNKAHZHWRW8NXKC0D2TG	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVRZPK9CG04E13KA3HM1YDC	1	USER_LOGGED_IN	2026-01-13 13:33:36.745	2026-01-13 13:33:36.745	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVRZPK9MMNT1TMA36ZJ7GGB	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcmub8f000ofanb07ooskg8", "payloadVersion": 1}
01KEVRZQ2Q92J636PZB01J7KJN	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:33:37.239	2026-01-13 13:33:37.239	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVRZQ2QF21TJHHGRH74Z9CJ	{"query": {"limit": 5}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEVRZQA5AXGR04HCP931HBCX	1	USER_LOGGED_IN	2026-01-13 13:33:37.477	2026-01-13 13:33:37.477	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVRZQA5DBEERD3X58FPRCJZ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcmubsx000rfanbh1xyc1gl", "payloadVersion": 1}
01KEVRZQS3EW2CFE848A5V3FHF	1	USER_LOGGED_IN	2026-01-13 13:33:37.954	2026-01-13 13:33:37.955	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVRZQS2B5GGC2ZQ89AQYCP7	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcmuc65000ufanboczmvvr9", "payloadVersion": 1}
01KEVRZR07ED2ZJMRF9WAH9Y8N	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:33:38.183	2026-01-13 13:33:38.183	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVRZR07NQDK43Y2XQNX7AHJ	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVS1W4KH41KCFKEKPD4SF46	1	USER_LOGGED_IN	2026-01-13 13:34:47.955	2026-01-13 13:34:47.955	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVS1W4K3BE6P3ST8CH2Q3ZN	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcmvu6k000xfanbqxu6x48k", "payloadVersion": 1}
01KEVS1XAAJ1X9MRDPB9WVQ5Y7	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:34:49.162	2026-01-13 13:34:49.162	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVS1XAATPYG4WP64FBEX1KR	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVS1Y7H4734CF0671Q5GYTA	1	USER_LOGGED_IN	2026-01-13 13:34:50.096	2026-01-13 13:34:50.097	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVS1Y7GW0HYXP81T189PB5G	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcmvvu20010fanbxnc7miir", "payloadVersion": 1}
01KEVS1YRK6TQ6ZWXWSWFJR0SX	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:34:50.643	2026-01-13 13:34:50.643	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVS1YRKNP8TCX9XJ28FDRQT	{"query": {"limit": 5}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 5, "payloadVersion": 1}
01KEVS1Z23QTA6SZDD8EP6R0PQ	1	USER_LOGGED_IN	2026-01-13 13:34:50.946	2026-01-13 13:34:50.947	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVS1Z22TGQ7KH4AM2SEH04H	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcmvwhq0013fanbr0s8brj2", "payloadVersion": 1}
01KEVS1ZHR7342MJRVA4CGX89C	1	USER_LOGGED_IN	2026-01-13 13:34:51.448	2026-01-13 13:34:51.448	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVS1ZHR3CHQR5AP465AMYD1	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcmvwvm0016fanbptmv48qi", "payloadVersion": 1}
01KEVS1ZXQBVZHKM53C44XX5RJ	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:34:51.83	2026-01-13 13:34:51.831	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVS1ZXPB9FSX50M8F0PHAYG	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVS9K498XTDRQNJGYNS047G	1	USER_LOGGED_IN	2026-01-13 13:39:00.873	2026-01-13 13:39:00.873	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVS9K49R00DFHSXJJAKQYKR	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcn19c10019fanb59ki9q5z", "payloadVersion": 1}
01KEVS9KQX7KCGP22EFD79ENZH	1	USER_LOGGED_IN	2026-01-13 13:39:01.5	2026-01-13 13:39:01.501	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVS9KQW0M0N499TRRVWPFZ9	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcn19td001cfanb2ie3cdb1", "payloadVersion": 1}
01KEVS9M1Q55N5SRXBQFKPFS0P	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:39:01.815	2026-01-13 13:39:01.815	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVS9M1Q48C2H9996YSVD4N4	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVS9MQ3QARPW9YVYA0GKVKV	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:39:02.499	2026-01-13 13:39:02.499	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVS9MQ3853MCC8YZ9HW5GFY	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVSAJ16SP1XXSR5MV4H41AH	1	USER_LOGGED_IN	2026-01-13 13:39:32.517	2026-01-13 13:39:32.518	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVSAJ15MZQE9PAJSQXMSS83	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcn1xr3001ffanbfaxz5cif", "payloadVersion": 1}
01KEVSDZYQCJ2ZMCFSSQ9XJAH3	1	USER_LOGGED_IN	2026-01-13 13:41:25.079	2026-01-13 13:41:25.08	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVSDZYQ98NT7DABBF16NHR6	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcn4clt001ifanbv8wjiqal", "payloadVersion": 1}
01KEVSXGBSR7JJ1F1BNFPTHPAY	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:49:53.401	2026-01-13 13:49:53.401	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVSXGBSEA6RH4QNGMA9C237	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVSYAC8PW9AB2KYAA4S2KRC	1	USER_LOGGED_IN	2026-01-13 13:50:20.04	2026-01-13 13:50:20.04	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVSYAC8VCYCVBJ9ZY4DCY50	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcnftds001lfanbnspz8w1l", "payloadVersion": 1}
01KEVSYDDGG3ATEH5E0Q46SNKM	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:50:23.151	2026-01-13 13:50:23.152	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVSYDDF5JH3C2TV3K2MPXHK	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVSYMX5JMKB112RZ6MBBNHF	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:50:30.82	2026-01-13 13:50:30.821	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVSYMX4MDR4PGZFD88ZZVJT	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVSYPCTZFZPS9PA3TYE4WFQ	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:50:32.346	2026-01-13 13:50:32.346	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVSYPCT6RAG6ZJBVZN0T0NS	{"action": "TENANT_VIEW", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVSYPE6434TT21BB5J28YFA	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:50:32.389	2026-01-13 13:50:32.39	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVSYPE530Y4Y9A5YKM1CPGA	{"action": "TENANT_USERS_LIST", "targetId": "cmk48grgv0006bmbcmahvvpfc", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk48grgv0006bmbcmahvvpfc", "payloadVersion": 1}
01KEVSZ94PWJ6PJ9256K852HHK	1	USER_LOGGED_OUT	2026-01-13 13:50:51.542	2026-01-13 13:50:51.542	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVSZ94PESQ412WWETRDMJCV	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcnftds001lfanbnspz8w1l", "payloadVersion": 1}
01KEVSZFH7K49PBVT5JY7FK0Y3	1	USER_LOGGED_IN	2026-01-13 13:50:58.087	2026-01-13 13:50:58.087	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVSZFH7R7K33YD3T5VSVFTZ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcngmqo001ofanb7odtg3xs", "payloadVersion": 1}
01KEVSZKCNMWPDFRJWR2TD1RYC	1	USER_LOGGED_OUT	2026-01-13 13:51:02.037	2026-01-13 13:51:02.038	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVSZKCNSNWR3CV7H244V2EA	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcngmqo001ofanb7odtg3xs", "payloadVersion": 1}
01KEVSZNPJJPRX7KP4FS84KNMB	1	USER_LOGGED_IN	2026-01-13 13:51:04.402	2026-01-13 13:51:04.402	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVSZNPJ9KKXAPTB9BEZ7MMN	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcngrm1001rfanb2o3rzwet", "payloadVersion": 1}
01KEVSZQ7MP09TN4Q094SSC8H8	1	USER_LOGGED_OUT	2026-01-13 13:51:05.971	2026-01-13 13:51:05.972	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVSZQ7KNAJ2EXYSH5X6XH1P	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcngrm1001rfanb2o3rzwet", "payloadVersion": 1}
01KEVSZV9ZRP2TQVB9VWMPCD8Z	1	USER_LOGGED_IN	2026-01-13 13:51:10.143	2026-01-13 13:51:10.143	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVSZV9ZFDT2RCEE4KMCZADN	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcngw1k001ufanbacr9c034", "payloadVersion": 1}
01KEVT0Q7ERG03XD0Z7W1MNPQ1	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:51:38.734	2026-01-13 13:51:38.734	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVT0Q7E7JQ929C2YX1NKWAW	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVT13VVNCVZBA8GY2VS6HV9	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:51:51.675	2026-01-13 13:51:51.676	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVT13VV3YVSQSN0AGXYA4VR	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVT162DB8CNWN8EADARRW4F	1	USER_LOGGED_OUT	2026-01-13 13:51:53.933	2026-01-13 13:51:53.933	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVT162DG66H2XQPMJ2YQW7F	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcngw1k001ufanbacr9c034", "payloadVersion": 1}
01KEVT18KGQKG74H0JYK6N3A7R	1	USER_LOGGED_IN	2026-01-13 13:51:56.528	2026-01-13 13:51:56.529	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVT18KG56RFPMANB4C8S063	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcnhvu3001yfanbbfufvqcr", "payloadVersion": 1}
01KEVT1GHPJJ65G274AA99SHEZ	1	USER_LOGGED_OUT	2026-01-13 13:52:04.662	2026-01-13 13:52:04.662	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVT1GHPC2BWNWYP5MTE1R6V	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcnhvu3001yfanbbfufvqcr", "payloadVersion": 1}
01KEVT1MEAA5YDGZ4X6ZVDW58M	1	USER_LOGGED_IN	2026-01-13 13:52:08.649	2026-01-13 13:52:08.65	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVT1ME9MP8HY1Z467CTHK7R	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcni56r0021fanb3p3b9uh9", "payloadVersion": 1}
01KEVT1WJYDB3RDGP9GV0RYKQM	1	USER_LOGGED_OUT	2026-01-13 13:52:16.989	2026-01-13 13:52:16.99	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVT1WJXY36J2Q2V2EPH2A9G	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcni56r0021fanb3p3b9uh9", "payloadVersion": 1}
01KEVT21H5JDKK70T1903KJV0S	1	USER_LOGGED_IN	2026-01-13 13:52:22.053	2026-01-13 13:52:22.053	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVT21H5QXMN55HRRTBF4S30	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcnifj20024fanb87wojafn", "payloadVersion": 1}
01KEVT24H0AG423076W7277GFV	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:52:25.12	2026-01-13 13:52:25.12	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVT24H0B9DRC8MHD6Z1X4QJ	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVT260Q8TZT1V3TSXVZMR2M	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:52:26.647	2026-01-13 13:52:26.647	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVT260QTNY2Q5Z98HY7A4H4	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVT260T73GV34C103FNAFC3	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:52:26.65	2026-01-13 13:52:26.65	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVT260T1S9RE6ZP7ET9B68Q	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVT2FZ1BA0290JHXAEFN5WB	1	USER_LOGGED_OUT	2026-01-13 13:52:36.833	2026-01-13 13:52:36.833	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVT2FZ1CA9QT4CX4TWGKK4W	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcnifj20024fanb87wojafn", "payloadVersion": 1}
01KEVT2N5TAER2HM6V53S4QT64	1	USER_LOGGED_IN	2026-01-13 13:52:42.169	2026-01-13 13:52:42.17	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVT2N5SCJE632CWP31AP318	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcniv1u0027fanbur31t4z8", "payloadVersion": 1}
01KEVT36GXXS8JWR9M03P3C8BM	1	USER_LOGGED_OUT	2026-01-13 13:52:59.933	2026-01-13 13:52:59.933	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVT36GXPG31FGFDHB3HC8VZ	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcniv1u0027fanbur31t4z8", "payloadVersion": 1}
01KEVT3CMASE5WRJY4HH1E4AQ4	1	USER_LOGGED_IN	2026-01-13 13:53:06.186	2026-01-13 13:53:06.186	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVT3CMACZ9A55T7Q6CQYSZX	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcnjdl1002afanbfpsj7zlg", "payloadVersion": 1}
01KEVT3JD5P4JNDVZ9WNGC24JP	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:53:12.101	2026-01-13 13:53:12.101	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVT3JD552BEAAAC5Q7V9YN7	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVT3PHHSXNVMQ1RVWHQVKAN	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:53:16.337	2026-01-13 13:53:16.337	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVT3PHH17GPSQCNPC3QJ43H	{"action": "NDA_LIST", "targetType": "NDA", "resultCount": 3, "payloadVersion": 1}
01KEVT492CW2F9BEZRM6J0C2VP	1	USER_LOGGED_OUT	2026-01-13 13:53:35.307	2026-01-13 13:53:35.308	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVT492BCEZSWY5RG71N9Z8P	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcnjdl1002afanbfpsj7zlg", "payloadVersion": 1}
01KEVT4DT6M6HPC0RXX3V4K91Y	1	USER_LOGGED_IN	2026-01-13 13:53:40.166	2026-01-13 13:53:40.166	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVT4DT602MN5Q68GC3XWEBS	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcnk3sx002dfanb8xgy7v1p", "payloadVersion": 1}
01KEVT5JPQHQQ89G7C0FV9HPAY	1	INTENT_VIEWED	2026-01-13 13:54:17.943	2026-01-13 13:54:17.943	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KEVT5JPP7CYDSE8215HAF0XE	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KEVT5TMMQCADGB83QDGF1RMH	1	INTENT_VIEWED	2026-01-13 13:54:26.068	2026-01-13 13:54:26.068	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmkb6tkau000412gfjnhadidf	CLARIFY	NEW	ui	01KEVT5TMM5CD8WFWYE585SZXK	{"intentId": "cmkb6tkau000412gfjnhadidf", "viewContext": "owner", "payloadVersion": 1}
01KEVT7R6CGAVZVE4ZNAD0E8SB	1	USER_LOGGED_OUT	2026-01-13 13:55:29.099	2026-01-13 13:55:29.1	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVT7R6BZQW1KN9NG9MH4420	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcnk3sx002dfanb8xgy7v1p", "payloadVersion": 1}
01KEVT7X0YG28T9ASNTB5YMX6F	1	USER_LOGGED_IN	2026-01-13 13:55:34.046	2026-01-13 13:55:34.046	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVT7X0Y7Q2SGTMXAZ0D34R6	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcnmjo7002gfanb9pvg7n56", "payloadVersion": 1}
01KEVT7ZPS7P8YB25MKSSRCGN2	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:55:36.793	2026-01-13 13:55:36.793	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVT7ZPS4KG2433QWBTK9P44	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVT8MDFPBVQTAM93EZK9WVD	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:55:57.999	2026-01-13 13:55:57.999	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVT8MDFNV6PXHM0ZSEE6WM1	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVT8ME6SW3WBVNZZ59RPRHJ	1	PLATFORM_ADMIN_AUDIT	2026-01-13 13:55:58.022	2026-01-13 13:55:58.022	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVT8ME6A4SX4DP0C13YKF46	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVY5HSGZPJNFRZE0QJMHP2Q	1	PLATFORM_ADMIN_AUDIT	2026-01-13 15:04:11.31	2026-01-13 15:04:11.312	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVY5HSE8FHXNHJHPC6C755C	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVY5KG1NVCYT0P21NYJ7KH0	1	PLATFORM_ADMIN_AUDIT	2026-01-13 15:04:13.057	2026-01-13 15:04:13.058	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVY5KG13M3FDCKSZ0ZHT960	{"action": "TENANT_VIEW", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVY5KGP87MS2YCXQP09JATR	1	PLATFORM_ADMIN_AUDIT	2026-01-13 15:04:13.078	2026-01-13 15:04:13.079	cmk736hrf0007oyv7jcxtvn9k	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVY5KGPV3DCF31H8C2GE3H0	{"action": "TENANT_USERS_LIST", "targetId": "cmk736hrf0007oyv7jcxtvn9k", "targetType": "TENANT", "resultCount": 1, "targetOrgId": "cmk736hrf0007oyv7jcxtvn9k", "payloadVersion": 1}
01KEVY5WNBHCXBPX1BX812YDZ8	1	PLATFORM_ADMIN_AUDIT	2026-01-13 15:04:22.443	2026-01-13 15:04:22.443	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVY5WNB0GC4059XQEANWXSE	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVY5Z7ASKHGVC4TG66Q8PE7	1	PLATFORM_ADMIN_AUDIT	2026-01-13 15:04:25.066	2026-01-13 15:04:25.066	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVY5Z7A74JVM72KPRFKYY9T	{"action": "TENANT_VIEW", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVY5Z7ENZ7PS0P316K6Y9WT	1	PLATFORM_ADMIN_AUDIT	2026-01-13 15:04:25.07	2026-01-13 15:04:25.07	cmk12kr4u000do1hxva29zgyd	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVY5Z7EBBZXTKVX3RZN414S	{"action": "TENANT_USERS_LIST", "targetId": "cmk12kr4u000do1hxva29zgyd", "targetType": "TENANT", "resultCount": 2, "targetOrgId": "cmk12kr4u000do1hxva29zgyd", "payloadVersion": 1}
01KEVY6R0EVKH12YF6RVXNSH4J	1	PLATFORM_ADMIN_AUDIT	2026-01-13 15:04:50.446	2026-01-13 15:04:50.446	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	system	01KEVY6R0EAKE8A2ZQECM8KW1Q	{"query": {"limit": 50}, "action": "TENANTS_LIST", "targetType": "TENANT", "resultCount": 6, "payloadVersion": 1}
01KEVY6VAWH3MBGZK7Y76Y4QWA	1	USER_LOGGED_OUT	2026-01-13 15:04:53.852	2026-01-13 15:04:53.852	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVY6VAWMQ8MD2TBWYPXDYSG	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcnmjo7002gfanb9pvg7n56", "payloadVersion": 1}
01KEVY7051T3N71GE4R6XWBBKA	1	USER_LOGGED_IN	2026-01-13 15:04:58.784	2026-01-13 15:04:58.785	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVY70501S4G2M7MHP19HZAX	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcq3t7d00034g01rszdonvk", "payloadVersion": 1}
01KEVY7398ZZCD5DCGQ0P0XKZY	1	USER_LOGGED_OUT	2026-01-13 15:05:01.992	2026-01-13 15:05:01.992	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVY7398EBQ8PN48EC8K5VD9	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcq3t7d00034g01rszdonvk", "payloadVersion": 1}
01KEVY777AXEH6NE203C66FKSJ	1	USER_LOGGED_IN	2026-01-13 15:05:06.026	2026-01-13 15:05:06.026	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVY777A53EQY4QN1FVWRGRA	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcq3ysj00064g01shsgo21g", "payloadVersion": 1}
01KEVY7GQND3AWTP9ZKQNKDRV2	1	USER_LOGGED_OUT	2026-01-13 15:05:15.765	2026-01-13 15:05:15.765	cmk48grgv0006bmbcmahvvpfc	cmk48grgz0008bmbcp8s2vrap	\N	USER	cmk48grgz0008bmbcp8s2vrap	CLARIFY	NEW	api	01KEVY7GQN7TFTF367JS8F782D	{"orgId": "cmk48grgv0006bmbcmahvvpfc", "userId": "cmk48grgz0008bmbcp8s2vrap", "sessionId": "cmkcq3ysj00064g01shsgo21g", "payloadVersion": 1}
01KEVY7MS3PY3E5VSY3MSGAXBC	1	USER_LOGGED_IN	2026-01-13 15:05:19.907	2026-01-13 15:05:19.908	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	\N	USER	cmk12kr4x000fo1hxdcjik7rt	CLARIFY	NEW	api	01KEVY7MS32TVEX8JASMHGH1B3	{"orgId": "cmk12kr4u000do1hxva29zgyd", "userId": "cmk12kr4x000fo1hxdcjik7rt", "sessionId": "cmkcq49i6000a4g013wsgqve1", "payloadVersion": 1}
01KEVYCZTGSMZ9C4RHKQEG82C4	1	INTENT_VIEWED	2026-01-13 15:08:15.056	2026-01-13 15:08:15.056	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KEVYCZTF6BSJ5GTECMY12QJA	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "viewContext": "owner", "payloadVersion": 1}
01KEW10AE9BPXCRP3R0V79V2N7	1	INTENT_VIEWED	2026-01-13 15:53:45.673	2026-01-13 15:53:45.673	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KEW10AE9221WMAKGXMX6XCCZ	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "viewContext": "owner", "payloadVersion": 1}
01KEW10JWYR017C4A6T4MX159C	1	INTENT_VIEWED	2026-01-13 15:53:54.334	2026-01-13 15:53:54.334	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	INTENT	cmk5tzxoz000o1341jzo45i8m	MATCH_ALIGN	MATCH	ui	01KEW10JWYDM32MEYD197ZV833	{"intentId": "cmk5tzxoz000o1341jzo45i8m", "viewContext": "owner", "payloadVersion": 1}
\.


--
-- Data for Name: Intent; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Intent" (id, "orgId", "createdByUserId", goal, context, scope, kpi, risks, "deadlineAt", stage, "confidentialityLevel", source, "createdAt", "updatedAt", title, "sourceTextRaw", "sourceTextSha256", "sourceTextLength", client, "ownerUserId", language, "lastActivityAt") FROM stdin;
cmk6prope00091fdlrmf971oe	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	test from paste	\N	\N	\N	\N	\N	NEW	L1	paste	2026-01-09 10:08:56.018	2026-01-09 10:08:56.018	test from paste	#16\tR1.0-INTENT-001 - Create Intent manually (from scratch)\t✅ CLOSED\n#25\tR1.0-INTENT-002 - Create Intent via paste / email text\t✅ CLOSED\n#26\tR1.0-INTENT-003 - Intent list view & filters\t✅ CLOSED\n#77\tR1.0-INTENT-ATT-001 - Intent attachments\t👷‍♀️ IN PROGRESS\n#17\tR1.0-PIPELINE-001 - Pre-sales pipeline board	c665ed3e848c967df34a70ab003f5c006a71950a81fd85f1b6202dec20d1c4d4	306	\N	cmjdakp0k0003ut2ufp00eqzv	EN	2026-01-09 10:08:56.017
cmk5te87r000e1341tr7y1dat	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	Creating…	\N	\N	\N	\N	\N	CLARIFY	L1	paste	2026-01-08 19:02:40.407	2026-01-09 14:18:27.369	Creating…	Creating…	c79ed9492e3c17199ab50694e07f5525cc6d598a02531528b0eb5ed933cd5466	9	\N	cmk12kr4x000fo1hxdcjik7rt	EN	2026-01-09 14:18:27.367
cmk5tiyvu000j1341uqwwes3f	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	Smoke paste	\N	\N	\N	\N	\N	MATCH	L1	paste	2026-01-08 19:06:21.595	2026-01-10 21:02:25.853	Smoke paste	Smoke paste intent	1778bd5652ffd8cce22d6273040675e2a093e695ca5662c8d63498ecc488f515	18	\N	cmk12kr4x000fo1hxdcjik7rt	EN	2026-01-10 21:02:25.852
cmk5jerkv0004bdrsfs3tf5hs	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	Sell new car.	We have plenty of new cars and we need to sell it.	Only new cars	1 car pwer week.	no	2026-06-30 00:00:00	NEW	L1	manual	2026-01-08 14:23:09.343	2026-01-08 14:23:09.343	\N	\N	\N	\N	\N	cmk12kr4x000fo1hxdcjik7rt	EN	2026-01-08 14:23:09.343
cmk5tdhg6000913412o3bqd4x	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	Test title	\N	\N	\N	\N	\N	NEW	L1	paste	2026-01-08 19:02:05.718	2026-01-08 19:02:05.718	Test title	test paste	95ba55c6ea6f04420f293d4a0fb0d28562e6aae18c1c8b05cd31ab7ed0c3c45a	10	\N	cmk12kr4x000fo1hxdcjik7rt	EN	2026-01-08 19:02:05.718
cmk6pq7nm00071fdlp1zekwp7	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	Test geal	contect text contect text contect text contect text contect text contect text	scope scope scope scope scope scope scope	kpoi	no	2026-04-24 00:00:00	NEW	L1	manual	2026-01-09 10:07:47.266	2026-01-09 10:07:47.266	Test geal	\N	\N	\N	\N	cmjdakp0k0003ut2ufp00eqzv	EN	2026-01-09 10:07:47.265
cmk5jhwcq0006bdrsvh8hnxme	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	Sell IT training	We have a portfolio of IT traininhg and can offer it to other companies.	IT development trainings.	1000 eur / month	in huge demant may strugle with trainers	2026-12-30 00:00:00	CLARIFY	L1	manual	2026-01-08 14:25:35.498	2026-01-12 17:15:52.925	\N	\N	\N	\N	\N	cmk12kr4x000fo1hxdcjik7rt	EN	2026-01-12 17:15:52.92
cmkb6tkau000412gfjnhadidf	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	goal	contects	scope	kpi	risk	2026-01-31 00:00:00	NEW	L1	manual	2026-01-12 13:17:21.799	2026-01-13 13:54:26.072	goal	\N	\N	\N	\N	cmk12kr4x000fo1hxdcjik7rt	EN	2026-01-13 13:54:26.068
cmk5tzxoz000o1341jzo45i8m	cmk12kr4u000do1hxva29zgyd	cmk12kr4x000fo1hxdcjik7rt	[SMOKE] Paste intent	\N	\N	\N	\N	\N	MATCH	L1	paste	2026-01-08 19:19:33.203	2026-01-13 15:53:54.339	[SMOKE] Paste intent	[SMOKE] Paste intent from VPS	d40b3acd936da11d958e23ef3994c743874f1238ddcfebd62be37a46570556f0	29	\N	cmk12kr4x000fo1hxdcjik7rt	EN	2026-01-13 15:53:54.334
\.


--
-- Data for Name: IntentShareLink; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."IntentShareLink" (id, "orgId", "intentId", "createdByUserId", "tokenHashSha256", "createdAt", "expiresAt", "revokedAt", "revokedByUserId", "lastAccessAt", "accessCount") FROM stdin;
cmkb32p91000qf1s92ui7obqr	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	a91a81b1a545110ccdf33c43d9732634fe71493b82034251f043e50db6d40416	2026-01-12 11:32:29.654	2026-01-26 11:32:29.648	2026-01-12 11:36:25.861	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb37rij000tf1s9obm46zx5	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	e45e67d1392e4d8ea2bf9b5492c468efd3a7f2f170f59d0216ae9f4f8006456f	2026-01-12 11:36:25.868	2026-01-26 11:36:25.861	2026-01-12 11:37:16.691	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb5vegz001wf1s9kt0errv9	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	bcbcc0b2823b85e13d8ab4e8bd6950d63e2b684434db1d505353be3ee768f8c8	2026-01-12 12:50:47.94	2026-01-26 12:50:47.936	2026-01-12 12:52:14.463	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb38uqe000wf1s9vgqqgxh3	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	96f0489bae85ab60604a5657ad0798a5745805993c94477434d382961b973098	2026-01-12 11:37:16.694	2026-01-26 11:37:16.69	2026-01-12 11:44:57.568	cmk12kr4x000fo1hxdcjik7rt	2026-01-12 11:44:16.588	2
cmkb3iqcm000zf1s9w8wkghbq	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	aef6849f3e33785ea45cc7830516c3e950a9b7cedeed562674267b7068979c05	2026-01-12 11:44:57.574	2026-01-26 11:44:57.568	2026-01-12 11:45:05.3	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb3lahv0012f1s9m4zvmazx	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	48591882673cfec56eaba7af62206bdf6f7c5a735af5a90aa139350e99da4ad9	2026-01-12 11:46:56.996	2026-01-26 11:46:56.992	2026-01-12 11:56:39.31	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb3xrtf0015f1s9lvns3758	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	5beab5398765d6e1a2903b7cea7bbe0ba7fc26b92f112819dd8eb848b05a7713	2026-01-12 11:56:39.315	2026-01-26 11:56:39.31	2026-01-12 12:02:19.75	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb452i40018f1s92o0nyjpx	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	1a25d069265c494f9a84e46decc043a53c8f270955178f569aa68f04754482f5	2026-01-12 12:02:19.756	2026-01-26 12:02:19.749	2026-01-12 12:04:37.94	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb4814o001bf1s926fkabdr	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	a86204ccc80e485d51d25b24510b7b7635992e2ea874bbc4e2c9ecced2a88fa6	2026-01-12 12:04:37.945	2026-01-26 12:04:37.939	2026-01-12 12:05:09.211	cmk12kr4x000fo1hxdcjik7rt	2026-01-12 12:04:48.579	1
cmkb48p9d001ef1s9xb6ftffv	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	2a47545210026f9da86e19f127db34d5159657d0bf6d9597fc14cef1f305801c	2026-01-12 12:05:09.217	2026-01-26 12:05:09.211	2026-01-12 12:06:54.981	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb4ayvc001hf1s9n5nm7mzt	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	5edd9fd93fe1c38ab760c30da6aed2b39d695e5d07deff35268b3b4001ef5d5b	2026-01-12 12:06:54.984	2026-01-26 12:06:54.981	2026-01-12 12:08:20.558	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb4cswj001kf1s9jqlrl2ea	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	4b58ca7a3650a30684b08c4874b234d440d546edb12ce4cd32242aaffe7c3c30	2026-01-12 12:08:20.563	2026-01-26 12:08:20.558	2026-01-12 12:14:06.703	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb4k7zo001qf1s93qv0jzbc	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	f177b161fdef4d5c13da922ad45b61f0d3bdbf50c9ad63a832b11253f313d226	2026-01-12 12:14:06.708	2026-01-26 12:14:06.703	2026-01-12 12:14:10.249	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb5t91y001tf1s9b5kod00a	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	9eede411916bcc6e64d06bb0672362775af4948198196e2f0fa3d75c1eb9872c	2026-01-12 12:49:07.607	2026-01-26 12:49:07.601	2026-01-12 12:50:47.936	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb64f2b0022f1s9umqq1rnm	cmk12kr4u000do1hxva29zgyd	cmk5tiyvu000j1341uqwwes3f	cmk12kr4x000fo1hxdcjik7rt	ce95cf64480a67f4b80cc54d08bdd736bd4df47e87908a399e04bfdb1c8a35a5	2026-01-12 12:57:48.612	2026-01-26 12:57:48.607	2026-01-12 12:57:51.204	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb64mmr0025f1s98223tafc	cmk12kr4u000do1hxva29zgyd	cmk5jhwcq0006bdrsvh8hnxme	cmk12kr4x000fo1hxdcjik7rt	0460ab248d6506b29f096632a05e010868a474344c89ae389eb1b45e75001261	2026-01-12 12:57:58.419	2026-01-26 12:57:58.414	2026-01-12 12:58:01.018	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb659k90028f1s9jhml7fjo	cmk12kr4u000do1hxva29zgyd	cmk5te87r000e1341tr7y1dat	cmk12kr4x000fo1hxdcjik7rt	6c97809fa71bb0ad37bc9dbb48e15b6ede63c4990a59b7575b4554ffad454803	2026-01-12 12:58:28.137	2026-01-26 12:58:28.131	2026-01-12 12:58:30.401	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkb5x98i001zf1s9okgx604b	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	42f3f7628d5804da792e28d641972ff987623bc1be7acf5e54085f41228a90e5	2026-01-12 12:52:14.466	2026-01-26 12:52:14.462	2026-01-12 19:41:57.8	cmk12kr4x000fo1hxdcjik7rt	\N	0
cmkbkk5v20002yjp6ie4fufq6	cmk12kr4u000do1hxva29zgyd	cmk5tzxoz000o1341jzo45i8m	cmk12kr4x000fo1hxdcjik7rt	4babad0702d10fa31ae859f8e3a1bef93dae3a01390522be36addfa0be6de870	2026-01-12 19:41:57.807	2026-01-26 19:41:57.8	\N	\N	\N	0
cmkceos5b0005wlikf1ackh6e	cmk12kr4u000do1hxva29zgyd	cmkb6tkau000412gfjnhadidf	cmk12kr4x000fo1hxdcjik7rt	5ec1d8518383519ccd4a4729aff2806303cd7440d157d299335c4f253cd14fea	2026-01-13 09:45:21.791	2026-01-27 09:45:21.784	\N	\N	\N	0
\.


--
-- Data for Name: NdaAcceptance; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."NdaAcceptance" (id, "orgId", "counterpartyOrgId", "ndaType", "ndaVersion", "enHashSha256", "acceptedByUserId", "acceptedAt", language, channel, "typedName", "typedRole", "createdAt") FROM stdin;
\.


--
-- Data for Name: NdaDocument; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."NdaDocument" (id, "ndaType", "ndaVersion", "enMarkdown", "summaryPl", "summaryDe", "summaryNl", "enHashSha256", "isActive", "createdAt", "updatedAt") FROM stdin;
cmk82fv01000drlysjzro5gr6	MUTUAL	Enabion_mutual_nda_v0.2_en	# Enabion Mutual Non-Disclosure Agreement (Mutual NDA)\n**Version:** Enabion_mutual_nda_v0.2_en  \n**Status:** Final (authorized)  \n**Effective Date:** {{EFFECTIVE_DATE}}  \n**Parties:**  \n1) **Enabion**: {{ENABION_LEGAL_NAME}}, {{ENABION_ADDRESS}}, {{ENABION_REGISTRY_ID}} ("**Enabion**")  \n2) **Counterparty**: {{COUNTERPARTY_LEGAL_NAME}}, {{COUNTERPARTY_ADDRESS}}, {{COUNTERPARTY_REGISTRY_ID}} ("**Counterparty**")  \n\nEnabion and Counterparty are each a "**Party**" and together the "**Parties**".\n\n> **Important notice (non-legal):** This Agreement is the Enabion standard Mutual NDA for the MVP pilot.\n\n---\n\n## 1. Purpose\nThe Parties wish to exchange certain information for the purpose of evaluating and/or pursuing potential business cooperation, including pre-sales discussions and possible project engagement(s) facilitated by the Enabion platform (the "**Purpose**").\n\n## 2. Definitions\n### 2.1 "Confidential Information"\n"**Confidential Information**" means any non-public information disclosed by or on behalf of a Party ("**Disclosing Party**") to the other Party ("**Receiving Party**"), whether in written, oral, visual, electronic or any other form, that is:\n- marked or identified as confidential, or\n- reasonably should be understood to be confidential given the nature of the information and the circumstances of disclosure.\n\nConfidential Information includes, without limitation: business plans, pricing, client information, proposals, software, source code, product roadmaps, technical data, security information, and any analyses, notes, summaries or derivatives made by the Receiving Party that contain or reflect such information.\n\n### 2.2 "Representatives"\n"**Representatives**" means a Party's employees, officers, directors, contractors, affiliates, professional advisors, and agents who have a need to know Confidential Information for the Purpose and are bound by confidentiality obligations at least as protective as those in this Agreement.\n\n### 2.3 Platform data levels (L1/L2)\nFor the MVP, the Parties may label information as:\n- **L1 (No-NDA Zone)**: information intended to be shareable without an NDA (e.g., high-level summaries).\n- **L2 (NDA-Required)**: information that must not be disclosed to the other Party unless the Mutual NDA is accepted.\n\nThis Agreement governs L2 disclosures. L1 information may still be treated as Confidential Information if it meets the definition in Section 2.1.\n\n## 3. Confidentiality Obligations\nThe Receiving Party shall:\n1) use the Disclosing Party's Confidential Information solely for the Purpose;\n2) keep the Confidential Information strictly confidential and protect it using at least the same degree of care it uses to protect its own confidential information, and no less than reasonable care;\n3) not disclose the Confidential Information to any third party except to its Representatives who have a need to know for the Purpose;\n4) ensure that its Representatives comply with this Agreement; and\n5) not copy, reverse engineer or decompile Confidential Information (including software) except as strictly necessary for the Purpose and as permitted by law.\n\n## 4. Exclusions\nConfidential Information does not include information that the Receiving Party can demonstrate with written records:\na) is or becomes publicly available through no breach of this Agreement;\nb) was lawfully known by the Receiving Party prior to disclosure;\nc) is independently developed by the Receiving Party without use of the Disclosing Party's Confidential Information; or\nd) is lawfully obtained from a third party without restriction.\n\n## 5. Compelled Disclosure\nIf the Receiving Party is required by law, regulation, court order or governmental authority to disclose Confidential Information, it shall (to the extent legally permitted) provide prompt written notice to the Disclosing Party and reasonably cooperate to seek protective treatment. The Receiving Party may disclose only the minimum amount required.\n\n## 6. Return / Destruction\nUpon written request by the Disclosing Party, the Receiving Party shall promptly return or destroy (and certify destruction of) the Disclosing Party's Confidential Information, except that the Receiving Party may retain:\n- one archival copy solely for legal/compliance purposes, and/or\n- copies stored automatically as part of routine system backups, provided such copies remain protected and are not accessed except for backup/restore operations.\n\n## 7. No License / No Obligation\nNo license or other rights are granted under this Agreement by disclosure of Confidential Information, whether by implication or otherwise. Nothing in this Agreement obligates either Party to proceed with any transaction or relationship.\n\n## 8. No Warranty\nAll Confidential Information is provided "as is" without warranties of any kind. The Disclosing Party does not guarantee completeness or accuracy.\n\n## 9. Term and Survival\n### 9.1 Term\nThis Agreement begins on the Effective Date and continues for **two (2) years**, unless terminated earlier by either Party upon thirty (30) days' written notice.\n\n### 9.2 Survival\nThe confidentiality obligations in this Agreement survive termination for **three (3) years** from the date of termination; however, with respect to trade secrets, such obligations survive as long as the information remains a trade secret under applicable law.\n\n## 10. Remedies\nThe Parties acknowledge that unauthorized disclosure or use of Confidential Information may cause irreparable harm. The Disclosing Party is entitled to seek injunctive or equitable relief in addition to any other remedies available at law.\n\n## 11. Governing Law and Jurisdiction\nThis Agreement shall be governed by the laws of **{{GOVERNING_LAW}}**, excluding its conflict-of-laws rules.  \nThe courts of **{{JURISDICTION}}** shall have exclusive jurisdiction, except that a Party may seek injunctive relief in any competent court.\n\n## 12. Miscellaneous\n- **Entire Agreement.** This Agreement constitutes the entire agreement between the Parties regarding the Purpose and supersedes prior discussions on confidentiality for the Purpose.\n- **Amendments.** Any amendment must be in writing and agreed by both Parties.\n- **Assignment.** Neither Party may assign this Agreement without the other Party's written consent, except to an affiliate in connection with a merger, acquisition or sale of substantially all assets.\n- **Severability.** If any provision is held invalid, the remainder remains in effect.\n- **Notices.** Notices shall be sent to the addresses stated above (or updated by written notice).\n- **Electronic Acceptance.** The Parties agree that electronic acceptance (including click-through acceptance in the Enabion application) may constitute valid acceptance of this Agreement, to the extent permitted by applicable law.\n- **Governing language.** In case of conflict, the English version prevails.\n\n---\n\n## Signatures\n**ENABION**  \nName: __________________________  \nTitle: __________________________  \nDate: __________________________  \n\n**COUNTERPARTY**  \nName: __________________________  \nTitle: __________________________  \nDate: __________________________  \n	# Enabion Mutual NDA - Summary (PL) - v0.2 (UI copy)\n\n> **Uwaga:** To jest skrót informacyjny (UI copy). Tekst prawnie wiążący jest w wersji EN: `Enabion_mutual_nda_v0.2_en`.\n\n## Co to jest?\nWzajemna umowa o poufności pomiędzy Enabion a drugą stroną (partnerem X<->Y), która pozwala wymieniać informacje **L2 (NDA-Required)** w procesie pre-sales.\n\n## Co chroni?\n- informacje handlowe i techniczne,\n- dane o klientach i projektach,\n- oferty, wyceny, warunki,\n- dokumenty i załączniki oznaczone jako L2,\n- notatki/analizy powstałe na bazie tych informacji.\n\n## Najważniejsze zobowiązania\n- używamy informacji tylko w celu oceny współpracy (Purpose),\n- nie ujawniamy osobom trzecim (poza upoważnionymi osobami w organizacji),\n- dbamy o bezpieczeństwo informacji co najmniej "rozsądnie",\n- po zakończeniu możemy zostać poproszeni o usunięcie/zwrot.\n\n## Czas trwania (wzorzec)\n- Umowa obowiązuje 2 lata,\n- obowiązek poufności: 3 lata po zakończeniu (dłużej dla tajemnic przedsiębiorstwa).\n\n## L1 vs L2 w aplikacji\n- L1: informacje do udostępniania bez NDA,\n- L2: dostępne dopiero po akceptacji Mutual NDA.\n	# Enabion Mutual NDA - Summary (DE) - v0.2 (UI copy)\n\n> **Hinweis:** Dies ist eine Zusammenfassung (UI-Text). Der rechtlich maßgebliche Text ist die EN-Version: `Enabion_mutual_nda_v0.2_en`.\n\n## Worum geht es?\nEine gegenseitige Vertraulichkeitsvereinbarung zwischen Enabion und der Gegenpartei (Partner X<->Y), um **L2 (NDA-Required)** Informationen im Pre-Sales-Prozess auszutauschen.\n\n## Was wird geschützt?\n- Geschäfts- und technische Informationen,\n- Kunden- und Projektdaten,\n- Angebote, Preise, Konditionen,\n- als L2 markierte Dokumente und Anhänge,\n- abgeleitete Notizen/Analysen.\n\n## Kernpflichten\n- Nutzung nur für den "Purpose" (Evaluierung/Kooperation),\n- keine Weitergabe an Dritte (außer autorisierte Personen),\n- angemessene Schutzmaßnahmen,\n- auf Anfrage Rückgabe/Löschung.\n\n## Dauer (Template)\n- Laufzeit 2 Jahre,\n- Vertraulichkeit: 3 Jahre nach Beendigung (länger bei Geschäftsgeheimnissen).\n\n## L1 vs L2 in der App\n- L1: ohne NDA teilbar,\n- L2: nur nach Annahme der Mutual NDA.\n	# Enabion Mutual NDA - Summary (NL) - v0.2 (UI copy)\n\n> **Let op:** Dit is een samenvatting (UI-tekst). De juridisch leidende tekst is de EN-versie: `Enabion_mutual_nda_v0.2_en`.\n\n## Wat is dit?\nEen wederzijdse geheimhoudingsovereenkomst tussen Enabion en de wederpartij (partner X<->Y) om **L2 (NDA-Required)** informatie uit te wisselen in pre-sales.\n\n## Wat wordt beschermd?\n- zakelijke en technische informatie,\n- klant- en projectinformatie,\n- offertes, prijzen, voorwaarden,\n- als L2 gemarkeerde documenten en bijlagen,\n- afgeleide notities/analyses.\n\n## Kernverplichtingen\n- gebruik alleen voor het doel ("Purpose"),\n- geen delen met derden (behalve geautoriseerde personen),\n- redelijke beveiliging,\n- op verzoek teruggeven/verwijderen.\n\n## Looptijd (template)\n- looptijd 2 jaar,\n- geheimhouding: 3 jaar na beëindiging (langer voor bedrijfsgeheimen).\n\n## L1 vs L2 in de app\n- L1: deelbaar zonder NDA,\n- L2: pas na acceptatie van Mutual NDA.\n	daf8f10807c4edbdca668b66ffe1e82d099023fe9a7da802a9a71f172ab838f9	f	2026-01-10 08:51:25.489	2026-01-10 09:23:22.937
cmk82gx3b000frlyscetkmbm9	MUTUAL	Enabion_mutual_nda_v0.3_en	# Enabion Mutual Non-Disclosure Agreement (Mutual NDA)\n**Version:** Enabion_mutual_nda_v0.3_en  \n**Status:** Final (authorized)  \n**Effective Date:** {{EFFECTIVE_DATE}}  \n**Parties:**  \n1) **Enabion**: {{ENABION_LEGAL_NAME}}, {{ENABION_ADDRESS}}, {{ENABION_REGISTRY_ID}} ("**Enabion**")  \n2) **Counterparty**: {{COUNTERPARTY_LEGAL_NAME}}, {{COUNTERPARTY_ADDRESS}}, {{COUNTERPARTY_REGISTRY_ID}} ("**Counterparty**")  \n\nEnabion and Counterparty are each a "**Party**" and together the "**Parties**".\n\n> **Important notice (non-legal):** This Agreement is the Enabion standard Mutual NDA for the MVP pilot.\n\n---\n\n## 1. Purpose\nThe Parties wish to exchange certain information for the purpose of evaluating and/or pursuing potential business cooperation, including pre-sales discussions and possible project engagement(s) facilitated by the Enabion platform (the "**Purpose**").\n\n## 2. Definitions\n### 2.1 "Confidential Information"\n"**Confidential Information**" means any non-public information disclosed by or on behalf of a Party ("**Disclosing Party**") to the other Party ("**Receiving Party**"), whether in written, oral, visual, electronic or any other form, that is:\n- marked or identified as confidential, or\n- reasonably should be understood to be confidential given the nature of the information and the circumstances of disclosure.\n\nConfidential Information includes, without limitation: business plans, pricing, client information, proposals, software, source code, product roadmaps, technical data, security information, and any analyses, notes, summaries or derivatives made by the Receiving Party that contain or reflect such information.\n\n### 2.2 "Representatives"\n"**Representatives**" means a Party's employees, officers, directors, contractors, affiliates, professional advisors, and agents who have a need to know Confidential Information for the Purpose and are bound by confidentiality obligations at least as protective as those in this Agreement.\n\n### 2.3 Platform data levels (L1/L2)\nFor the MVP, the Parties may label information as:\n- **L1 (No-NDA Zone)**: information intended to be shareable without an NDA (e.g., high-level summaries).\n- **L2 (NDA-Required)**: information that must not be disclosed to the other Party unless the Mutual NDA is accepted.\n\nThis Agreement governs L2 disclosures. L1 information may still be treated as Confidential Information if it meets the definition in Section 2.1.\n\n## 3. Confidentiality Obligations\nThe Receiving Party shall:\n1) use the Disclosing Party's Confidential Information solely for the Purpose;\n2) keep the Confidential Information strictly confidential and protect it using at least the same degree of care it uses to protect its own confidential information, and no less than reasonable care;\n3) not disclose the Confidential Information to any third party except to its Representatives who have a need to know for the Purpose;\n4) ensure that its Representatives comply with this Agreement; and\n5) not copy, reverse engineer or decompile Confidential Information (including software) except as strictly necessary for the Purpose and as permitted by law.\n\n## 4. Exclusions\nConfidential Information does not include information that the Receiving Party can demonstrate with written records:\na) is or becomes publicly available through no breach of this Agreement;\nb) was lawfully known by the Receiving Party prior to disclosure;\nc) is independently developed by the Receiving Party without use of the Disclosing Party's Confidential Information; or\nd) is lawfully obtained from a third party without restriction.\n\n## 5. Compelled Disclosure\nIf the Receiving Party is required by law, regulation, court order or governmental authority to disclose Confidential Information, it shall (to the extent legally permitted) provide prompt written notice to the Disclosing Party and reasonably cooperate to seek protective treatment. The Receiving Party may disclose only the minimum amount required.\n\n## 6. Return / Destruction\nUpon written request by the Disclosing Party, the Receiving Party shall promptly return or destroy (and certify destruction of) the Disclosing Party's Confidential Information, except that the Receiving Party may retain:\n- one archival copy solely for legal/compliance purposes, and/or\n- copies stored automatically as part of routine system backups, provided such copies remain protected and are not accessed except for backup/restore operations.\n\n## 7. No License / No Obligation\nNo license or other rights are granted under this Agreement by disclosure of Confidential Information, whether by implication or otherwise. Nothing in this Agreement obligates either Party to proceed with any transaction or relationship.\n\n## 8. No Warranty\nAll Confidential Information is provided "as is" without warranties of any kind. The Disclosing Party does not guarantee completeness or accuracy.\n\n## 9. Term and Survival\n### 9.1 Term\nThis Agreement begins on the Effective Date and continues for **two (2) years**, unless terminated earlier by either Party upon thirty (30) days' written notice.\n\n### 9.2 Survival\nThe confidentiality obligations in this Agreement survive termination for **three (3) years** from the date of termination; however, with respect to trade secrets, such obligations survive as long as the information remains a trade secret under applicable law.\n\n## 10. Remedies\nThe Parties acknowledge that unauthorized disclosure or use of Confidential Information may cause irreparable harm. The Disclosing Party is entitled to seek injunctive or equitable relief in addition to any other remedies available at law.\n\n## 11. Governing Law and Jurisdiction\nThis Agreement shall be governed by the laws of **{{GOVERNING_LAW}}**, excluding its conflict-of-laws rules.  \nThe courts of **{{JURISDICTION}}** shall have exclusive jurisdiction, except that a Party may seek injunctive relief in any competent court.\n\n## 12. Miscellaneous\n- **Entire Agreement.** This Agreement constitutes the entire agreement between the Parties regarding the Purpose and supersedes prior discussions on confidentiality for the Purpose.\n- **Amendments.** Any amendment must be in writing and agreed by both Parties.\n- **Assignment.** Neither Party may assign this Agreement without the other Party's written consent, except to an affiliate in connection with a merger, acquisition or sale of substantially all assets.\n- **Severability.** If any provision is held invalid, the remainder remains in effect.\n- **Notices.** Notices shall be sent to the addresses stated above (or updated by written notice).\n- **Electronic Acceptance.** The Parties agree that electronic acceptance (including click-through acceptance in the Enabion application) may constitute valid acceptance of this Agreement, to the extent permitted by applicable law.\n- **Governing language.** In case of conflict, the English version prevails.\n\n---\n\n## Signatures\n**ENABION**  \nName: __________________________  \nTitle: __________________________  \nDate: __________________________  \n\n**COUNTERPARTY**  \nName: __________________________  \nTitle: __________________________  \nDate: __________________________  \n	# Enabion Mutual NDA - Summary (PL) - v0.3 (UI copy)\n\n> **Uwaga:** To jest skrót informacyjny (UI copy). Tekst prawnie wiążący jest w wersji EN: `Enabion_mutual_nda_v0.3_en`.\n\n## Co to jest?\nWzajemna umowa o poufności pomiędzy Enabion a drugą stroną (partnerem X<->Y), która pozwala wymieniać informacje **L2 (NDA-Required)** w procesie pre-sales.\n\n## Co chroni?\n- informacje handlowe i techniczne,\n- dane o klientach i projektach,\n- oferty, wyceny, warunki,\n- dokumenty i załączniki oznaczone jako L2,\n- notatki/analizy powstałe na bazie tych informacji.\n\n## Najważniejsze zobowiązania\n- używamy informacji tylko w celu oceny współpracy (Purpose),\n- nie ujawniamy osobom trzecim (poza upoważnionymi osobami w organizacji),\n- dbamy o bezpieczeństwo informacji co najmniej "rozsądnie",\n- po zakończeniu możemy zostać poproszeni o usunięcie/zwrot.\n\n## Czas trwania (wzorzec)\n- Umowa obowiązuje 2 lata,\n- obowiązek poufności: 3 lata po zakończeniu (dłużej dla tajemnic przedsiębiorstwa).\n\n## L1 vs L2 w aplikacji\n- L1: informacje do udostępniania bez NDA,\n- L2: dostępne dopiero po akceptacji Mutual NDA.\n	# Enabion Mutual NDA - Summary (DE) - v0.3 (UI copy)\n\n> **Hinweis:** Dies ist eine Zusammenfassung (UI-Text). Der rechtlich maßgebliche Text ist die EN-Version: `Enabion_mutual_nda_v0.3_en`.\n\n## Worum geht es?\nEine gegenseitige Vertraulichkeitsvereinbarung zwischen Enabion und der Gegenpartei (Partner X<->Y), um **L2 (NDA-Required)** Informationen im Pre-Sales-Prozess auszutauschen.\n\n## Was wird geschützt?\n- Geschäfts- und technische Informationen,\n- Kunden- und Projektdaten,\n- Angebote, Preise, Konditionen,\n- als L2 markierte Dokumente und Anhänge,\n- abgeleitete Notizen/Analysen.\n\n## Kernpflichten\n- Nutzung nur für den "Purpose" (Evaluierung/Kooperation),\n- keine Weitergabe an Dritte (außer autorisierte Personen),\n- angemessene Schutzmaßnahmen,\n- auf Anfrage Rückgabe/Löschung.\n\n## Dauer (Template)\n- Laufzeit 2 Jahre,\n- Vertraulichkeit: 3 Jahre nach Beendigung (länger bei Geschäftsgeheimnissen).\n\n## L1 vs L2 in der App\n- L1: ohne NDA teilbar,\n- L2: nur nach Annahme der Mutual NDA.\n	# Enabion Mutual NDA - Summary (NL) - v0.3 (UI copy)\n\n> **Let op:** Dit is een samenvatting (UI-tekst). De juridisch leidende tekst is de EN-versie: `Enabion_mutual_nda_v0.3_en`.\n\n## Wat is dit?\nEen wederzijdse geheimhoudingsovereenkomst tussen Enabion en de wederpartij (partner X<->Y) om **L2 (NDA-Required)** informatie uit te wisselen in pre-sales.\n\n## Wat wordt beschermd?\n- zakelijke en technische informatie,\n- klant- en projectinformatie,\n- offertes, prijzen, voorwaarden,\n- als L2 gemarkeerde documenten en bijlagen,\n- afgeleide notities/analyses.\n\n## Kernverplichtingen\n- gebruik alleen voor het doel ("Purpose"),\n- geen delen met derden (behalve geautoriseerde personen),\n- redelijke beveiliging,\n- op verzoek teruggeven/verwijderen.\n\n## Looptijd (template)\n- looptijd 2 jaar,\n- geheimhouding: 3 jaar na beëindiging (langer voor bedrijfsgeheimen).\n\n## L1 vs L2 in de app\n- L1: deelbaar zonder NDA,\n- L2: pas na acceptatie van Mutual NDA.\n	2b379be36c5d227ec61d99c573791e19e6bac2b16542b650d24559ceee39e697	f	2026-01-10 08:52:14.855	2026-01-10 09:24:05.259
cmk83lv680009fbz0rv7s91fk	MUTUAL	Enabion_mutual_nda_v0.1_en	# Enabion Mutual Non-Disclosure Agreement (Mutual NDA)\n**Version:** Enabion_mutual_nda_v0.1_en  \n**Status:** Final (authorized)  \n**Effective Date:** {{EFFECTIVE_DATE}}  \n**Parties:**  \n1) **Enabion**: {{ENABION_LEGAL_NAME}}, {{ENABION_ADDRESS}}, {{ENABION_REGISTRY_ID}} ("**Enabion**")  \n2) **Counterparty**: {{COUNTERPARTY_LEGAL_NAME}}, {{COUNTERPARTY_ADDRESS}}, {{COUNTERPARTY_REGISTRY_ID}} ("**Counterparty**")  \n\nEnabion and Counterparty are each a "**Party**" and together the "**Parties**".\n\n> **Important notice (non-legal):** This Agreement is the Enabion standard Mutual NDA for the MVP pilot.\n\n---\n\n## 1. Purpose\nThe Parties wish to exchange certain information for the purpose of evaluating and/or pursuing potential business cooperation, including pre-sales discussions and possible project engagement(s) facilitated by the Enabion platform (the "**Purpose**").\n\n## 2. Definitions\n### 2.1 "Confidential Information"\n"**Confidential Information**" means any non-public information disclosed by or on behalf of a Party ("**Disclosing Party**") to the other Party ("**Receiving Party**"), whether in written, oral, visual, electronic or any other form, that is:\n- marked or identified as confidential, or\n- reasonably should be understood to be confidential given the nature of the information and the circumstances of disclosure.\n\nConfidential Information includes, without limitation: business plans, pricing, client information, proposals, software, source code, product roadmaps, technical data, security information, and any analyses, notes, summaries or derivatives made by the Receiving Party that contain or reflect such information.\n\n### 2.2 "Representatives"\n"**Representatives**" means a Party's employees, officers, directors, contractors, affiliates, professional advisors, and agents who have a need to know Confidential Information for the Purpose and are bound by confidentiality obligations at least as protective as those in this Agreement.\n\n### 2.3 Platform data levels (L1/L2)\nFor the MVP, the Parties may label information as:\n- **L1 (No-NDA Zone)**: information intended to be shareable without an NDA (e.g., high-level summaries).\n- **L2 (NDA-Required)**: information that must not be disclosed to the other Party unless the Mutual NDA is accepted.\n\nThis Agreement governs L2 disclosures. L1 information may still be treated as Confidential Information if it meets the definition in Section 2.1.\n\n## 3. Confidentiality Obligations\nThe Receiving Party shall:\n1) use the Disclosing Party's Confidential Information solely for the Purpose;\n2) keep the Confidential Information strictly confidential and protect it using at least the same degree of care it uses to protect its own confidential information, and no less than reasonable care;\n3) not disclose the Confidential Information to any third party except to its Representatives who have a need to know for the Purpose;\n4) ensure that its Representatives comply with this Agreement; and\n5) not copy, reverse engineer or decompile Confidential Information (including software) except as strictly necessary for the Purpose and as permitted by law.\n\n## 4. Exclusions\nConfidential Information does not include information that the Receiving Party can demonstrate with written records:\na) is or becomes publicly available through no breach of this Agreement;\nb) was lawfully known by the Receiving Party prior to disclosure;\nc) is independently developed by the Receiving Party without use of the Disclosing Party's Confidential Information; or\nd) is lawfully obtained from a third party without restriction.\n\n## 5. Compelled Disclosure\nIf the Receiving Party is required by law, regulation, court order or governmental authority to disclose Confidential Information, it shall (to the extent legally permitted) provide prompt written notice to the Disclosing Party and reasonably cooperate to seek protective treatment. The Receiving Party may disclose only the minimum amount required.\n\n## 6. Return / Destruction\nUpon written request by the Disclosing Party, the Receiving Party shall promptly return or destroy (and certify destruction of) the Disclosing Party's Confidential Information, except that the Receiving Party may retain:\n- one archival copy solely for legal/compliance purposes, and/or\n- copies stored automatically as part of routine system backups, provided such copies remain protected and are not accessed except for backup/restore operations.\n\n## 7. No License / No Obligation\nNo license or other rights are granted under this Agreement by disclosure of Confidential Information, whether by implication or otherwise. Nothing in this Agreement obligates either Party to proceed with any transaction or relationship.\n\n## 8. No Warranty\nAll Confidential Information is provided "as is" without warranties of any kind. The Disclosing Party does not guarantee completeness or accuracy.\n\n## 9. Term and Survival\n### 9.1 Term\nThis Agreement begins on the Effective Date and continues for **two (2) years**, unless terminated earlier by either Party upon thirty (30) days' written notice.\n\n### 9.2 Survival\nThe confidentiality obligations in this Agreement survive termination for **three (3) years** from the date of termination; however, with respect to trade secrets, such obligations survive as long as the information remains a trade secret under applicable law.\n\n## 10. Remedies\nThe Parties acknowledge that unauthorized disclosure or use of Confidential Information may cause irreparable harm. The Disclosing Party is entitled to seek injunctive or equitable relief in addition to any other remedies available at law.\n\n## 11. Governing Law and Jurisdiction\nThis Agreement shall be governed by the laws of **{{GOVERNING_LAW}}**, excluding its conflict-of-laws rules.  \nThe courts of **{{JURISDICTION}}** shall have exclusive jurisdiction, except that a Party may seek injunctive relief in any competent court.\n\n## 12. Miscellaneous\n- **Entire Agreement.** This Agreement constitutes the entire agreement between the Parties regarding the Purpose and supersedes prior discussions on confidentiality for the Purpose.\n- **Amendments.** Any amendment must be in writing and agreed by both Parties.\n- **Assignment.** Neither Party may assign this Agreement without the other Party's written consent, except to an affiliate in connection with a merger, acquisition or sale of substantially all assets.\n- **Severability.** If any provision is held invalid, the remainder remains in effect.\n- **Notices.** Notices shall be sent to the addresses stated above (or updated by written notice).\n- **Electronic Acceptance.** The Parties agree that electronic acceptance (including click-through acceptance in the Enabion application) may constitute valid acceptance of this Agreement, to the extent permitted by applicable law.\n- **Governing language.** In case of conflict, the English version prevails.\n\n---\n\n## Signatures\n**ENABION**  \nName: __________________________  \nTitle: __________________________  \nDate: __________________________  \n\n**COUNTERPARTY**  \nName: __________________________  \nTitle: __________________________  \nDate: __________________________  \n	# Enabion Mutual NDA - Summary (PL) - v0.1 (UI copy)\n\n> **Uwaga:** To jest skrót informacyjny (UI copy). Tekst prawnie wiążący jest w wersji EN: `Enabion_mutual_nda_v0.1_en`.\n\n## Co to jest?\nWzajemna umowa o poufności pomiędzy Enabion a drugą stroną (partnerem X<->Y), która pozwala wymieniać informacje **L2 (NDA-Required)** w procesie pre-sales.\n\n## Co chroni?\n- informacje handlowe i techniczne,\n- dane o klientach i projektach,\n- oferty, wyceny, warunki,\n- dokumenty i załączniki oznaczone jako L2,\n- notatki/analizy powstałe na bazie tych informacji.\n\n## Najważniejsze zobowiązania\n- używamy informacji tylko w celu oceny współpracy (Purpose),\n- nie ujawniamy osobom trzecim (poza upoważnionymi osobami w organizacji),\n- dbamy o bezpieczeństwo informacji co najmniej "rozsądnie",\n- po zakończeniu możemy zostać poproszeni o usunięcie/zwrot.\n\n## Czas trwania (wzorzec)\n- Umowa obowiązuje 2 lata,\n- obowiązek poufności: 3 lata po zakończeniu (dłużej dla tajemnic przedsiębiorstwa).\n\n## L1 vs L2 w aplikacji\n- L1: informacje do udostępniania bez NDA,\n- L2: dostępne dopiero po akceptacji Mutual NDA.\n	# Enabion Mutual NDA - Summary (DE) - v0.1 (UI copy)\n\n> **Hinweis:** Dies ist eine Zusammenfassung (UI-Text). Der rechtlich maßgebliche Text ist die EN-Version: `Enabion_mutual_nda_v0.1_en`.\n\n## Worum geht es?\nEine gegenseitige Vertraulichkeitsvereinbarung zwischen Enabion und der Gegenpartei (Partner X<->Y), um **L2 (NDA-Required)** Informationen im Pre-Sales-Prozess auszutauschen.\n\n## Was wird geschützt?\n- Geschäfts- und technische Informationen,\n- Kunden- und Projektdaten,\n- Angebote, Preise, Konditionen,\n- als L2 markierte Dokumente und Anhänge,\n- abgeleitete Notizen/Analysen.\n\n## Kernpflichten\n- Nutzung nur für den "Purpose" (Evaluierung/Kooperation),\n- keine Weitergabe an Dritte (außer autorisierte Personen),\n- angemessene Schutzmaßnahmen,\n- auf Anfrage Rückgabe/Löschung.\n\n## Dauer (Template)\n- Laufzeit 2 Jahre,\n- Vertraulichkeit: 3 Jahre nach Beendigung (länger bei Geschäftsgeheimnissen).\n\n## L1 vs L2 in der App\n- L1: ohne NDA teilbar,\n- L2: nur nach Annahme der Mutual NDA.\n	# Enabion Mutual NDA - Summary (NL) - v0.1 (UI copy)\n\n> **Let op:** Dit is een samenvatting (UI-tekst). De juridisch leidende tekst is de EN-versie: `Enabion_mutual_nda_v0.1_en`.\n\n## Wat is dit?\nEen wederzijdse geheimhoudingsovereenkomst tussen Enabion en de wederpartij (partner X<->Y) om **L2 (NDA-Required)** informatie uit te wisselen in pre-sales.\n\n## Wat wordt beschermd?\n- zakelijke en technische informatie,\n- klant- en projectinformatie,\n- offertes, prijzen, voorwaarden,\n- als L2 gemarkeerde documenten en bijlagen,\n- afgeleide notities/analyses.\n\n## Kernverplichtingen\n- gebruik alleen voor het doel ("Purpose"),\n- geen delen met derden (behalve geautoriseerde personen),\n- redelijke beveiliging,\n- op verzoek teruggeven/verwijderen.\n\n## Looptijd (template)\n- looptijd 2 jaar,\n- geheimhouding: 3 jaar na beëindiging (langer voor bedrijfsgeheimen).\n\n## L1 vs L2 in de app\n- L1: deelbaar zonder NDA,\n- L2: pas na acceptatie van Mutual NDA.\n	9ed55f618aab2662e3137c3aa2eaa86fcccd655d6d060e26664864b6509cbffd	t	2026-01-10 09:24:05.264	2026-01-10 09:24:05.264
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Organization" (id, name, "createdAt", slug, "defaultLanguage", "policyAiEnabled", "policyShareLinksEnabled", "policyEmailIngestEnabled", status) FROM stdin;
cmjdakp0f0001ut2uv0n881s3	TEST01	2025-12-19 19:58:16.479	test01	EN	t	f	f	ACTIVE
cmje0pkpu000dut2u1z41ciku	TEST02	2025-12-20 08:09:54.21	test02	EN	t	f	f	ACTIVE
cmjejbes70007o1hxngxzzzw7	TEST03	2025-12-20 16:50:46.04	test03	EN	t	f	f	ACTIVE
cmk736hrf0007oyv7jcxtvn9k	Admin	2026-01-09 16:24:21.868	admin-01	EN	t	f	f	ACTIVE
cmk48grgv0006bmbcmahvvpfc	Admin	2026-01-07 16:29:00.559	admin	EN	t	f	f	ACTIVE
cmk12kr4u000do1hxva29zgyd	TEST01 Nazwa Testowa	2026-01-05 11:20:50.527	test01-tname	EN	t	f	f	ACTIVE
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."PasswordResetToken" (id, "userId", "tokenHash", "createdAt", "expiresAt", "usedAt") FROM stdin;
cmk13vhpg000213n32bejppkt	cmk12kr4x000fo1hxdcjik7rt	c3562318e2156a8ff438ebf8e79e2ac11f11a48b28f2dd1e57db10bf96a7d6c6	2026-01-05 11:57:11.14	2026-01-05 12:27:11.132	2026-01-05 12:03:25.09
cmk143i94000513n3w2do6ecr	cmk12kr4x000fo1hxdcjik7rt	543b5f1d7ddc3f065a68c072623aab4dac2fec4a3cd580213f446ce029446401	2026-01-05 12:03:25.096	2026-01-05 12:33:25.09	\N
cmk15e0kq0002ya7ahsshryg5	cmk12kr4x000fo1hxdcjik7rt	1271e4f51647d48b75ea1681d394c5140d630623f7d4e72379106790553c2b14	2026-01-05 12:39:35.019	2026-01-05 13:09:35.011	2026-01-05 12:48:55.83
cmk15q1b00005ya7af25k5v22	cmk12kr4x000fo1hxdcjik7rt	d412f11f7e6fc4efda36613bb833e8cc9c7c9861c8c4c338e95942f5ae7dd9d1	2026-01-05 12:48:55.837	2026-01-05 13:18:55.83	\N
cmk18urgn0008ya7aephyu2jp	cmk12kr4x000fo1hxdcjik7rt	78dc8414fdb9f49b98fb2dd030de383cb6446228ad663c337d342cc8976a47f3	2026-01-05 14:16:35.208	2026-01-05 14:46:35.202	\N
cmk3r88wk000bya7av3fodj38	cmk12kr4x000fo1hxdcjik7rt	ed051623d7929ebeaa3fb18b5ee50ff9b28e4e5a202ea3ab81aef8c80e4fe370	2026-01-07 08:26:29.78	2026-01-07 08:56:29.773	2026-01-07 08:27:57.22
cmk3ra4dj000eya7aou676wpg	cmk12kr4x000fo1hxdcjik7rt	dcc6647e610d759e5bffe285c190ba8a8de9389d032d4015c8dd2ac74fece76f	2026-01-07 08:27:57.224	2026-01-07 08:57:57.22	2026-01-07 08:38:20.847
cmk3rnhkl000hya7aaxdi1t10	cmk12kr4x000fo1hxdcjik7rt	007bda03a336dc074d1d62761569ce7a436c1b36f8191c3680fe2fe843d759dc	2026-01-07 08:38:20.853	2026-01-07 09:08:20.847	2026-01-07 08:42:24.537
cmk3rsplo000kya7a6zutneko	cmk12kr4x000fo1hxdcjik7rt	8a7efca7a22fdc722dee43670485e4ba54ab105556b76cbbe79d9a1fa3b75bff	2026-01-07 08:42:24.541	2026-01-07 09:12:24.537	\N
cmk3ztnyi000215kosdnx7uui	cmk12kr4x000fo1hxdcjik7rt	1d387dc20d83be22f5f0d649da0e20c6976261cfc40fb241690fc28dca60a98d	2026-01-07 12:27:05.994	2026-01-07 12:57:05.987	2026-01-07 12:29:47.315
cmk400c770002kr4xvoalh8i3	cmk12kr4x000fo1hxdcjik7rt	2bb28a593c3d42535035c6ec44db10009de9c82b20b7586be77bb55940aea67e	2026-01-07 12:32:17.347	2026-01-07 13:02:17.338	\N
cmk41o0hr0002i0v0dn8en4kf	cmk12kr4x000fo1hxdcjik7rt	7c0dc7ff849d862d0a832e4625678f9c23ae1440d34a60fd108ddfb659894af6	2026-01-07 13:18:41.536	2026-01-07 13:48:41.527	2026-01-07 13:19:18.984
cmk482b510004bmbc6a4l42az	cmk482b4p0001bmbck6q90zvv	618631a59eb1fedf7084ebd689afa8c0bfd3ae4a7bad4cbb1374559df16ba27a	2026-01-07 16:17:46.213	2026-01-07 16:47:46.206	\N
cmk6uu9xt00028cfegbsjaca4	cmk12kr4x000fo1hxdcjik7rt	c323e7ebbbc5f339bfc6a4781d631222249a0f0a328cd4d04ac12d73e9570110	2026-01-09 12:30:54.929	2026-01-09 13:00:54.922	2026-01-09 12:34:03.534
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Session" (id, "userId", "tokenHash", "createdAt", "expiresAt", "revokedAt") FROM stdin;
cmjdakp0p0005ut2uz4saqcrf	cmjdakp0k0003ut2ufp00eqzv	6d56a5096834c4876cbe9309194e9b227be23cbc8fc7ff8f3cda1ff07cf1b11b	2025-12-19 19:58:16.489	2025-12-20 07:58:16.457	2025-12-19 19:58:31.487
cmjdalfiq0008ut2u50saciqk	cmjdakp0k0003ut2ufp00eqzv	2abe08b56945dc697dd0e0cfbd34d5887fc64187b396f551eead41b83f49a824	2025-12-19 19:58:50.834	2025-12-20 07:58:50.829	2025-12-19 19:58:58.566
cmje0ourm000but2usyvwb2tw	cmjdakp0k0003ut2ufp00eqzv	546703cdbc1069fedf25aa0417c1297f272cefcfe48159a5ecaf9b03d3ea9be4	2025-12-20 08:09:20.579	2025-12-20 20:09:20.572	2025-12-20 08:09:38.086
cmje0pkpz000hut2u9qbj5swy	cmje0pkpw000fut2uqq8am6xm	b10b4f89e9ff9518994de75f92e0fa7ad8c8f506e32209e5d9d2cfe5939ec3fc	2025-12-20 08:09:54.215	2025-12-20 20:09:54.208	2025-12-20 08:11:16.568
cmje0vlx7000kut2umcar3fvt	cmje0pkpw000fut2uqq8am6xm	464800ef4086290da2e55c5ff64d5edf85fccdc546e7adfe858cb5b7f27b5498	2025-12-20 08:14:35.708	2025-12-20 20:14:35.703	2025-12-20 08:14:44.247
cmje0wap1000rut2ut8mdyltc	cmje0pkpw000fut2uqq8am6xm	68a0c7179497b92211be8753501651f2a66130332f4aba20c0c6131b8d869039	2025-12-20 08:15:07.814	2025-12-20 20:15:07.809	2025-12-20 08:30:10.291
cmje1fpal0002tvgv5d0v0jq4	cmje0pkpw000fut2uqq8am6xm	ce7e6959c4a404f69ab1507e736cdc9965fcff5c8484c55079cb448ad054e9ba	2025-12-20 08:30:13.198	2025-12-20 20:30:13.188	2025-12-20 08:30:21.316
cmje1tdi80005tvgvyduak82j	cmje0pkpw000fut2uqq8am6xm	6ec231c9361b29c3f57fccf7c7bc90308834f728c7f93d258dfe8846d1f808a9	2025-12-20 08:40:51.105	2025-12-20 20:40:51.099	2025-12-20 16:27:48.742
cmjeihzjs0002g1h76qvc4v6y	cmjdakp0k0003ut2ufp00eqzv	a14a03bc80d39daf86a859c071d228b35eadc3556c5b13d2e82ec7c119333782	2025-12-20 16:27:53.272	2025-12-21 04:27:53.266	2025-12-20 16:27:55.144
cmjeiqwr10002o1hxa6cnazc3	cmjdakp0k0003ut2ufp00eqzv	7ba49e2058dfe35f3fa62781ffba9d771eda4d61ee40a16b0c0b138f7c0c76ef	2025-12-20 16:34:49.55	2025-12-21 04:34:49.544	2025-12-20 16:34:51.486
cmjejb5ic0005o1hxkowop4vc	cmjdakp0k0003ut2ufp00eqzv	865f6f18b726a476c39a781a9dd82ce9377ad416aef9234612ef6483928f5adc	2025-12-20 16:50:34.021	2025-12-21 04:50:34.014	2025-12-20 16:50:35.564
cmjejbesc000bo1hx5jfbo3ea	cmjejbesa0009o1hxza9o6wpx	95902237da6065a42f45c46ec4b42ee6939924e3f64413b6dc86b7f007a9de38	2025-12-20 16:50:46.044	2025-12-21 04:50:46.037	2025-12-20 16:50:48.767
cmk12kr50000ho1hxukaj9r7i	cmk12kr4x000fo1hxdcjik7rt	8f1d32c38b63acb1f26dfdb69972d61cae09ed2be5c7ceea0ba298e087c74e9f	2026-01-05 11:20:50.532	2026-01-05 23:20:50.508	2026-01-05 11:28:32.133
cmk12upp9000ko1hxepfys1ze	cmk12kr4x000fo1hxdcjik7rt	f9a38f2440b0804766bff43cd7ee32944c65fd71bc8484611d3e8782d6664a21	2026-01-05 11:28:35.229	2026-01-05 23:28:35.225	2026-01-05 11:28:37.426
cmk3zxg3z000615kox8o064g4	cmk12kr4x000fo1hxdcjik7rt	7e321e874017d1aceed5793cbaea04b7b9e9587c0e271553b7f4765ee046fdbc	2026-01-07 12:30:02.448	2026-01-08 00:30:02.437	2026-01-07 13:18:29.306
cmk41p0on0006i0v0f9yumxui	cmk12kr4x000fo1hxdcjik7rt	0a6fc8dec9abbafc05f7515edc5da85584c305abc3381698840b19ebc7014304	2026-01-07 13:19:28.439	2026-01-08 01:19:28.433	2026-01-07 13:45:12.137
cmk469msl0002t8cit8rq2pux	cmk12kr4x000fo1hxdcjik7rt	af229bf5c7460ce36903813d9a4a724b90f7a61f227c106949f3e656a4b119f0	2026-01-07 15:27:28.678	2026-01-08 03:27:28.67	2026-01-07 15:30:54.478
cmk46e8g90005t8ci4a1tj9xw	cmk12kr4x000fo1hxdcjik7rt	9b5d71870b57b2d6bc047563c37adf13a2267aba845048330f99d726f923aa18	2026-01-07 15:31:03.369	2026-01-08 03:31:03.364	2026-01-07 16:28:28.161
cmk48grh3000abmbc9dwdqdp1	cmk48grgz0008bmbcp8s2vrap	deffbf93d25a49fa2b4d5ec715c447fd5c0328d46f2c3a5918a014a08a7cfb52	2026-01-07 16:29:00.567	2026-01-08 04:29:00.552	2026-01-07 16:29:21.784
cmk49wfky000210ufpmjytmgm	cmk48grgz0008bmbcp8s2vrap	7e0cbd5db1e1385ac1688e56ba9df00ce795c4284966ae6e9f3a9457bacdab02	2026-01-07 17:09:11.266	2026-01-08 05:09:11.258	\N
cmk5cgu36000510ufair0t79h	cmk48grgz0008bmbcp8s2vrap	de9bb6d4295120b03692d3864591ac24b8b25e3d49a2b529e48b950554f21536	2026-01-08 11:08:48.594	2026-01-08 23:08:48.588	2026-01-08 11:53:55.095
cmk5e2w7q000810ufvs1whblh	cmk48grgz0008bmbcp8s2vrap	9399b61e599071383b5fb2544ac47428705ae093478f6ecd57f6bd23e7dcb257	2026-01-08 11:53:57.398	2026-01-08 23:53:57.392	2026-01-08 12:08:53.584
cmk5em84v0002h66lyo9xac54	cmk12kr4x000fo1hxdcjik7rt	f8514d7671ec0352d2dc44086390dfaab71a62c14e9298783327649d15384eb2	2026-01-08 12:08:59.311	2026-01-09 00:08:59.303	2026-01-08 12:10:18.565
cmk5enza40005h66lh94scp4y	cmk12kr4x000fo1hxdcjik7rt	8894efb39dbe5778c52dd36665c150d382d85ace814b8343b400cd638f6608fd	2026-01-08 12:10:21.148	2026-01-09 00:10:21.143	2026-01-08 12:11:11.956
cmk5eppc20008h66lovk0zw5j	cmk12kr4x000fo1hxdcjik7rt	077d03a5cb48c1fb365a725cf79907cb9e91c7b3fe36866f925e4ba5dd24d0a2	2026-01-08 12:11:41.571	2026-01-09 00:11:41.565	2026-01-08 12:19:13.619
cmk5ezfop000bh66lppwyol68	cmk12kr4x000fo1hxdcjik7rt	adc5dcc10777758b8e78acd37c7ff0470f46c052f099d043bed0f352e7bc250b	2026-01-08 12:19:15.625	2026-01-09 00:19:15.62	2026-01-08 12:35:24.901
cmk5fk9aw00029x9sqe9w53g9	cmk12kr4x000fo1hxdcjik7rt	7e7ddd9626bb9a586eaec5fd91486f8338b7ca4b34f352dead1f1ca7bdb02914	2026-01-08 12:35:27.128	2026-01-09 00:35:27.116	2026-01-08 12:35:47.314
cmk5fkrt300059x9s3dod0n47	cmk48grgz0008bmbcp8s2vrap	f2d31a13e05abaf23f6abfee858ab38fd947b7314bd9dcb9f1def4fc4c7e29f0	2026-01-08 12:35:51.112	2026-01-09 00:35:51.105	2026-01-08 12:49:48.981
cmk5g2s6u000210ytbbztu53x	cmk48grgz0008bmbcp8s2vrap	729738d921dee21d8e03d8354775a0ec6daec6d05d96fc51ec8c4957d38f3760	2026-01-08 12:49:51.414	2026-01-09 00:49:51.406	2026-01-08 12:50:16.005
cmk5g3evh000510ytxdm5ju30	cmk12kr4x000fo1hxdcjik7rt	703581d54e29bd8a8be584eedd89976204393e94e633ff98aced6eea3b34f687	2026-01-08 12:50:20.814	2026-01-09 00:50:20.807	2026-01-08 12:50:25.492
cmk5g3lbl000810yt15ql6i2o	cmk48grgz0008bmbcp8s2vrap	8c82d7c1d17dfbaffe1c0f9179e9aa024192a2302775ff0572295fe6283d2d70	2026-01-08 12:50:29.169	2026-01-09 00:50:29.164	2026-01-08 12:50:52.986
cmk5hv5jv000b10ytbdyu1ki8	cmk48grgz0008bmbcp8s2vrap	35f7fb00a14d837907dbbab4fafcd783bf8b4dc775669a7edfdbdd192c6ccb29	2026-01-08 13:39:54.715	2026-01-09 01:39:54.708	2026-01-08 13:40:36.775
cmk5hw3jt000e10yt4vt51e33	cmk48grgz0008bmbcp8s2vrap	de5fdec9851725ab255967872e05c65143bb4d819c31b51d375e9a38ff615af5	2026-01-08 13:40:38.777	2026-01-09 01:40:38.77	2026-01-08 13:41:21.159
cmk5hx4ut000h10ytxlbssx14	cmk12kr4x000fo1hxdcjik7rt	07de0bb826eb5b8e0220119c46f594dad06f81eb57cbf5ca4750d97fae8b875a	2026-01-08 13:41:27.126	2026-01-09 01:41:27.121	2026-01-08 14:20:53.236
cmk5jbwbl0002bdrs3rx68h66	cmk12kr4x000fo1hxdcjik7rt	2e7bcf654fa81ec16380481c32aa60d21477b5a833eec4d2e37507b0e7626b91	2026-01-08 14:20:55.521	2026-01-09 02:20:55.512	2026-01-08 15:07:48.194
cmk5l08d30009bdrscqqo00b9	cmk12kr4x000fo1hxdcjik7rt	8c4f268aa501a41390e1ca6faa677fbcfc39488f6bca8cf6d402daeb38ddbcf8	2026-01-08 15:07:50.487	2026-01-09 03:07:50.48	2026-01-08 15:08:36.261
cmk5l1big000cbdrs69eubfa2	cmk12kr4x000fo1hxdcjik7rt	33504d8c2fb9f1348be4e0ba8cbe8043699874e3f5b8235ed7944e26eb636d98	2026-01-08 15:08:41.224	2026-01-09 03:08:41.219	2026-01-08 15:14:55.509
cmk5l9e9x000fbdrsh05vepg4	cmk12kr4x000fo1hxdcjik7rt	c686f63eeeaa42c490096cdfc8b29dd789644f8b320070cd11f324d25e6860fc	2026-01-08 15:14:58.053	2026-01-09 03:14:58.049	2026-01-08 15:45:02.817
cmk46etry0008t8cia912fv9m	cmk12kr4x000fo1hxdcjik7rt	6b6712f99776212877f4a714d5d6d64daf87330f9004f9cf8d9ef5553ba0a4f9	2026-01-07 15:31:31.006	2026-01-08 03:31:31.001	2026-01-09 12:34:03.534
cmk5mc4mj000ibdrs149u8m0e	cmk12kr4x000fo1hxdcjik7rt	ef923628285fe12a9ca8b6b85484f8e920e4c09547d6997e024a4d4f3657fd51	2026-01-08 15:45:05.132	2026-01-09 03:45:05.112	2026-01-08 19:02:27.834
cmk6kemgs000r134140cvgzis	cmk12kr4x000fo1hxdcjik7rt	3e94c425ecec70a2f1276ce9b9e8b012390bfb12c16dd8f8e0b9288986a5fe38	2026-01-09 07:38:48.508	2026-01-09 19:38:48.501	2026-01-09 08:57:08.809
cmk6n7f55000u1341ji6dhf3k	cmk12kr4x000fo1hxdcjik7rt	1b8673bb64b5e83f371e36a2cd45dc8d304a16732e5226be88bf16fbe0316ee0	2026-01-09 08:57:11.273	2026-01-09 20:57:11.268	2026-01-09 10:01:23.757
cmk6pi2yd00021fdlkit62p0v	cmk48grgz0008bmbcp8s2vrap	75c6b39c67c6a98efd1de4a14134b05554a5f5e0879c86e708c7318796149ffc	2026-01-09 10:01:27.926	2026-01-09 22:01:27.919	2026-01-09 10:04:20.184
cmk6plus000051fdl5g7gcl8a	cmjdakp0k0003ut2ufp00eqzv	7d2e847f2d9f6ffb6d77d382c1f5ab0e0530e81d7d244bab5e1ff08d980a6571	2026-01-09 10:04:23.953	2026-01-09 22:04:23.946	\N
cmk6s4p0x0002u9ict4dj6ivv	cmk12kr4x000fo1hxdcjik7rt	44f3ec8239dda292cb82cc987d2e861ae7a910bdc8af62182b9da29f1394cf52	2026-01-09 11:15:02.194	2026-01-09 23:15:02.179	2026-01-09 11:25:05.531
cmk5mk5pi000lbdrsoh4u8722	cmk12kr4x000fo1hxdcjik7rt	217dadda5e827fdbe68a4cb116223e35311c6299f845d8e2e215181fbf2b3667	2026-01-08 15:51:19.783	2026-01-09 03:51:19.777	2026-01-09 12:34:03.534
cmk5mv1yq000obdrs9tcnuzz3	cmk12kr4x000fo1hxdcjik7rt	05438f3fb81083bcfcb2486cc5d2873d20edab46c8c0491125f239bc8bf84367	2026-01-08 15:59:48.146	2026-01-09 03:59:48.141	2026-01-09 12:34:03.534
cmk5mvpxz000rbdrs6i5po5wz	cmk12kr4x000fo1hxdcjik7rt	ac484b8cda6572c49c9b24bf01f11ee1786c01dd85ee5432517a51f28cf3db8c	2026-01-08 16:00:19.224	2026-01-09 04:00:19.217	2026-01-09 12:34:03.534
cmk5mwwl3000ubdrs0kuwp3tt	cmk12kr4x000fo1hxdcjik7rt	9bfbca5010701b06eb77225008829f009397f01a08db92a5c8d2811e80e4dfdc	2026-01-08 16:01:14.487	2026-01-09 04:01:14.481	2026-01-09 12:34:03.534
cmk5mxehr000xbdrsib5u6lqf	cmk12kr4x000fo1hxdcjik7rt	4dcf618ef054382057b65641dbf0a365725fd473d93e65e204b8d6c78d866097	2026-01-08 16:01:37.696	2026-01-09 04:01:37.691	2026-01-09 12:34:03.534
cmk5myevh0010bdrsg1ewy7de	cmk12kr4x000fo1hxdcjik7rt	9d5c1c9d0a0ffcb1bd143ab28b7cfd13cdb7e7ec5a9ca33f6673af52834a0abd	2026-01-08 16:02:24.845	2026-01-09 04:02:24.841	2026-01-09 12:34:03.534
cmk5n49xf0013bdrsldnagcld	cmk12kr4x000fo1hxdcjik7rt	bb67b078621cfe57c32aae9ee2cfa1cef7423cfc810c8be7e5da609df1589711	2026-01-08 16:06:58.372	2026-01-09 04:06:58.366	2026-01-09 12:34:03.534
cmk5n4qid0016bdrs07j3nfcu	cmk12kr4x000fo1hxdcjik7rt	dfa182e2f05c16dbdbd7f7c35a04536455d50ccb900c0208d4bd1bf3f49d818b	2026-01-08 16:07:19.861	2026-01-09 04:07:19.856	2026-01-09 12:34:03.534
cmk5t3m8p0019bdrsvmml8dyl	cmk12kr4x000fo1hxdcjik7rt	425689e2c3c9cc66d581978efd25ccf7c1e4bdc37ba9eae63453b04aaa05ccb8	2026-01-08 18:54:25.369	2026-01-09 06:54:25.364	2026-01-09 12:34:03.534
cmk5t6col001cbdrsj7swhztf	cmk12kr4x000fo1hxdcjik7rt	4a1e9c3558dc5f28b65a83b191c28354ae745c895bcbfcc524217b6f81f84159	2026-01-08 18:56:32.949	2026-01-09 06:56:32.945	2026-01-09 12:34:03.534
cmk5tbxwd00021341akvvbg40	cmk12kr4x000fo1hxdcjik7rt	44402883d9c72cf4b0b46ce4fb42ce7a909d64215428ae8d5f75ad8fcca6ecf6	2026-01-08 19:00:53.726	2026-01-09 07:00:53.715	2026-01-09 12:34:03.534
cmk5tdh9k00071341iavxyeut	cmk12kr4x000fo1hxdcjik7rt	c90c8ecdf598428fb8d9de87f2bc1dd476b3da3e3249dcd4e7b30b2f69cad8df	2026-01-08 19:02:05.48	2026-01-09 07:02:05.475	2026-01-09 12:34:03.534
cmk5te0c4000c1341951gp5ni	cmk12kr4x000fo1hxdcjik7rt	862cebc5d85f2791d4b92dc14ce136cc7b268fa641d3041f3389339207681241	2026-01-08 19:02:30.196	2026-01-09 07:02:30.192	2026-01-09 12:34:03.534
cmk5tiylh000h1341k759b9ak	cmk12kr4x000fo1hxdcjik7rt	98eadcdd348ce67a685e6ffc760ce5f63c424be875cdbf4ee94754b98e7e4753	2026-01-08 19:06:21.222	2026-01-09 07:06:21.214	2026-01-09 12:34:03.534
cmk5tzxn5000m1341cg25lge8	cmk12kr4x000fo1hxdcjik7rt	abbf7eb3c1e6909f747fc1662f163b1573dd64d4b076a9f650662296dfc65b5b	2026-01-08 19:19:33.138	2026-01-09 07:19:33.132	2026-01-09 12:34:03.534
cmk6shofv0002nqfueg244379	cmk12kr4x000fo1hxdcjik7rt	9dfa66aeb836916c060ef511545f249e3bb457974b20fb6df11988eb466a2c4f	2026-01-09 11:25:07.964	2026-01-09 23:25:07.954	2026-01-09 12:34:03.534
cmk6uz5p500068cfekphhe7xu	cmk12kr4x000fo1hxdcjik7rt	62814f15a4d7e1b9b7642bbe7231d2e3c6120a47af065ebe1fdc88a8a1e75b30	2026-01-09 12:34:42.713	2026-01-10 00:34:42.707	2026-01-09 12:34:51.111
cmk6uzffv00098cfegcmu6dku	cmk48grgz0008bmbcp8s2vrap	b50780fef6efe48707960d8b9a335e49302066d2c7080d4a067fea729b652f4f	2026-01-09 12:34:55.339	2026-01-10 00:34:55.335	\N
cmk6v1vo1000c8cfeb72g7670	cmk12kr4x000fo1hxdcjik7rt	41c0facea609ebcd54a6175d2b31839e5c1e2f762ba253494e65ba3531b91289	2026-01-09 12:36:49.682	2026-01-10 00:36:49.676	\N
cmk6v3y33000f8cfer68q0gv7	cmk12kr4x000fo1hxdcjik7rt	d5c3a3a1c543d1f7848496ee335ac7a3d7ee1f3eb41e9d16c9897fc9a487be6b	2026-01-09 12:38:26.127	2026-01-10 00:38:26.123	2026-01-09 12:39:48.244
cmk6v5x5d000i8cfeq5k74e57	cmk12kr4x000fo1hxdcjik7rt	e02b4ab9bd65cbf1cfbde216ce98cbbcf123a1240a77abd737dd6f30f3df269c	2026-01-09 12:39:58.225	2026-01-10 00:39:58.22	\N
cmk6v64e8000l8cfevigalycw	cmk12kr4x000fo1hxdcjik7rt	7430a3e17cdbdb0cb72b24f858983132c8cc188bf92fc6ef56505dcfbd179b4c	2026-01-09 12:40:07.617	2026-01-10 00:40:07.611	\N
cmk6vncmi000o8cfegks6ecmx	cmk12kr4x000fo1hxdcjik7rt	c26c5f762de1f8912039b5e99e5f958f1676b405c0bf668b43e85791d6bb9e86	2026-01-09 12:53:31.434	2026-01-10 00:53:31.427	\N
cmk6wdjwa000r8cfeoenzltkc	cmk12kr4x000fo1hxdcjik7rt	67d7eecbc55111170b98c2af6dba72793590b52e6af1da29aefaaa63c55a8ea0	2026-01-09 13:13:53.914	2026-01-10 01:13:53.908	2026-01-09 13:14:22.02
cmk6x9gzd0002grbrvybbpk95	cmk12kr4x000fo1hxdcjik7rt	db3b9163e93e06b0618915a57f6f93fed480ebb12b9b570fb7c46921d68bf5b5	2026-01-09 13:38:43.13	2026-01-10 01:38:43.114	2026-01-09 13:44:44.396
cmk6xhalb0005grbrgavaw5w0	cmk48grgz0008bmbcp8s2vrap	12bf41c5476e74ea69d885c3633a4f2bf85831ad0694a200ea7077d535510e41	2026-01-09 13:44:48.095	2026-01-10 01:44:48.091	2026-01-09 13:45:48.963
cmk6xiqkw0008grbrssdllum4	cmk12kr4x000fo1hxdcjik7rt	5ca4964250d83608963566965e9000f7e02dbe38e6e6e4ff9a95d8c3fa325ad3	2026-01-09 13:45:55.472	2026-01-10 01:45:55.467	2026-01-09 14:25:08.548
cmk6yx7zc0002padg8zhbkzvh	cmk12kr4x000fo1hxdcjik7rt	caa7e7e2e6092995b53dc7a258a667b784d70a4fe3fa4ac5388810cb6a430646	2026-01-09 14:25:10.824	2026-01-10 02:25:10.818	2026-01-09 14:25:19.872
cmk6yxigz0005padgmrxcr7e5	cmk48grgz0008bmbcp8s2vrap	67908ef1820c617277a63a3cd4d1e386fc409a7126f48f86fa4e9bd4c8633cbf	2026-01-09 14:25:24.419	2026-01-10 02:25:24.415	2026-01-09 14:25:38.715
cmk6yxxm70008padg9w2v2zsq	cmk12kr4x000fo1hxdcjik7rt	023df9b482a6761944b73d98ee4f422a8db2484c20a2ea9854938fde395ff2c8	2026-01-09 14:25:44.048	2026-01-10 02:25:44.043	2026-01-09 14:31:48.028
cmk6z5sq7000bpadgmavswyub	cmk12kr4x000fo1hxdcjik7rt	199c764f4e107125cb90aeaa74daca146f2a18b3cf5e207da3e909743fec8d4b	2026-01-09 14:31:50.959	2026-01-10 02:31:50.954	2026-01-09 14:32:31.381
cmk6z6s4v000epadggb51z95v	cmk48grgz0008bmbcp8s2vrap	43a83a735e58fe1e76cd66683be437181720a738b121fac97b95001c24cb8c72	2026-01-09 14:32:36.847	2026-01-10 02:32:36.842	2026-01-09 14:37:14.932
cmk6zcuci000hpadgowq8k7r0	cmk12kr4x000fo1hxdcjik7rt	ad589dd5ca844ea85fb960883d5210edddb96153f75e371a3dad6c9790bb342c	2026-01-09 14:37:19.65	2026-01-10 02:37:19.643	2026-01-09 14:43:18.637
cmk6zkla1000kpadgt4kfi41b	cmk12kr4x000fo1hxdcjik7rt	4fc4c8506b4c83b19f35d79063f918dc561c5685f98c2587eb6ea0caeaa30d48	2026-01-09 14:43:21.145	2026-01-10 02:43:21.14	2026-01-09 14:43:54.224
cmk6zlcfx000npadgy47ja86n	cmk12kr4x000fo1hxdcjik7rt	5e9b2ebfcc2bd6e629f7130883a0da64ec63e4d24c94739effa65baeab61e1b9	2026-01-09 14:43:56.349	2026-01-10 02:43:56.344	2026-01-09 14:59:59.228
cmk70689t000217eacxm7i6pi	cmk12kr4x000fo1hxdcjik7rt	b44e266d0f0e87657ad1584e7304ca1056c869f5030136662bb0464f2fcb6467	2026-01-09 15:00:10.722	2026-01-10 03:00:10.712	2026-01-09 15:11:25.801
cmk70kqxz000517eael15e9xg	cmk12kr4x000fo1hxdcjik7rt	b314b0f3a7d509a0a4179a17c2d45e0a0d0bee5347fb2b3a00b3b6bd14c24069	2026-01-09 15:11:28.103	2026-01-10 03:11:28.097	2026-01-09 16:15:03.171
cmk72umen0002dq0dmju82snf	cmk48grgz0008bmbcp8s2vrap	ac4885397cb115e3c76eb4a1a1823b8d9bf72178b4bbfd6eed45efd63be8c637	2026-01-09 16:15:08.015	2026-01-10 04:15:08.006	2026-01-09 16:15:21.64
cmk72uyyk0005dq0dfelm397t	cmk48grgz0008bmbcp8s2vrap	85761059f9a7ad0070bc3b401f3d9822c016c97f14028e77d079961b950ec085	2026-01-09 16:15:24.284	2026-01-10 04:15:24.278	2026-01-09 16:15:50.337
cmk72voah0008dq0dbhngl0ql	cmk48grgz0008bmbcp8s2vrap	1199fd075bfbc4cd0922f96977ed8b265247236b8620f74ba84af1d2cc90de92	2026-01-09 16:15:57.114	2026-01-10 04:15:57.108	2026-01-09 16:22:36.231
cmk734bxo0002oyv7bw5uo2zv	cmk12kr4x000fo1hxdcjik7rt	f38de0abf96c7d0247c75b786d695b011ccf24c82faa18bfb69782e460cc9d97	2026-01-09 16:22:41.005	2026-01-10 04:22:40.996	2026-01-09 16:22:49.492
cmk7358y30005oyv79ww3j28c	cmk48grgz0008bmbcp8s2vrap	c80607fb8bcfdbe82a47799daacb7338f8d6a1d2a50876dbf657d22db956fe6e	2026-01-09 16:23:23.787	2026-01-10 04:23:23.783	2026-01-09 16:23:42.119
cmk736hrr000boyv7s17tdeqp	cmk736hrm0009oyv7mm2wm20e	3908a741d8a4b448f6761a663579fb73c4a1fb8bc4914ee40a9ce22811561560	2026-01-09 16:24:21.88	2026-01-10 04:24:21.859	2026-01-09 16:24:49.926
cmk73794j000eoyv7l7h41mnr	cmk12kr4x000fo1hxdcjik7rt	99d7631d49de9162395730477bf7ad3edd60b180d22d232be9ab4a86107b6bd5	2026-01-09 16:24:57.332	2026-01-10 04:24:57.324	2026-01-09 16:24:59.965
cmk770psl000hoyv70erspo3h	cmk12kr4x000fo1hxdcjik7rt	68776e1d8ebfccb4602bc8a23325f1e8314fdbdaba29794bc09f5cc89d856337	2026-01-09 18:11:50.805	2026-01-10 06:11:50.799	2026-01-09 18:12:40.637
cmk7apx4f000koyv7b5c17gii	cmk12kr4x000fo1hxdcjik7rt	da704864ed48f66214b535eb062bccb0276af1260fdd18c8574e33c78a7d3d68	2026-01-09 19:55:25.552	2026-01-10 07:55:25.545	\N
cmk7eawfp000noyv7sr4n4okk	cmk12kr4x000fo1hxdcjik7rt	be5c87986857f8cf31a1f0079e8d34bba8416f96def3a6635c06f99f055d95b7	2026-01-09 21:35:43.285	2026-01-10 09:35:43.28	2026-01-09 22:08:54.277
cmk7fhnrz0002rlysw0pn7aux	cmk48grgz0008bmbcp8s2vrap	cef97e0254ceac2a7dba173dc20760e27a5a5cb2917535f7464be7a3bd058a68	2026-01-09 22:08:58.271	2026-01-10 10:08:58.265	2026-01-09 22:09:41.398
cmk7fip1l0005rlys3fh3mvex	cmk12kr4x000fo1hxdcjik7rt	8e70e03cf3d5ba2dbd3e8f460346fd673b64d30d426f2276186f07d381c8a71e	2026-01-09 22:09:46.569	2026-01-10 10:09:46.565	\N
cmk829evo0008rlysytuy9ld8	cmk12kr4x000fo1hxdcjik7rt	e8ccbb325ced4a874c7f7b4c8481b192d605f9e9e70f66f65133b676ce6bf2f8	2026-01-10 08:46:24.66	2026-01-10 20:46:24.655	2026-01-10 08:47:06.667
cmk82ae1u000brlyszex4zi57	cmk48grgz0008bmbcp8s2vrap	349f537da51203fd1a8a0be11330de3ad3796936be5d0fd806565a2a53bd21be	2026-01-10 08:47:10.242	2026-01-10 20:47:10.236	2026-01-10 08:52:25.939
cmk82ha0c000jrlysi4hfn7rc	cmk12kr4x000fo1hxdcjik7rt	0f7736fe531469ad955fa5a67de3e7fbef1c207ee3cb31cf789da09c4cf5b974	2026-01-10 08:52:31.597	2026-01-10 20:52:31.592	2026-01-10 08:52:46.027
cmk82hnve000mrlysqfah52qq	cmk48grgz0008bmbcp8s2vrap	88b68147d7a199fd0e31ddaae07048b96698b8f8a0891a5060da436bfd405494	2026-01-10 08:52:49.562	2026-01-10 20:52:49.556	2026-01-10 08:53:14.152
cmk82i9je000qrlysgwj0nipr	cmk12kr4x000fo1hxdcjik7rt	65219127b4dabb51bd13209809d106eb7dd68cb3a598ebd2e011cfaea7e0b340	2026-01-10 08:53:17.642	2026-01-10 20:53:17.637	2026-01-10 08:53:22.273
cmk82ifmv000trlysqp3nmard	cmk48grgz0008bmbcp8s2vrap	793e98e46cd57e10ea068807c62977afd3db96a1fb91469ea7c6c9166fb86af0	2026-01-10 08:53:25.543	2026-01-10 20:53:25.538	2026-01-10 09:20:09.019
cmk89qury0002s35hmghae2jo	cmk12kr4x000fo1hxdcjik7rt	31696c91770dfd694d0d9cf7cfafa6cd37c589a3a30272ece450f4ceaf70339d	2026-01-10 12:15:55.727	2026-01-11 00:15:55.718	\N
cmk89rpv90005s35ht732uyrz	cmk12kr4x000fo1hxdcjik7rt	06f8c1919efca2c7aff8d2378ebe9c6d0555a2c23a64a02f6181d584d94b067e	2026-01-10 12:16:36.021	2026-01-11 00:16:36.012	\N
cmk89sig50008s35hualp8yl5	cmk12kr4x000fo1hxdcjik7rt	059ec8ea4c732779ad5c09044d21197df01069d56f615ed80082489f1ca0dbe6	2026-01-10 12:17:13.062	2026-01-11 00:17:13.054	\N
cmk83ffqy000wrlysit0p92zf	cmk12kr4x000fo1hxdcjik7rt	63cde41456ff1ec2a1aead46f2b7160794311c758e135d2ec7e70a59e67dd2e5	2026-01-10 09:19:05.339	2026-01-10 21:19:05.331	2026-01-10 12:19:55.915
cmk89w2j4000bs35hrsngezkb	cmk12kr4x000fo1hxdcjik7rt	ce0602d4fb2f31ea33d2522140f9c3de15494e858a1187cefdc7f548500ab092	2026-01-10 12:19:59.057	2026-01-11 00:19:59.052	2026-01-10 12:20:01.208
cmk89xsky000hs35h8208f760	cmk12kr4x000fo1hxdcjik7rt	9cf07f78aa15cc0f79847a7b043f3af94e75554377388a59a877532d33b52ab5	2026-01-10 12:21:19.474	2026-01-11 00:21:19.469	\N
cmk89yc2k000ks35h7bng4iv4	cmk12kr4x000fo1hxdcjik7rt	b40d75e02fe413ec718b216ec03fc97224a625be1437dbfd25deeac8229c5e0b	2026-01-10 12:21:44.733	2026-01-11 00:21:44.728	\N
cmk8a168d000ns35hknovuowo	cmk12kr4x000fo1hxdcjik7rt	c99ddd3af736a38ca868b00edfa3d80ff6378d1a51bc3348a10f7b21c07c6723	2026-01-10 12:23:57.133	2026-01-11 00:23:57.128	\N
cmk8a5w1h000qs35hpapzye0b	cmk12kr4x000fo1hxdcjik7rt	eaa2a3f9715eeb0f76086496daeb4ec51555fc32b7e4284b871b2acfa6bf47f1	2026-01-10 12:27:37.205	2026-01-11 00:27:37.199	\N
cmk8aixmy0002h9jo855n4iit	cmk12kr4x000fo1hxdcjik7rt	8e8737aebddd1873780a3418cad30317742800bfa86a09e069626f47221b785b	2026-01-10 12:37:45.802	2026-01-11 00:37:45.793	\N
cmk8allia0005h9johqfg845v	cmk12kr4x000fo1hxdcjik7rt	8510b8daab1c5c5784a0df385d00d75df2c5e135f1169be16056e789e88e0263	2026-01-10 12:39:50.05	2026-01-11 00:39:50.045	\N
cmk8am6un0008h9jo9yftnis4	cmk12kr4x000fo1hxdcjik7rt	670cc63a1a00b7dad3f5005a02ddcd3c2484233ce772956e6e7c646cc3735917	2026-01-10 12:40:17.711	2026-01-11 00:40:17.705	\N
cmk8amo59000bh9joz6i1apfq	cmk12kr4x000fo1hxdcjik7rt	8826c3ec636a734673a5bae1d1947ab27eacb6d36417b7009d3b6429a1e5c0a7	2026-01-10 12:40:40.125	2026-01-11 00:40:40.12	\N
cmk8anbtl000eh9joy9ddbaki	cmk12kr4x000fo1hxdcjik7rt	7d5408f6215bfa685ca44a7970e47d7058578919aa6d3e8bcce7f1f343ce7765	2026-01-10 12:41:10.81	2026-01-11 00:41:10.805	\N
cmk8any4h000hh9jo3au35fht	cmk12kr4x000fo1hxdcjik7rt	826225fb5f7e316347c8b296251822ebdeea2db1d54b7663af200d50c57a8328	2026-01-10 12:41:39.713	2026-01-11 00:41:39.709	\N
cmk8aoz15000kh9joy71uwkzg	cmk12kr4x000fo1hxdcjik7rt	584643b30a1f689b4ac2895a3f414ccc853700299a414dea5af7026ab17ee235	2026-01-10 12:42:27.545	2026-01-11 00:42:27.54	\N
cmk83guiq0002fbz0r3wfku9a	cmk48grgz0008bmbcp8s2vrap	eab497514ee86291234b3365da9c3713a5fd67328898ac088a24b6fca56305d8	2026-01-10 09:20:11.138	2026-01-10 21:20:11.13	2026-01-10 12:43:56.191
cmk8asgyf000nh9jo11oqdfo0	cmk12kr4x000fo1hxdcjik7rt	a486d87fbf62a33d8f40f75b764d15ae548c6252ae8972396f5e08d37eb288e6	2026-01-10 12:45:10.744	2026-01-11 00:45:10.739	\N
cmk8ashpk000qh9jo6yqwx79i	cmjdakp0k0003ut2ufp00eqzv	74d8abbe840bfcc50d4ba8e2863145df6745a4d53cd72126708e0e82f161f3e7	2026-01-10 12:45:11.72	2026-01-11 00:45:11.715	\N
cmk89wcil000es35hdrkydlpe	cmk12kr4x000fo1hxdcjik7rt	874338ec30fda02c6ee19608bdfef0f1076eb7035e94a1c806c956771d82e9dd	2026-01-10 12:20:11.997	2026-01-11 00:20:11.991	2026-01-10 20:19:58.902
cmk8r1hq7000th9jop6df6c0m	cmk12kr4x000fo1hxdcjik7rt	4b6af23dd9fb78099bf0415c122c8c1a76ce1a1de2fa76bc0ba7e4db5d8f65c7	2026-01-10 20:20:05.504	2026-01-11 08:20:05.497	\N
cmk8r1n19000wh9jo3gld9uqq	cmk48grgz0008bmbcp8s2vrap	de4d1a1718b211829e2338cb6a879ae56cb2114f090a5bf4ee1a2c264be0da06	2026-01-10 20:20:12.382	2026-01-11 08:20:12.376	\N
cmk8r5623000zh9jo2ybc21o9	cmk12kr4x000fo1hxdcjik7rt	7c60892dca96dcc0a4730b93688b9b4ce241d1099b6fbba2a820695e073be3ae	2026-01-10 20:22:57.003	2026-01-11 08:22:56.999	\N
cmk8r56hm0012h9jos6qsy7e8	cmjdakp0k0003ut2ufp00eqzv	8ab4dc50f0b8e721120d3a16108f686fa263aff73950d4ea022782a510750806	2026-01-10 20:22:57.563	2026-01-11 08:22:57.558	\N
cmk8rd2s60015h9joav4q9f6p	cmjdakp0k0003ut2ufp00eqzv	907ea81c8aa5d402bf37fda15a8f6d5d23e8c33155fb9fd2d4cc18e333415840	2026-01-10 20:29:06.006	2026-01-11 08:29:06.001	\N
cmk8rebfw0018h9jo0wki4h3c	cmjdakp0k0003ut2ufp00eqzv	823d0b2221c3bb3a7e34753be9a2fbb6f43ad28a194a449e36c7f6978f1c8696	2026-01-10 20:30:03.885	2026-01-11 08:30:03.879	\N
cmk8reox5001bh9joiadwecqx	cmjdakp0k0003ut2ufp00eqzv	caa45f740eedfc1283c79e6a6de8ece5dab645399448992303de581b6dd7388b	2026-01-10 20:30:21.353	2026-01-11 08:30:21.348	\N
cmk8rf6yx001eh9jo978e7t8y	cmjdakp0k0003ut2ufp00eqzv	e2dc6f108fe650cabbd2cdaf10a00eb8f3349c4bf5bb36e1254899a6056f73cc	2026-01-10 20:30:44.746	2026-01-11 08:30:44.742	\N
cmk8rfkv1001hh9jo73448hns	cmjdakp0k0003ut2ufp00eqzv	e1e7c95195b217b266bf0ebcc6bb7d57c65365c571ce26eee7189348f88716da	2026-01-10 20:31:02.75	2026-01-11 08:31:02.745	\N
cmk8rg2j6001kh9jonvhzaat5	cmjdakp0k0003ut2ufp00eqzv	acacbf1e029893d9e9ac99a8ae33d612f3d3dc28bacf52a79795ce5007dea0e0	2026-01-10 20:31:25.651	2026-01-11 08:31:25.646	\N
cmk8rgn2p001nh9jor2eog6mb	cmjdakp0k0003ut2ufp00eqzv	3bc6d603c37596bcd54a4ecd044cdad2097bf9591abad982cade2a86c49ce752	2026-01-10 20:31:52.274	2026-01-11 08:31:52.268	\N
cmk8rh5c5001qh9joiyd1wu0l	cmjdakp0k0003ut2ufp00eqzv	6118750ac4a590ef941874fc4ed0e6c4db8d7fd84e32e12b9bc8fbd99342a9fb	2026-01-10 20:32:15.941	2026-01-11 08:32:15.933	\N
cmk8rhjnn001th9joek34qrpi	cmjdakp0k0003ut2ufp00eqzv	1975ca19758bab0965f635a2cb96b0d6d8f6a0cb72877804c3124629b790da76	2026-01-10 20:32:34.5	2026-01-11 08:32:34.494	\N
cmk8rhynm001wh9jo7qwix3ai	cmjdakp0k0003ut2ufp00eqzv	78b35a5529e427e445c466db5cef0acd4c186817c7c5fcab19bd5ef1ad530a75	2026-01-10 20:32:53.939	2026-01-11 08:32:53.912	\N
cmk8riyoi001zh9jo7i5lea8v	cmjdakp0k0003ut2ufp00eqzv	9d727d2285253e230ad90912e171afc7c41ceac0769ca0203dce6c3753b3474a	2026-01-10 20:33:40.626	2026-01-11 08:33:40.621	\N
cmk8rjp8s0022h9joclq85fo8	cmjdakp0k0003ut2ufp00eqzv	2cd6e1e51841d9727727678d59334b3063218e7b2aeda32e8429976222c5affb	2026-01-10 20:34:15.053	2026-01-11 08:34:15.048	\N
cmk8rk4c10025h9jon6l7glw8	cmjdakp0k0003ut2ufp00eqzv	fc1502a825c32f446d01d1069dd6bb4a47906c04034b379d262dd4d0fa8d20e4	2026-01-10 20:34:34.61	2026-01-11 08:34:34.605	\N
cmk8rl3280028h9jof5odt6gy	cmjdakp0k0003ut2ufp00eqzv	4d141f755ffbef59ce692798a2d9014ccb3339a2f988da325c9682c797a51e03	2026-01-10 20:35:19.616	2026-01-11 08:35:19.612	\N
cmkb0mxfh00025otl9457mxta	cmk12kr4x000fo1hxdcjik7rt	c1e9b3a4688673c57cf0c84a6a54d927839d9930b6ba9750085abb2e8cf2811c	2026-01-12 10:24:14.525	2026-01-12 22:24:14.513	2026-01-12 10:56:04.47
cmkb1rx1q0002f1s98g9d72yz	cmk12kr4x000fo1hxdcjik7rt	81f653d81d379418a271e9de23d25dce22c197c28941d23431e017743402f6e2	2026-01-12 10:56:06.927	2026-01-12 22:56:06.916	2026-01-12 10:56:26.038
cmkb1seca0005f1s9gdrpnwvy	cmk48grgz0008bmbcp8s2vrap	8f97d04fa016a5f6b02e82bcf1401c545c0ca47f3f46c4225b09152e6c813a69	2026-01-12 10:56:29.339	2026-01-12 22:56:29.333	2026-01-12 10:56:36.839
cmkb1sopn0008f1s92g2qtwtt	cmk12kr4x000fo1hxdcjik7rt	8b3815432e60a1eca0ac0839cf18ff376bebb1d6805a002664556fd284a7635a	2026-01-12 10:56:42.779	2026-01-12 22:56:42.773	2026-01-12 11:19:56.946
cmkb2mm4m000bf1s9i9qa2btr	cmk12kr4x000fo1hxdcjik7rt	6f55fca4254b091f27747e7ad01ee7e63f0241fee371aa7db59ab4b378d950dc	2026-01-12 11:19:59.111	2026-01-12 23:19:59.104	2026-01-12 11:25:18.216
cmkb2tij9000ef1s9099k2903	cmk12kr4x000fo1hxdcjik7rt	7d0ed6d1274460d67958112c7e8d2731df4b0ed0735b0cf58df961a0d17dbc7a	2026-01-12 11:25:21.045	2026-01-12 23:25:21.039	2026-01-12 11:25:35.235
cmkb2tw3z000hf1s90mb6xfsm	cmk12kr4x000fo1hxdcjik7rt	a249beea2770fe0037ab10f47960f40efbb0cc4fdc7e1e30d6665ede17721d3d	2026-01-12 11:25:38.639	2026-01-12 23:25:38.634	2026-01-12 11:25:44.741
cmkb2umrh000kf1s9wh2bjf94	cmk12kr4x000fo1hxdcjik7rt	f9ac3e10ecc0e066905c17759cfdc4e7873cc6874fed6f91ab432f24b6e0c105	2026-01-12 11:26:13.181	2026-01-12 23:26:13.176	2026-01-12 11:29:54.089
cmkb302b9000nf1s91o98vfma	cmk12kr4x000fo1hxdcjik7rt	4ef28ba9bf5fa861ecb1df3353711974117b240c69748531842085f4b673649f	2026-01-12 11:30:26.613	2026-01-12 23:30:26.608	2026-01-12 12:13:48.489
cmkb4jvk6001nf1s9eydw3jly	cmk12kr4x000fo1hxdcjik7rt	a564ca2df0738e3850d03b746bfeb5356ecead75480c398bd45d87a8092ea566	2026-01-12 12:13:50.598	2026-01-13 00:13:50.592	2026-01-12 13:16:35.917
cmkb6sn70000212gfzaj6v9k0	cmk12kr4x000fo1hxdcjik7rt	4a9331a33e18b5a17210cf1aa2f1772cd07050834d223c445e43f67520b9d9fd	2026-01-12 13:16:38.892	2026-01-13 01:16:38.882	2026-01-12 15:54:33.472
cmkbd197f00027bo9zmv74p2a	cmk12kr4x000fo1hxdcjik7rt	bb9c2b080d8ffcc9b2acbacfeee16526cd94eee2e6d4f861fd52c1159d3318ea	2026-01-12 16:11:18.363	2026-01-13 04:11:18.352	2026-01-12 16:14:32.642
cmkbdjj8i00023q034u8bzu5w	cmk12kr4x000fo1hxdcjik7rt	0b5fa95c28b2d46e30a6189a2814591cb54af2be922f713879a974a74effa67d	2026-01-12 16:25:31.17	2026-01-13 04:25:31.163	2026-01-12 16:25:43.032
cmkbe2qrr000238rpr75nf4fo	cmk12kr4x000fo1hxdcjik7rt	0908fdc5b2de2fa343c8df2980d0533e2a1fcbaa144d14d1c8d1711cb1720347	2026-01-12 16:40:27.4	2026-01-13 04:40:27.391	2026-01-12 17:56:26.076
cmkbhul1a00028oa5dj2eexth	cmk12kr4x000fo1hxdcjik7rt	0c0e87378fa6363490e747a841bd0e789bd9332778404ff35ede02d5581e14d8	2026-01-12 18:26:05.182	2026-01-13 06:26:05.174	2026-01-12 18:26:12.883
cmkbhvwp500058oa5qdon63nv	cmk12kr4x000fo1hxdcjik7rt	906acdb651c22937aae64e0cfaaa49a80b071c2ec874a29f62de780c87957427	2026-01-12 18:27:06.953	2026-01-13 06:27:06.949	2026-01-12 18:27:48.25
cmkbi4gyj00088oa51i2afub4	cmk12kr4x000fo1hxdcjik7rt	12c0309a6b3be23665cf80776d607b684bfef1f7dc081e1299071751d4202911	2026-01-12 18:33:46.459	2026-01-13 06:33:46.452	2026-01-12 18:51:23.827
cmkbj0j4g0002v00lj65iwb1j	cmk12kr4x000fo1hxdcjik7rt	1644cfc2c96a9ac9675ab1c1ff56c246ca327676232aac5f6572c2f0d817a10a	2026-01-12 18:58:42.257	2026-01-13 06:58:42.246	2026-01-12 20:06:48.796
cmkblg78e0005yjp6uy0ijd5p	cmk48grgz0008bmbcp8s2vrap	0e6e4c173c329852a6f8cc89b0ff581fd846dd2f4b0ed2559e33f3fd3719f683	2026-01-12 20:06:52.575	2026-01-13 08:06:52.568	2026-01-12 20:07:01.78
cmkblgiu10008yjp6qcauzum9	cmk12kr4x000fo1hxdcjik7rt	886d6e409534f8a2f25990be6bf7b783f5ceea2a363e8c31b33dec1427589628	2026-01-12 20:07:07.61	2026-01-13 08:07:07.605	\N
cmkceo8ou0002wlikz88ddnn3	cmk12kr4x000fo1hxdcjik7rt	572ae4c6ad6d704696d0f28d99ba76547928e1d38fc6305589ed7bac6a282852	2026-01-13 09:44:56.574	2026-01-13 21:44:56.567	2026-01-13 09:46:00.534
cmkch0cvy0003z8kxaigta1sl	cmk48grgz0008bmbcp8s2vrap	b32b927c0fca3c7f265afff7b049df873251cdc0d1263d8390c99476105b06ca	2026-01-13 10:50:21.119	2026-01-13 22:50:21.11	\N
cmkch1bel0006z8kxj59q6gjp	cmk48grgz0008bmbcp8s2vrap	4f8b13765eafd2c9cb0cbcab8fb02ee280568843e61fd4905d409bcb0f5b81a0	2026-01-13 10:51:05.853	2026-01-13 22:51:05.846	\N
cmkcepp9h0008wlik7rv1wt8s	cmk48grgz0008bmbcp8s2vrap	7ea8eff3cead5aec4caebd8342e2a978e65638bc9b7511146428ab6a2cb93aae	2026-01-13 09:46:04.709	2026-01-13 21:46:04.703	2026-01-13 12:09:30.14
cmkcju8x700025j850kzv2q1t	cmk12kr4x000fo1hxdcjik7rt	cdeeef2e7b1adb53eb6fcc8c9d26be4c7cb38cf16126fca72efb3d734632d32b	2026-01-13 12:09:34.891	2026-01-14 00:09:34.883	2026-01-13 12:09:51.607
cmkcjup0j00055j85d35c3szu	cmk48grgz0008bmbcp8s2vrap	3fc88c92f0be2b50bce9b4043bcac5ab925b9b6b855a92795f9b2c5b6dd91653	2026-01-13 12:09:55.747	2026-01-14 00:09:55.742	\N
cmkck6pju00023tkx3glnht6p	cmk48grgz0008bmbcp8s2vrap	8fc265522f50a312b2634805b2c5392bfbb123e094f3d47568c145777408a73b	2026-01-13 12:19:16.315	2026-01-14 00:19:16.307	2026-01-13 12:47:21.255
cmkcl6vnb0002cscewhrlrxhz	cmk48grgz0008bmbcp8s2vrap	ac3d1fc28c89c6c16543532229dd13321dd79a3f1dc09492bafef3cfddb06c5a	2026-01-13 12:47:23.831	2026-01-14 00:47:23.824	2026-01-13 12:47:41.683
cmkcl7dor0005cscezm2k8qix	cmk12kr4x000fo1hxdcjik7rt	649c8e6e1b3f00cc2a144f8c3202075e23871cf22c3576581543fd401dc79abd	2026-01-13 12:47:47.211	2026-01-14 00:47:47.204	2026-01-13 12:47:51.447
cmkcl7l1y0008cscezonrhl25	cmk48grgz0008bmbcp8s2vrap	9ca0a2877a1a3ef0a4bb396f350db90c682dff6d99f00839bd33ac1e03463f7a	2026-01-13 12:47:56.758	2026-01-14 00:47:56.753	2026-01-13 12:56:50.984
cmkclj4g7000bcscek4h7dhv9	cmk12kr4x000fo1hxdcjik7rt	3cd7391fc795cb92cbce90c534bdcbe5916341a8ff44b91ddcfe6aaf7d9725e8	2026-01-13 12:56:55.112	2026-01-14 00:56:55.105	2026-01-13 12:56:57.925
cmkclj9d8000ecsceu2c8dbfc	cmk48grgz0008bmbcp8s2vrap	9bfa81ffbee0c562423f69681fedbf15f5e253eb88b13eccb9450d7b89a1efe2	2026-01-13 12:57:01.484	2026-01-14 00:57:01.475	\N
cmkcm2tue0002fanb44kx3zmd	cmk48grgz0008bmbcp8s2vrap	e7cf16d0dfbb52218fb839d0ef61132712c40473850111f8e02ea72a8ad35608	2026-01-13 13:12:14.487	2026-01-14 01:12:14.478	\N
cmkcm3hz40005fanbofq0026e	cmk48grgz0008bmbcp8s2vrap	93cdf4a6c9ab31c98b4cde98cc1d92cb1215c75955b0ea2d50f128afd13ea28c	2026-01-13 13:12:45.76	2026-01-14 01:12:45.754	\N
cmkcmpazx0009fanb8jzoirku	cmk48grgz0008bmbcp8s2vrap	f9061db1ba212707dac35b8fc7c8cfa60c6eb00d4032af242b9fdae4408051cd	2026-01-13 13:29:43.149	2026-01-14 01:29:43.142	\N
cmkcmqpbv000cfanbffpgn0cm	cmk48grgz0008bmbcp8s2vrap	275340101c86fb525f5b4abc24a4453170ed81f61d127beb7d9ae0596470b250	2026-01-13 13:30:48.379	2026-01-14 01:30:48.372	\N
cmkcmqqzc000ffanbzmjlawxc	cmk12kr4x000fo1hxdcjik7rt	ef879fcb73545effa3a0215d9e3105832946fd6bba7b7244cf8d658cc86ef5ea	2026-01-13 13:30:50.52	2026-01-14 01:30:50.513	\N
cmkcmsr9h000ifanb94i2k6ti	cmk48grgz0008bmbcp8s2vrap	fe45ad1681a9db3cc89237a1f9f2ea57c91ff5b595e39cd293be70ee8a65d7a1	2026-01-13 13:32:24.198	2026-01-14 01:32:24.192	\N
cmkcmu9jd000lfanbomljluye	cmk48grgz0008bmbcp8s2vrap	0d4ed317642b6d34107dedfe3b1bcf32abe23869fcf08ff002af18dd36638112	2026-01-13 13:33:34.537	2026-01-14 01:33:34.532	\N
cmkcmub8f000ofanb07ooskg8	cmk48grgz0008bmbcp8s2vrap	b4f7e517045635f72251945f8876737f1d44ba1a559fcb44cb61901a4a7bcd75	2026-01-13 13:33:36.736	2026-01-14 01:33:36.73	\N
cmkcmubsx000rfanbh1xyc1gl	cmk12kr4x000fo1hxdcjik7rt	ccd10a33f741676d3f803598c33c96f4edd617483338f90da13d1e602d4d5505	2026-01-13 13:33:37.473	2026-01-14 01:33:37.468	\N
cmkcmuc65000ufanboczmvvr9	cmk12kr4x000fo1hxdcjik7rt	e1c5091907b9ffb52179cb5c1a67cd9f633b80f9a95ca70c1e2135788ccbdd4d	2026-01-13 13:33:37.95	2026-01-14 01:33:37.944	\N
cmkcmvu6k000xfanbqxu6x48k	cmk48grgz0008bmbcp8s2vrap	60f81f9fb4982a66c5f9e358ef4cd9fd4342f295104053bab007fd7af6706b7d	2026-01-13 13:34:47.949	2026-01-14 01:34:47.944	\N
cmkcmvvu20010fanbxnc7miir	cmk48grgz0008bmbcp8s2vrap	a0aecb3045adf7f7e5049286e685e70c8190844be407d78dd9e05a7e1b7670dd	2026-01-13 13:34:50.09	2026-01-14 01:34:50.084	\N
cmkcmvwhq0013fanbr0s8brj2	cmk12kr4x000fo1hxdcjik7rt	16650d4bb873b3143a27676258f8a04b40007f3111af87ceb91204dc031bc80a	2026-01-13 13:34:50.942	2026-01-14 01:34:50.937	\N
cmkcmvwvm0016fanbptmv48qi	cmk12kr4x000fo1hxdcjik7rt	d6daadab915fea4d55a1f272f5cfe99eac76016b2e1092b8a2a432d51f6896f1	2026-01-13 13:34:51.443	2026-01-14 01:34:51.438	\N
cmkcn19c10019fanb59ki9q5z	cmk48grgz0008bmbcp8s2vrap	13e758690060376919165ffda2c9033a107a1abf7372c23da8e80035943d1153	2026-01-13 13:39:00.865	2026-01-14 01:39:00.859	\N
cmkcn19td001cfanb2ie3cdb1	cmk48grgz0008bmbcp8s2vrap	2a7592303680bfdc506e6659516d8680844c58e488c36ab18ff672e115cc3b18	2026-01-13 13:39:01.489	2026-01-14 01:39:01.483	\N
cmkcn1xr3001ffanbfaxz5cif	cmk12kr4x000fo1hxdcjik7rt	ad4b7371267271ea331e632f07a54610fa078aa9e3668a95564270cfc553dbe0	2026-01-13 13:39:32.512	2026-01-14 01:39:32.506	\N
cmkcn4clt001ifanbv8wjiqal	cmk48grgz0008bmbcp8s2vrap	91f6ab252e9ba544c425a97fd8e4521c0e2dec12d590bf8c8d8707f664cc5253	2026-01-13 13:41:25.074	2026-01-14 01:41:25.066	\N
cmkcnftds001lfanbnspz8w1l	cmk48grgz0008bmbcp8s2vrap	857cce1ef2d6b5f7264b80037ff7e9c63e89755a3e0989a45c2a65cd5957cc3e	2026-01-13 13:50:20.033	2026-01-14 01:50:20.025	2026-01-13 13:50:51.538
cmkcngmqo001ofanb7odtg3xs	cmk12kr4x000fo1hxdcjik7rt	120aef6dff236053f9e554971ccb97291a095c1bc8ee6f0241d159cf592a1bf9	2026-01-13 13:50:58.08	2026-01-14 01:50:58.073	2026-01-13 13:51:02.029
cmkcngrm1001rfanb2o3rzwet	cmk12kr4x000fo1hxdcjik7rt	0d38fcf437b8b3df3c641911202ae903e0f450ca0340f788bb9f74625e466f2e	2026-01-13 13:51:04.393	2026-01-14 01:51:04.386	2026-01-13 13:51:05.969
cmkcngw1k001ufanbacr9c034	cmk48grgz0008bmbcp8s2vrap	1ad9ae0ef94e37eee9e8be5904acf94e2ccd34d1d37741b90bf69399d698a1c1	2026-01-13 13:51:10.136	2026-01-14 01:51:10.131	2026-01-13 13:51:53.928
cmkcnhvu3001yfanbbfufvqcr	cmk48grgz0008bmbcp8s2vrap	0081a56d15984ef72b7997e3a7c5078b0fa1becdc8c7e91033772659873a1dbd	2026-01-13 13:51:56.523	2026-01-14 01:51:56.518	2026-01-13 13:52:04.657
cmkcni56r0021fanb3p3b9uh9	cmk12kr4x000fo1hxdcjik7rt	c65eb01ee2da9642db57aeccee5513e2ea8f9fdec44e515fd6e24e2d022ad52b	2026-01-13 13:52:08.643	2026-01-14 01:52:08.636	2026-01-13 13:52:16.986
cmkcnifj20024fanb87wojafn	cmk48grgz0008bmbcp8s2vrap	314e453c7e70b7d82d405787a378eaa9d2a1c5f7ead9eb57fd1e8ed07b7eb0e8	2026-01-13 13:52:22.046	2026-01-14 01:52:22.041	2026-01-13 13:52:36.83
cmkcniv1u0027fanbur31t4z8	cmk12kr4x000fo1hxdcjik7rt	a6375f463b6e2f87a95aac046864d7062bc002eeae651ae89276d5e0c27644bb	2026-01-13 13:52:42.163	2026-01-14 01:52:42.157	2026-01-13 13:52:59.93
cmkcnjdl1002afanbfpsj7zlg	cmk48grgz0008bmbcp8s2vrap	8079be487dcfa1b1cdf668b9488562df29ee4a8f93ebc7ca0ffc6fc1eefc572a	2026-01-13 13:53:06.181	2026-01-14 01:53:06.176	2026-01-13 13:53:35.304
cmkcnk3sx002dfanb8xgy7v1p	cmk12kr4x000fo1hxdcjik7rt	43fa77644e6bd8a8f563add680e4922eb6aab7da5c5d2968e6a94f113e742dcd	2026-01-13 13:53:40.161	2026-01-14 01:53:40.156	2026-01-13 13:55:29.095
cmkcnmjo7002gfanb9pvg7n56	cmk48grgz0008bmbcp8s2vrap	e9273d1bd89596b763bac4319d36da29c23717e8f780250391d8f8ffdb16604c	2026-01-13 13:55:34.039	2026-01-14 01:55:34.033	2026-01-13 15:04:53.847
cmkcq3t7d00034g01rszdonvk	cmk12kr4x000fo1hxdcjik7rt	0b8a341af1eefaee0c6fdc3c3f62a20350ba7b34599f5c7f63375060c121b488	2026-01-13 15:04:58.778	2026-01-14 03:04:58.771	2026-01-13 15:05:01.985
cmkcq3ysj00064g01shsgo21g	cmk48grgz0008bmbcp8s2vrap	330d2d59a5af334970906b8022b368deea71f95f9926fd653b3dbdd8dcdf0907	2026-01-13 15:05:06.02	2026-01-14 03:05:06.014	2026-01-13 15:05:15.761
cmkcq49i6000a4g013wsgqve1	cmk12kr4x000fo1hxdcjik7rt	96b3a96619dd3acde55600feb0b63074904764d77d850b557bd9d36f7fdc945c	2026-01-13 15:05:19.903	2026-01-14 03:05:19.898	\N
\.


--
-- Data for Name: ThemePalette; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."ThemePalette" (id, slug, name, "tokensJson", "isGlobalDefault", "createdByUserId", "updatedByUserId", "createdAt", "updatedAt") FROM stdin;
cmkcfo4yj0007nqizwe1flaeo	en-test01	Enabion_test01	{"info": "#228BE6", "danger": "#F87171", "success": "#2F9E44", "warning": "#F59F00", "accent-1": "#822312", "accent-2": "#a23959", "accent-3": "#FDBA45", "brand-gold": "#FDBA45", "brand-navy": "#0B2239", "brand-green": "#91a239", "brand-ocean": "#827312"}	f	cmk48grgz0008bmbcp8s2vrap	cmk48grgz0008bmbcp8s2vrap	2026-01-13 10:12:51.355	2026-01-13 15:05:13.779
cmkcfemy90000nqiz1hym3kvc	enabion-default	Enabion default	{"info": "#228BE6", "danger": "#F87171", "success": "#2F9E44", "warning": "#F59F00", "accent-1": "#126E82", "accent-2": "#38A169", "accent-3": "#FDBA45", "brand-gold": "#FDBA45", "brand-navy": "#0B2239", "brand-green": "#38A169", "brand-ocean": "#126E82"}	t	\N	cmk48grgz0008bmbcp8s2vrap	2026-01-13 10:05:28.114	2026-01-13 15:05:13.782
\.


--
-- Data for Name: ThemePaletteRevision; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."ThemePaletteRevision" (id, "paletteId", revision, "tokensJson", "createdByUserId", "createdAt") FROM stdin;
cmkcfemyh0002nqizf4q8ey1v	cmkcfemy90000nqiz1hym3kvc	1	{"info": "#228BE6", "danger": "#F87171", "success": "#2F9E44", "warning": "#F59F00", "accent-1": "#126E82", "accent-2": "#38A169", "accent-3": "#FDBA45", "brand-gold": "#FDBA45", "brand-navy": "#0B2239", "brand-green": "#38A169", "brand-ocean": "#126E82"}	\N	2026-01-13 10:05:28.121
cmkcfla730004nqiz4vsgz2fn	cmkcfemy90000nqiz1hym3kvc	2	{"info": "#228BE6", "danger": "#F87171", "success": "#2F9E44", "warning": "#F59F00", "accent-1": "#126E82", "accent-2": "#a23981", "accent-3": "#FDBA45", "brand-gold": "#FDBA45", "brand-navy": "#0B2239", "brand-green": "#38A169", "brand-ocean": "#126E82"}	cmk48grgz0008bmbcp8s2vrap	2026-01-13 10:10:38.175
cmkcfmo690006nqizjgvss33d	cmkcfemy90000nqiz1hym3kvc	3	{"info": "#228BE6", "danger": "#F87171", "success": "#2F9E44", "warning": "#F59F00", "accent-1": "#126E82", "accent-2": "#38A169", "accent-3": "#FDBA45", "brand-gold": "#FDBA45", "brand-navy": "#0B2239", "brand-green": "#38A169", "brand-ocean": "#126E82"}	cmk48grgz0008bmbcp8s2vrap	2026-01-13 10:11:42.946
cmkcfo4yn0009nqiziztuvry5	cmkcfo4yj0007nqizwe1flaeo	1	{"info": "#228BE6", "danger": "#F87171", "success": "#2F9E44", "warning": "#F59F00", "accent-1": "#822312", "accent-2": "#a23959", "accent-3": "#FDBA45", "brand-gold": "#FDBA45", "brand-navy": "#0B2239", "brand-green": "#38A169", "brand-ocean": "#827312"}	cmk48grgz0008bmbcp8s2vrap	2026-01-13 10:12:51.359
cmkcfp3iq000cnqiz1nmeploe	cmkcfo4yj0007nqizwe1flaeo	2	{"info": "#228BE6", "danger": "#F87171", "success": "#2F9E44", "warning": "#F59F00", "accent-1": "#822312", "accent-2": "#a23959", "accent-3": "#FDBA45", "brand-gold": "#FDBA45", "brand-navy": "#0B2239", "brand-green": "#91a239", "brand-ocean": "#827312"}	cmk48grgz0008bmbcp8s2vrap	2026-01-13 10:13:36.146
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."User" (id, "orgId", email, role, "createdAt", "passwordHash", "passwordUpdatedAt", "lastLoginAt", "deactivatedAt") FROM stdin;
cmk12kr4x000fo1hxdcjik7rt	cmk12kr4u000do1hxva29zgyd	test01@enabion.com	Owner	2026-01-05 11:20:50.53	scrypt$16384$8$1$cf9f1f15e22a040f0670d7a765bd70ca$80728a5e3ab9247b13afe02074468011b336d98ff245493655804680a331f4ba41716f2cf9582a803c3f0b79918de1c0a2f6eead3c8fdabb2c4fd07b72077247	2026-01-09 12:34:03.534	2026-01-13 15:05:19.898	\N
cmjdakp0k0003ut2ufp00eqzv	cmjdakp0f0001ut2uv0n881s3	info1@staadit.com	Owner	2025-12-19 19:58:16.485	scrypt$16384$8$1$5c4a3b9311e7279a7aebef2514244914$28376ef7428969c473c6dafc5f9583c9977a33f2a337be87625f064716375363ea478817b2d3ce9b37b67df6751cd9a11b1ff71fe6ac334f7b437bcd57ee95b9	2025-12-19 19:58:16.457	2026-01-10 20:35:19.612	\N
cmje0pkpw000fut2uqq8am6xm	cmje0pkpu000dut2u1z41ciku	info2@staadit.com	Owner	2025-12-20 08:09:54.212	scrypt$16384$8$1$4a0f57a2d209f21c57f003a07081d066$b5b8d5223f55670d58c86d43fd519e0c930e971d0f906fdfaba3d8864164cb174aa6ec06ffd563c02cac5ae2590af8b6a6a2dff50f1bbb5229820c55a69f05e6	2025-12-20 08:09:54.208	2025-12-20 08:40:51.099	\N
cmjejbesa0009o1hxza9o6wpx	cmjejbes70007o1hxngxzzzw7	info3@staadit.com	Owner	2025-12-20 16:50:46.042	scrypt$16384$8$1$ede6761328706ccb2354fdb64c762301$13f8654a67088179e19602da5eba2fcb0af261567d24aa370351bad95c2a86fb3aeeb11290f5885f06faa1b3dddeefe346f848e5fa31f4e098884322806f3802	2025-12-20 16:50:46.037	2025-12-20 16:50:46.037	\N
cmk482b4p0001bmbck6q90zvv	cmk12kr4u000do1hxva29zgyd	test02@enabion.com	Viewer	2026-01-07 16:17:46.198	\N	\N	\N	\N
cmk48grgz0008bmbcp8s2vrap	cmk48grgv0006bmbcmahvvpfc	admin@enabion.com	Owner	2026-01-07 16:29:00.563	scrypt$16384$8$1$f90de0b3da295e2cdb923f204e4d083e$151110312f0a7b03341c7ddfb99c18171daa5da474065cd941086780486b097fec6f69552c5aee7912a82b73dd36e81a91cd96f5a2ecf0e7ae40f35fe1915757	2026-01-07 16:29:00.552	2026-01-13 15:05:06.014	\N
cmk736hrm0009oyv7mm2wm20e	cmk736hrf0007oyv7jcxtvn9k	info04@staadit.com	Owner	2026-01-09 16:24:21.874	scrypt$16384$8$1$d4adf9f39d238280d16e63236f007e88$8b556366641dc56ec097d497d5dad2b866cc8344b5756b0e7e4ba5dc565762ae986408ad1e08ca82aed56466ac347ef87677bab2fbb3ae745d8c7752f5100707	2026-01-09 16:24:21.859	2026-01-09 16:24:21.859	\N
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4b94872d-a3e2-46cb-b7a6-7f5f6bd9b084	2b1715731cd35fd42cffbb99a75344acbacc5a25469ff59fc6fd4bb355c8b042	2025-12-15 20:05:00.958438+00	20251215203010_add_event_table	\N	\N	2025-12-15 20:05:00.93144+00	1
fd6aa896-2a4c-4204-aee7-0e8c1a6b5db4	c20093dbc7ba0bd1cd6986a2cfa267effb2fe308d0ab29600dfeffc9545eddb1	2026-01-07 15:58:30.672366+00	20260107190000_adminpanel_org_settings	\N	\N	2026-01-07 15:58:30.653345+00	1
4ae6d8e8-3db8-4ae0-9669-95713fc2ae35	9467b83f8b636cbd9f9c7cf5770d0dfbbb3fcd03edc2bbd042a8d28e8d960457	2025-12-17 15:40:42.913405+00	20251218_add_blobstore	\N	\N	2025-12-17 15:40:42.867957+00	1
f44b326c-c82c-4a2b-964a-c521c73b6054	80d9b493a19eb4733e00a774dd152b8292ae5d2ad99562b1fada7bf62a53cb95	2025-12-17 15:48:05.76771+00	20251217_make_lifecycle_required	\N	\N	2025-12-17 15:48:05.748703+00	1
e24fc9fd-7ba3-4e33-8c80-0d841a3335d6	77ca0523c7b8f8e59181f1aa73fc344aa258e78fdd8414d61b291a2a97be59a7	2025-12-19 18:50:33.120915+00	20251219141500_add_auth_sessions	\N	\N	2025-12-19 18:50:33.037265+00	1
5e46a49b-ef17-4607-ad25-560c1a739cfe	c20cec22f046d2cd9bc0f67e7effc54c95a1107e5fd1512c6f33e7cbb4ba2f67	2026-01-07 17:05:23.626077+00	20260107173000_add_org_status	\N	\N	2026-01-07 17:05:23.609546+00	1
0d9ccab5-60d8-499b-8d34-60e2bfb0e89f	3c05e88f6329d8e73a7adfeafdadc75420af59cfbeed3c453fb0ecba41e88948	2025-12-20 08:28:06.449514+00	20251219141000_add_password_reset_tokens	\N	\N	2025-12-20 08:28:06.419183+00	1
60510631-ad11-407d-9b94-572c486b809c	c20093dbc7ba0bd1cd6986a2cfa267effb2fe308d0ab29600dfeffc9545eddb1	\N	20260107190000_adminpanel_org_settings	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260107190000_adminpanel_org_settings\n\nDatabase error code: 23505\n\nDatabase error:\nERROR: could not create unique index "Organization_slug_key"\nDETAIL: Key (slug)=(test01) is duplicated.\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E23505), message: "could not create unique index \\"Organization_slug_key\\"", detail: Some("Key (slug)=(test01) is duplicated."), hint: None, position: None, where_: None, schema: Some("public"), table: Some("Organization"), column: None, datatype: None, constraint: Some("Organization_slug_key"), file: Some("tuplesortvariants.c"), line: Some(1361), routine: Some("comparetup_index_btree") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260107190000_adminpanel_org_settings"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20260107190000_adminpanel_org_settings"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-01-07 15:58:23.484369+00	2026-01-07 15:43:05.413996+00	0
a64d7c8e-0325-4a73-ba1c-82458849f9f0	ec53bb71746aa015f0b7c44c805f0e4b6e8fad33070a22159c3fb6a9f3bbec52	2026-01-09 11:09:03.189796+00	20260110120000_add_attachment_indexes	\N	\N	2026-01-09 11:09:03.171996+00	1
b798861d-4dd6-4e90-be14-05b0427aae06	f5aa2489c3afe48e98ce8445146d3fc7d77bf8e59c25bc7d6ea2b436f15fa252	2026-01-08 14:20:21.248674+00	20260108150000_add_intents	\N	\N	2026-01-08 14:20:21.205326+00	1
89a8eac7-5a94-41d0-871e-a7939850ed5e	d36186bdb0a946d54792dc0da87f0a7cab92e81c35ea065ff7d9e22f8f0ee38b	2026-01-08 19:01:49.958728+00	20260108160000_add_intent_paste_fields	\N	\N	2026-01-08 19:01:49.945477+00	1
8d00c1fe-2a76-4240-bc6a-c9ffb6e0fbca	311aa047de6771279d1cf6e150babb8424f04be7cebe6ab74e6c3b64704348f9	2026-01-13 15:01:30.571898+00	20260117150000_remove_org_theme_palette	\N	\N	2026-01-13 15:01:30.550916+00	1
3cf66aa9-e1c4-4e36-9ec8-ed3713caa145	52eb12cf5c062761ebc4d741d8452f7657c865d5b5af411af856ad2a0e64af29	\N	20260109130000_add_intent_list_fields	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260109130000_add_intent_list_fields\n\nDatabase error code: 42701\n\nDatabase error:\nERROR: column "client" of relation "Intent" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42701), message: "column \\"client\\" of relation \\"Intent\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("tablecmds.c"), line: Some(7347), routine: Some("check_for_column_name_collision") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260109130000_add_intent_list_fields"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20260109130000_add_intent_list_fields"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-01-09 11:02:05.849618+00	2026-01-09 10:52:35.828785+00	0
66852116-3e62-4894-8ce4-25627f7d39e7	52eb12cf5c062761ebc4d741d8452f7657c865d5b5af411af856ad2a0e64af29	2026-01-09 11:02:05.852567+00	20260109130000_add_intent_list_fields		\N	2026-01-09 11:02:05.852567+00	0
abcbbe96-b39f-4108-b1ef-6acb6ff5bda3	21a737563c2fccb7556263e3e11637cd008cf1181d96fea15693a01b772acecb	2026-01-09 22:07:14.736275+00	20260110153000_add_nda_records	\N	\N	2026-01-09 22:07:14.653515+00	1
6361e8be-54ea-4052-b5d2-8730eaac4f3a	9caee31888214570b3def0c8cdb6f89b78d3f8ce0f66307ea0156d48d3b5eb86	2026-01-10 21:07:30.934021+00	20260111120000_add_intent_share_links	\N	\N	2026-01-10 21:07:30.888353+00	1
17803694-65d9-42f4-8283-91fd7747322c	577f7bf696ad25d668834167927c38a3426d35b9a58d4253b8db8b62c124cf75	2026-01-13 09:41:32.641816+00	20260115130000_add_theme_palettes	\N	\N	2026-01-13 09:41:32.550531+00	1
\.


--
-- Name: Attachment Attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_pkey" PRIMARY KEY (id);


--
-- Name: Blob Blob_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Blob"
    ADD CONSTRAINT "Blob_pkey" PRIMARY KEY (id);


--
-- Name: Event Event_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_pkey" PRIMARY KEY (id);


--
-- Name: IntentShareLink IntentShareLink_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentShareLink"
    ADD CONSTRAINT "IntentShareLink_pkey" PRIMARY KEY (id);


--
-- Name: Intent Intent_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_pkey" PRIMARY KEY (id);


--
-- Name: NdaAcceptance NdaAcceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."NdaAcceptance"
    ADD CONSTRAINT "NdaAcceptance_pkey" PRIMARY KEY (id);


--
-- Name: NdaDocument NdaDocument_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."NdaDocument"
    ADD CONSTRAINT "NdaDocument_pkey" PRIMARY KEY (id);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: ThemePaletteRevision ThemePaletteRevision_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."ThemePaletteRevision"
    ADD CONSTRAINT "ThemePaletteRevision_pkey" PRIMARY KEY (id);


--
-- Name: ThemePalette ThemePalette_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."ThemePalette"
    ADD CONSTRAINT "ThemePalette_pkey" PRIMARY KEY (id);


--
-- Name: User User_email_key; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_email_key" UNIQUE (email);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Attachment_intentId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Attachment_intentId_idx" ON public."Attachment" USING btree ("intentId");


--
-- Name: Attachment_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Attachment_orgId_idx" ON public."Attachment" USING btree ("orgId");


--
-- Name: Attachment_orgId_intentId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Attachment_orgId_intentId_createdAt_idx" ON public."Attachment" USING btree ("orgId", "intentId", "createdAt");


--
-- Name: Blob_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Blob_orgId_idx" ON public."Blob" USING btree ("orgId");


--
-- Name: Blob_orgId_objectKey_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Blob_orgId_objectKey_idx" ON public."Blob" USING btree ("orgId", "objectKey");


--
-- Name: Event_correlationId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_correlationId_idx" ON public."Event" USING btree ("correlationId");


--
-- Name: Event_occurredAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_occurredAt_idx" ON public."Event" USING btree ("occurredAt");


--
-- Name: Event_orgId_subjectId_type_occurredAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_orgId_subjectId_type_occurredAt_idx" ON public."Event" USING btree ("orgId", "subjectId", type, "occurredAt");


--
-- Name: IntentShareLink_expiresAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentShareLink_expiresAt_idx" ON public."IntentShareLink" USING btree ("expiresAt");


--
-- Name: IntentShareLink_orgId_intentId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentShareLink_orgId_intentId_idx" ON public."IntentShareLink" USING btree ("orgId", "intentId");


--
-- Name: IntentShareLink_revokedAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "IntentShareLink_revokedAt_idx" ON public."IntentShareLink" USING btree ("revokedAt");


--
-- Name: IntentShareLink_tokenHashSha256_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "IntentShareLink_tokenHashSha256_key" ON public."IntentShareLink" USING btree ("tokenHashSha256");


--
-- Name: Intent_createdByUserId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_createdByUserId_idx" ON public."Intent" USING btree ("createdByUserId");


--
-- Name: Intent_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_idx" ON public."Intent" USING btree ("orgId");


--
-- Name: Intent_orgId_language_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_language_idx" ON public."Intent" USING btree ("orgId", language);


--
-- Name: Intent_orgId_lastActivityAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_lastActivityAt_idx" ON public."Intent" USING btree ("orgId", "lastActivityAt" DESC);


--
-- Name: Intent_orgId_ownerUserId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_ownerUserId_idx" ON public."Intent" USING btree ("orgId", "ownerUserId");


--
-- Name: Intent_orgId_stage_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_stage_idx" ON public."Intent" USING btree ("orgId", stage);


--
-- Name: Intent_orgId_stage_lastActivityAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Intent_orgId_stage_lastActivityAt_idx" ON public."Intent" USING btree ("orgId", stage, "lastActivityAt" DESC);


--
-- Name: NdaAcceptance_acceptedByUserId_acceptedAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "NdaAcceptance_acceptedByUserId_acceptedAt_idx" ON public."NdaAcceptance" USING btree ("acceptedByUserId", "acceptedAt");


--
-- Name: NdaAcceptance_orgId_counterpartyOrgId_ndaType_ndaVersion_enHash; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "NdaAcceptance_orgId_counterpartyOrgId_ndaType_ndaVersion_enHash" ON public."NdaAcceptance" USING btree ("orgId", "counterpartyOrgId", "ndaType", "ndaVersion", "enHashSha256");


--
-- Name: NdaAcceptance_orgId_ndaType_ndaVersion_enHashSha256_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "NdaAcceptance_orgId_ndaType_ndaVersion_enHashSha256_idx" ON public."NdaAcceptance" USING btree ("orgId", "ndaType", "ndaVersion", "enHashSha256");


--
-- Name: NdaDocument_ndaType_isActive_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "NdaDocument_ndaType_isActive_idx" ON public."NdaDocument" USING btree ("ndaType", "isActive");


--
-- Name: NdaDocument_ndaVersion_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "NdaDocument_ndaVersion_key" ON public."NdaDocument" USING btree ("ndaVersion");


--
-- Name: Organization_slug_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "Organization_slug_key" ON public."Organization" USING btree (slug);


--
-- Name: PasswordResetToken_expiresAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "PasswordResetToken_expiresAt_idx" ON public."PasswordResetToken" USING btree ("expiresAt");


--
-- Name: PasswordResetToken_tokenHash_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "PasswordResetToken_tokenHash_key" ON public."PasswordResetToken" USING btree ("tokenHash");


--
-- Name: PasswordResetToken_userId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "PasswordResetToken_userId_idx" ON public."PasswordResetToken" USING btree ("userId");


--
-- Name: Session_expiresAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Session_expiresAt_idx" ON public."Session" USING btree ("expiresAt");


--
-- Name: Session_tokenHash_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "Session_tokenHash_key" ON public."Session" USING btree ("tokenHash");


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: ThemePaletteRevision_paletteId_createdAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "ThemePaletteRevision_paletteId_createdAt_idx" ON public."ThemePaletteRevision" USING btree ("paletteId", "createdAt");


--
-- Name: ThemePaletteRevision_paletteId_revision_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "ThemePaletteRevision_paletteId_revision_key" ON public."ThemePaletteRevision" USING btree ("paletteId", revision);


--
-- Name: ThemePalette_isGlobalDefault_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "ThemePalette_isGlobalDefault_idx" ON public."ThemePalette" USING btree ("isGlobalDefault");


--
-- Name: ThemePalette_slug_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "ThemePalette_slug_key" ON public."ThemePalette" USING btree (slug);


--
-- Name: Attachment Attachment_blobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_blobId_fkey" FOREIGN KEY ("blobId") REFERENCES public."Blob"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Attachment Attachment_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Blob Blob_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Blob"
    ADD CONSTRAINT "Blob_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Event Event_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentShareLink IntentShareLink_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentShareLink"
    ADD CONSTRAINT "IntentShareLink_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentShareLink IntentShareLink_intentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentShareLink"
    ADD CONSTRAINT "IntentShareLink_intentId_fkey" FOREIGN KEY ("intentId") REFERENCES public."Intent"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentShareLink IntentShareLink_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentShareLink"
    ADD CONSTRAINT "IntentShareLink_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: IntentShareLink IntentShareLink_revokedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."IntentShareLink"
    ADD CONSTRAINT "IntentShareLink_revokedByUserId_fkey" FOREIGN KEY ("revokedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Intent Intent_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Intent Intent_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Intent Intent_ownerUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Intent"
    ADD CONSTRAINT "Intent_ownerUserId_fkey" FOREIGN KEY ("ownerUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: NdaAcceptance NdaAcceptance_acceptedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."NdaAcceptance"
    ADD CONSTRAINT "NdaAcceptance_acceptedByUserId_fkey" FOREIGN KEY ("acceptedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NdaAcceptance NdaAcceptance_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."NdaAcceptance"
    ADD CONSTRAINT "NdaAcceptance_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ThemePaletteRevision ThemePaletteRevision_paletteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."ThemePaletteRevision"
    ADD CONSTRAINT "ThemePaletteRevision_paletteId_fkey" FOREIGN KEY ("paletteId") REFERENCES public."ThemePalette"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict NnG5o2Zdw2cEUYCSO705dOSegIkfHeoHiVeNxFEFVYPidwgaBeHw4QssFB900ix

