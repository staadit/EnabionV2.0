--
-- PostgreSQL database dump
--

\restrict eeN0JFwJbw0cYCEPCCnv9qopEI7Mp68iSMUEbel0y9hNJctzVYq38Ea6Oc72CG7

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AttachmentSource; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."AttachmentSource" AS ENUM (
    'email_ingest',
    'manual_upload',
    'export'
);


ALTER TYPE public."AttachmentSource" OWNER TO enabion;

--
-- Name: BlobStorageDriver; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."BlobStorageDriver" AS ENUM (
    'local',
    's3'
);


ALTER TYPE public."BlobStorageDriver" OWNER TO enabion;

--
-- Name: ConfidentialityLevel; Type: TYPE; Schema: public; Owner: enabion
--

CREATE TYPE public."ConfidentialityLevel" AS ENUM (
    'L1',
    'L2',
    'L3'
);


ALTER TYPE public."ConfidentialityLevel" OWNER TO enabion;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Attachment; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Attachment" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "intentId" text,
    source public."AttachmentSource" DEFAULT 'manual_upload'::public."AttachmentSource" NOT NULL,
    filename text NOT NULL,
    "blobId" text NOT NULL,
    "createdByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Attachment" OWNER TO enabion;

--
-- Name: Blob; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Blob" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    "storageDriver" public."BlobStorageDriver" DEFAULT 'local'::public."BlobStorageDriver" NOT NULL,
    "objectKey" text NOT NULL,
    "sizeBytes" integer NOT NULL,
    sha256 character(64) NOT NULL,
    "contentType" text NOT NULL,
    confidentiality public."ConfidentialityLevel" DEFAULT 'L1'::public."ConfidentialityLevel" NOT NULL,
    encrypted boolean DEFAULT false NOT NULL,
    "encryptionAlg" text,
    "encryptionKeyId" text,
    "encryptionIvB64" text,
    "encryptionTagB64" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Blob" OWNER TO enabion;

--
-- Name: Event; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Event" (
    id text NOT NULL,
    "schemaVersion" integer NOT NULL,
    type text NOT NULL,
    "occurredAt" timestamp(3) without time zone NOT NULL,
    "recordedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "orgId" text NOT NULL,
    "actorUserId" text,
    "actorOrgId" text,
    "subjectType" text NOT NULL,
    "subjectId" text NOT NULL,
    "lifecycleStep" text DEFAULT 'CLARIFY'::text NOT NULL,
    "pipelineStage" text DEFAULT 'NEW'::text NOT NULL,
    channel text NOT NULL,
    "correlationId" text NOT NULL,
    payload jsonb NOT NULL
);


ALTER TABLE public."Event" OWNER TO enabion;

--
-- Name: Organization; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."Organization" OWNER TO enabion;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


ALTER TABLE public."Session" OWNER TO enabion;

--
-- Name: User; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "orgId" text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT now() NOT NULL,
    "passwordHash" text,
    "passwordUpdatedAt" timestamp(3) without time zone,
    "lastLoginAt" timestamp(3) without time zone
);


ALTER TABLE public."User" OWNER TO enabion;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: enabion
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO enabion;

--
-- Data for Name: Attachment; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Attachment" (id, "orgId", "intentId", source, filename, "blobId", "createdByUserId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Blob; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Blob" (id, "orgId", "storageDriver", "objectKey", "sizeBytes", sha256, "contentType", confidentiality, encrypted, "encryptionAlg", "encryptionKeyId", "encryptionIvB64", "encryptionTagB64", "createdAt") FROM stdin;
\.


--
-- Data for Name: Event; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Event" (id, "schemaVersion", type, "occurredAt", "recordedAt", "orgId", "actorUserId", "actorOrgId", "subjectType", "subjectId", "lifecycleStep", "pipelineStage", channel, "correlationId", payload) FROM stdin;
01KCW322DF84P22Q3CGW3GA29T	1	USER_SIGNED_UP	2025-12-19 19:58:16.494	2025-12-19 19:58:16.495	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW322DE2NR8R14VJRQ4RFC5	{"role": "Owner", "email": "info1@staadit.com", "orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdakp0p0005ut2uz4saqcrf", "payloadVersion": 1}
01KCW32H23AE8XH2MK87W8ZK82	1	USER_LOGGED_OUT	2025-12-19 19:58:31.49	2025-12-19 19:58:31.491	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW32H22S91HDZZTJQ84G8EZ	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdakp0p0005ut2uz4saqcrf", "payloadVersion": 1}
01KCW333YN1N9EH7CGWS6KC445	1	USER_LOGGED_IN	2025-12-19 19:58:50.837	2025-12-19 19:58:50.838	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW333YNYE7A0XFYRVSF64H9	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdalfiq0008ut2u50saciqk", "payloadVersion": 1}
01KCW33BG9KMDR0MKJ4X2VRGCW	1	USER_LOGGED_OUT	2025-12-19 19:58:58.569	2025-12-19 19:58:58.569	cmjdakp0f0001ut2uv0n881s3	cmjdakp0k0003ut2ufp00eqzv	\N	USER	cmjdakp0k0003ut2ufp00eqzv	CLARIFY	NEW	api	01KCW33BG9RTNRN6AV7159DBY0	{"orgId": "cmjdakp0f0001ut2uv0n881s3", "userId": "cmjdakp0k0003ut2ufp00eqzv", "sessionId": "cmjdalfiq0008ut2u50saciqk", "payloadVersion": 1}
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Organization" (id, name, "createdAt") FROM stdin;
cmjdakp0f0001ut2uv0n881s3	TEST01	2025-12-19 19:58:16.479
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."Session" (id, "userId", "tokenHash", "createdAt", "expiresAt", "revokedAt") FROM stdin;
cmjdakp0p0005ut2uz4saqcrf	cmjdakp0k0003ut2ufp00eqzv	6d56a5096834c4876cbe9309194e9b227be23cbc8fc7ff8f3cda1ff07cf1b11b	2025-12-19 19:58:16.489	2025-12-20 07:58:16.457	2025-12-19 19:58:31.487
cmjdalfiq0008ut2u50saciqk	cmjdakp0k0003ut2ufp00eqzv	2abe08b56945dc697dd0e0cfbd34d5887fc64187b396f551eead41b83f49a824	2025-12-19 19:58:50.834	2025-12-20 07:58:50.829	2025-12-19 19:58:58.566
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public."User" (id, "orgId", email, role, "createdAt", "passwordHash", "passwordUpdatedAt", "lastLoginAt") FROM stdin;
cmjdakp0k0003ut2ufp00eqzv	cmjdakp0f0001ut2uv0n881s3	info1@staadit.com	Owner	2025-12-19 19:58:16.485	scrypt$16384$8$1$5c4a3b9311e7279a7aebef2514244914$28376ef7428969c473c6dafc5f9583c9977a33f2a337be87625f064716375363ea478817b2d3ce9b37b67df6751cd9a11b1ff71fe6ac334f7b437bcd57ee95b9	2025-12-19 19:58:16.457	2025-12-19 19:58:50.829
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: enabion
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4b94872d-a3e2-46cb-b7a6-7f5f6bd9b084	2b1715731cd35fd42cffbb99a75344acbacc5a25469ff59fc6fd4bb355c8b042	2025-12-15 20:05:00.958438+00	20251215203010_add_event_table	\N	\N	2025-12-15 20:05:00.93144+00	1
4ae6d8e8-3db8-4ae0-9669-95713fc2ae35	9467b83f8b636cbd9f9c7cf5770d0dfbbb3fcd03edc2bbd042a8d28e8d960457	2025-12-17 15:40:42.913405+00	20251218_add_blobstore	\N	\N	2025-12-17 15:40:42.867957+00	1
f44b326c-c82c-4a2b-964a-c521c73b6054	80d9b493a19eb4733e00a774dd152b8292ae5d2ad99562b1fada7bf62a53cb95	2025-12-17 15:48:05.76771+00	20251217_make_lifecycle_required	\N	\N	2025-12-17 15:48:05.748703+00	1
e24fc9fd-7ba3-4e33-8c80-0d841a3335d6	77ca0523c7b8f8e59181f1aa73fc344aa258e78fdd8414d61b291a2a97be59a7	2025-12-19 18:50:33.120915+00	20251219141500_add_auth_sessions	\N	\N	2025-12-19 18:50:33.037265+00	1
\.


--
-- Name: Attachment Attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_pkey" PRIMARY KEY (id);


--
-- Name: Blob Blob_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Blob"
    ADD CONSTRAINT "Blob_pkey" PRIMARY KEY (id);


--
-- Name: Event Event_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_pkey" PRIMARY KEY (id);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: User User_email_key; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_email_key" UNIQUE (email);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Attachment_intentId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Attachment_intentId_idx" ON public."Attachment" USING btree ("intentId");


--
-- Name: Attachment_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Attachment_orgId_idx" ON public."Attachment" USING btree ("orgId");


--
-- Name: Blob_orgId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Blob_orgId_idx" ON public."Blob" USING btree ("orgId");


--
-- Name: Blob_orgId_objectKey_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Blob_orgId_objectKey_idx" ON public."Blob" USING btree ("orgId", "objectKey");


--
-- Name: Event_correlationId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_correlationId_idx" ON public."Event" USING btree ("correlationId");


--
-- Name: Event_occurredAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_occurredAt_idx" ON public."Event" USING btree ("occurredAt");


--
-- Name: Event_orgId_subjectId_type_occurredAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Event_orgId_subjectId_type_occurredAt_idx" ON public."Event" USING btree ("orgId", "subjectId", type, "occurredAt");


--
-- Name: Session_expiresAt_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Session_expiresAt_idx" ON public."Session" USING btree ("expiresAt");


--
-- Name: Session_tokenHash_key; Type: INDEX; Schema: public; Owner: enabion
--

CREATE UNIQUE INDEX "Session_tokenHash_key" ON public."Session" USING btree ("tokenHash");


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: enabion
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: Attachment Attachment_blobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_blobId_fkey" FOREIGN KEY ("blobId") REFERENCES public."Blob"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Attachment Attachment_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Attachment"
    ADD CONSTRAINT "Attachment_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Blob Blob_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Blob"
    ADD CONSTRAINT "Blob_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Event Event_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_orgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: enabion
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict eeN0JFwJbw0cYCEPCCnv9qopEI7Mp68iSMUEbel0y9hNJctzVYq38Ea6Oc72CG7

